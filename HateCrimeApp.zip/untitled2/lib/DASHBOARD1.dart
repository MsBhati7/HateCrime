import 'package:flutter/material.dart';
import 'package:get/get.dart';

import 'package:sizer/sizer.dart';
import 'package:untitled2/Drawer.dart';
import 'package:untitled2/HousingCensus.dart';
import 'package:untitled2/HousingCensusForm1.dart';
import 'package:untitled2/Myprofile.dart';
import 'package:untitled2/Profile.dart';
import 'package:untitled2/Reports%20History.dart';
import 'package:untitled2/Settings.dart';
import 'package:untitled2/reportnewhate-crime.dart';
import 'package:untitled2/spalash.dart';

import 'package:untitled2/utils/IcIcons.dart';
import 'package:untitled2/utils/colors.dart';

import 'Widgets/appbuttons.dart';

class DashBoard1 extends StatefulWidget {
  static const route = "/dashBoard1";

  DashBoard1({Key? key}) : super(key: key);

  @override
  State<DashBoard1> createState() => _DashBoard1State();
}

class _DashBoard1State extends State<DashBoard1> {
  String? firstdropDownValue = "Food Category";
  String? seconddropDownValue = "Select";
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        elevation: 0.0,
        title: Row(
          children: [
            Text(
              "Dashboard",
              style: TextStyle(
                fontSize: 13.sp,
                fontWeight: FontWeight.bold,
                color: AppColors.black1,
              ),
            ),
            Padding(
              padding:  EdgeInsets.only(left: 35.w),
              child: Image.asset(IcIcons.notify,width: 4.w,),
            ),

            Image.asset(IcIcons.notify1,width: 15.w,)
          ],
        ),
        leading: IconButton(onPressed: () {}, icon: Image.asset(IcIcons.Dash,width: 5.w,)),
        backgroundColor: AppColors.white1,
      ),
      body: SingleChildScrollView(
          child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
            Container(),
            SizedBox(
              height: 3.h,
            ),
            Padding(
              padding:  EdgeInsets.only(right: 65.w),
              child: RichText(text: TextSpan(
                text: "Hello ",style: TextStyle(fontSize: 12.sp,fontWeight: FontWeight.bold,color: AppColors.black1),
                children: [
                  TextSpan(
                  text: "Amanda!",style: TextStyle(fontSize: 12.sp,fontWeight: FontWeight.bold,color: AppColors.red1))
                ]
              )),
            ),
                SizedBox(
                  height: 1.h,
                ),
               Padding(
                 padding:  EdgeInsets.only(right: 35.w),
                 child: Text( "Welcome to COMMUNION ",style: TextStyle(fontSize: 14.sp,fontWeight: FontWeight.w500,color: AppColors.black1)),
               ),
            SizedBox(
              height: 3.h,
            ),
            Container(
              width: 90.w,
              height: 7.5.h,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(8.0),
               color: AppColors.litey,
                border: Border.all(
                  color: AppColors.lite1,
                  width: 0.2.h,
                ),
              ),
              child: Padding(
                padding: EdgeInsets.all(2.h),
                child: GestureDetector(
                  onTap: () {Get.to(() => ReportNewHateCrime());},
                  child: Row(
                    children: [
                      Text(
                        "REPORT HATE-CRIME",
                        style: TextStyle(
                          color: Colors.black87,
                          fontSize: 10.sp,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      SizedBox(
                        width: 44.w,
                      ),
                      Icon(Icons.arrow_forward_ios,size: 4.w,color: AppColors.black1,)
                    ],
                  ),
                ),
              ),
            ),
            SizedBox(
              height: 2.h,
            ),
            Container(
              width: 92.w,
              height: 7.5.h,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(8.0),
               color: AppColors.litey,
                border: Border.all(
                  color: AppColors.lite1,
                  width: 0.2.h,
                ),
              ),
              child: Padding(
                padding: EdgeInsets.all(2.h),
                child: Row(
                  children: [
                    Text(
                      "VALIDATE HATE CRIME",
                      style: TextStyle(
                        color: Colors.black87,
                        fontSize: 10.sp,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    SizedBox(
                      width: 44.w,
                    ),
                    Icon(Icons.arrow_forward_ios,size: 4.w,color: AppColors.black1,)
                  ],
                ),
              ),
            ),
                SizedBox(
                  height: 2.h,
                ),
                Container(
                  width: 92.w,
                  height: 7.5.h,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(2.w),
                    color: AppColors.litey,
                    border: Border.all(
                      color: AppColors.lite1,
                      width: 0.2.h,
                    ),
                  ),
                  child: Padding(
                    padding: EdgeInsets.all(2.h),
                    child: Row(
                      children: [
                        GestureDetector(

                        onTap: () {Get.to(() => HousingCensusForm1());},
                          child: Text(
                            "ENTER CENSUS DATA",
                            style: TextStyle(
                              color: Colors.black87,
                              fontSize: 10.sp,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                        SizedBox(
                          width: 47.w,
                        ),
                       Icon(Icons.arrow_forward_ios,size: 4.w,color: AppColors.black1,)
                        
                      ],
                    ),
                  ),
                ),

                SizedBox(
                  height: 6.h,
                ),
                Padding(
                  padding:  EdgeInsets.only(right: 70.w),
                  child: Text( "View Reports ",style: TextStyle(fontSize: 10.sp,fontWeight: FontWeight.bold,color: AppColors.black1)),
                ),
                SizedBox(
                  height: 2.h,
                ),
                DecoratedBox(
                  decoration: ShapeDecoration(
                    color: AppColors.white1,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.all(
                          Radius.circular(2.w)),
                    ),
                  ),
                  child: Container(
                    decoration: BoxDecoration(
                        color: AppColors.grey6,
                        borderRadius:
                        BorderRadius.circular(
                            2.w),
                        border: Border.all(
                            color: AppColors.grey6)),
                    height: 7.h,
                    width: 90.w,
                    child:
                    DropdownButtonHideUnderline(
                      child: Padding(
                        padding: EdgeInsets.symmetric(
                            horizontal: 2.h),
                        child: DropdownButton<String>(
                          elevation: 0,
                          icon: Icon(
                            Icons
                                .keyboard_arrow_down_sharp,
                            color: AppColors.black1,
                          ),
                          value: seconddropDownValue,
                          dropdownColor:
                          AppColors.grey5,
                          items: <String>[
                            'Food Category',
                            'Select'
                          ].map((String value) {
                            return DropdownMenuItem<
                                String>(
                              value: value,
                              child: Text(
                                value,
                                style: TextStyle(
                                    fontSize: 10.sp),
                              ),
                            );
                          }).toList(),
                          onChanged: (value) {
                            setState(() {
                              firstdropDownValue =
                                  value;
                            });
                          },
                        ),
                      ),
                    ),
                  ),
                ),
                SizedBox(
                  height: 5.h,
                ),
                GestureDetector(
                    onTap: () {Get.to(() => Spalash());},
                    child: Container(
                      alignment: Alignment.center,
                      width: 90.w,
                      height: 8.h,
                      decoration: BoxDecoration(

                        border: Border.all(
                          color: AppColors.grey2,
                          width: 0.1.h,
                        ),
                        color: AppColors.grey6,
                        borderRadius: BorderRadius.circular(2.w),


                      ),
                      child: Padding(
                        padding: EdgeInsets.all(2.h),
                        child: Text(
                          "EXIT COMMUNION ",
                          style: TextStyle(
                            color: Colors.black87,
                            fontSize: 11.sp,
                            fontWeight: FontWeight.bold,

                          ),
                        ),
                      ),
                    )),
                     SizedBox(
              height: 5.h,
            ),
            Container(
              width: 90.w,
              height: 11.h,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(8.0),
                color: AppColors.litey,
                
              ),
              child: Padding(
                padding:  EdgeInsets.only(left: 7.w,bottom: 1.h),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    RichText(text: TextSpan(
                        text: "Need Help? Have Any Questions?",style: TextStyle(fontSize: 9.sp, color: AppColors.black1),

                    children: [
                      TextSpan(text: "\nGet in touch with our customer ",style: TextStyle(height: 0.3.h,fontSize: 9.sp,fontWeight: FontWeight.w400 ,color: AppColors.grey1)),
                      TextSpan(text: "\nsupport team. ",style: TextStyle(fontSize: 9.sp,fontWeight: FontWeight.w400 ,color: AppColors.grey1))
                    ]

                    ),


                    ),

                   Padding(
                     padding:  EdgeInsets.only(left: 25.w,),
                     child: GestureDetector(
                         onTap: () {Get.to(() => ReportNewHateCrime());},
                         child: Icon(Icons.arrow_forward,size: 5.w,)),
                   )
                   ],

                ),
              ),
            ),

                SizedBox(
                  height: 8.h,
                ),
          ])),

     drawer: Drawer(
         child: Container(
           color: AppColors.black1,
           child: Column(
             crossAxisAlignment: CrossAxisAlignment.start,
             children: [
               SizedBox(height: 3.h,),
               Padding(
                 padding:  EdgeInsets.only(left: 3.w,top: 3.h),
                 child: Text("Menu",style: TextStyle(fontSize: 12.sp,fontWeight: FontWeight.bold,color: AppColors.white1)),
               ),
               SizedBox(height: 2.h,),
               Padding(
                 padding:  EdgeInsets.only(left: 3.w),
                 child: Container(


                     height: 15.h,
                     width: 75.w,
                     decoration: BoxDecoration(
                         color: AppColors.black2,
                         borderRadius: BorderRadius.circular(5.w)

                     ),
                     child: Row(

                       children: [
                         Padding(
                           padding:  EdgeInsets.only(left: 5.w),
                           child: CircleAvatar(
                               radius: 8.w,
                               backgroundColor: AppColors.lite1,
                               child: Image.asset(IcIcons.image3,width: 14.w,)),
                         ) ,
                         Padding(
                           padding: EdgeInsets.only(left: 3.w),
                           child: RichText(text: TextSpan(
                               text: "Rendy Vickriansyah",style: TextStyle(height: 0.3.h,fontSize: 10.sp,fontWeight: FontWeight.bold,color: AppColors.white1),

                               children: [
                                 TextSpan(
                                   text: "\nRendy.V@email.con",style: TextStyle(color: AppColors.lite2),



                                 )])

                           ),
                         ) ],
                     )
                 ),
               ),


               SizedBox(height: 4.h,),
               Container(

                 height: 7.h,
                 width: 75.w,
                 child: GestureDetector(
                   onTap: () {Get.to(() => DashBoard1());},
                   child: ListTile(
                       dense:true,
                       leading: Image.asset(IcIcons.Dashb,width: 5.w,),
                       title: Text("DASHBOARD",style: TextStyle(fontSize: 10.sp,color: AppColors.white1),),
                       trailing: Icon(Icons.arrow_forward_ios,color: AppColors.lite1,size: 4.w,)
                   ),
                 ),
               ),
               Container(

                 height: 7.h,
                 width: 75.w,
                 child: ListTile(
                     dense:true,
                     leading: Image.asset(IcIcons.report2,width: 5.w,),
                     title: GestureDetector(
                         onTap: (){
                           Get.to(() => ReportsHistory());
                         },
                         child: Text("REPORT HISTORY",style: TextStyle(fontSize: 10.sp,color: AppColors.lite2),)),
                     trailing: Icon(Icons.arrow_forward_ios,color: AppColors.lite1,size: 4.w,)
                 ),
               ),
               Container(

                 height: 7.h,
                 width: 75.w,
                 child: GestureDetector(
                   onTap: () { Get.to(() => MyProfile1());},
                   child: ListTile(
                       dense:true,
                       leading: Image.asset(IcIcons.per,width: 5.w,),
                       title: Text("MY PROFILE",style: TextStyle(fontSize: 10.sp,color: AppColors.lite2),),
                       trailing: Icon(Icons.arrow_forward_ios,color: AppColors.lite1,size: 4.w,)
                   ),
                 ),
               ),
               Container(

                 height: 7.h,
                 width: 75.w,
                 decoration: BoxDecoration(

                     borderRadius: BorderRadius.circular(5.w)

                 ),
                 child: GestureDetector(
                   onTap: (){
                     Get.to(() => Settings());
                   },
                   child: ListTile(
                     dense:true,
                     leading: Image.asset(IcIcons.Settings1,width: 5.w,),
                     title: Text("SETTINGS",style: TextStyle(fontSize: 10.sp,color: AppColors.lite2),),
                     trailing: Icon(Icons.arrow_forward_ios,color: AppColors.lite1,size: 4.w,),
                     focusColor:   AppColors.black2,
                   ),
                 ),
               ),
               Container(

                 height: 10.h,
                 width: 75.w,
                 child: ListTile(

                     contentPadding: EdgeInsets.only(left: 5.w, right: 5.w),
                     leading: Image.asset(IcIcons.phone2,width: 5.w,),
                     title: Text("CONTRACT US",style: TextStyle(fontSize: 10.sp,color: AppColors.lite2),),
                     trailing: Icon(Icons.arrow_forward_ios,color: AppColors.lite1,size: 4.w,)
                   // Image.asset(IcIcons.arrowfor,width: 2.w,),
                 ),
               ),
               Padding(
                 padding:  EdgeInsets.only(left: 36.w,top: 25.h),
                 child: GestureDetector(

                       onTap: () { Get.to(() => DashBoard1());},
                     child: Image.asset(IcIcons.image5,width: 10.w,)),
               )

             ],
           ),
         )


     ),

    );
  }
}
