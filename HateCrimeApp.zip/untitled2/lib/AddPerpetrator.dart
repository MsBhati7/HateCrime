import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:sizer/sizer.dart';
import 'package:untitled2/ReportSubmitted.dart';

import 'package:untitled2/Widgets/appbuttons.dart';
import 'package:untitled2/utils/IcIcons.dart';

import 'package:untitled2/utils/colors.dart';



class AddPerpetrator extends StatefulWidget {
  static const route = "/addPerpetrator";

  AddPerpetrator({Key? key}) : super(key: key);

  @override
  State<AddPerpetrator> createState() => _AddPerpetratorState();
}

class _AddPerpetratorState extends State<AddPerpetrator> {
  String? firstdropDownValue = "Food Category";
  String? seconddropDownValue = "Select";
  var fullname = TextEditingController();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body:  Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
              child: ElevatedButton(
                child: Text("Open Bottom Sheet"),
                onPressed: () {
                  showModalBottomSheet(
                      context: context,
                      shape: RoundedRectangleBorder(
                          borderRadius:
                          BorderRadius.vertical(top: Radius.circular(5.w))),
                      builder: (context) => Container(


                        decoration: BoxDecoration(
                          color: AppColors.lite1,
                          borderRadius: BorderRadius.only(
                              topRight: Radius.circular(5.w),
                              topLeft: Radius.circular(5.w)),
                        ),
                        child: Stack(
                          children: [
                            Padding(
                              padding: EdgeInsets.only(top: 3.h),
                              child: SingleChildScrollView(
                                child: Container(
                                  decoration: BoxDecoration(
                                    color: AppColors.white1,
                                    borderRadius: BorderRadius.only(
                                        topRight: Radius.circular(5.w),
                                        topLeft: Radius.circular(5.w)),
                                  ),
                                  height: 100.h,
                                  child: Column(
                                    children: [
                                      SizedBox(height: 2.h,),
                                      Row(
                                        children: [
                                          Text("     Add Victim(s) info",style: TextStyle(
                                              fontSize: 13.sp,
                                              fontWeight: FontWeight.bold,
                                              color: AppColors.black1)),
                                          Padding(
                                            padding:  EdgeInsets.only(left: 35.w),
                                            child: CircleAvatar(
                                                backgroundColor: AppColors.white1,
                                                child:
                                                Icon(Icons.close,color: AppColors.black1,)
                                            ),
                                          )
                                        ],
                                      ),

                                      Padding(
                                        padding:  EdgeInsets.only(right: 45
                                            .w),
                                        child: Text("Full Name                     ",
                                            style: TextStyle(
                                                fontSize: 11.sp,

                                                color: AppColors.grey1)),
                                      ),
                                      SizedBox(height: 2.h,),
                                      SingleChildScrollView(
                                        child: Container(
                                          height: 6.5.h,
                                          width: 90.w,
                                          decoration: BoxDecoration(
                                              color: AppColors.grey6,
                                              borderRadius:
                                              BorderRadius.circular(2.w),
                                              border: Border.all(
                                                  color: AppColors.grey6)),
                                          child: Padding(
                                            padding: EdgeInsets.all(
                                              1.5.h,
                                            ),
                                            child: TextFormField(
                                              decoration: InputDecoration(
                                                border: InputBorder.none,
                                                hintText: "Sarah M. Holiday",
                                                hintStyle: TextStyle(
                                                    fontSize: 10.sp,
                                                    fontWeight:
                                                    FontWeight.w500,
                                                    color: AppColors.black1),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                      SizedBox(height: 2.h,),
                                      Row(
                                        mainAxisAlignment:
                                        MainAxisAlignment.spaceEvenly,
                                        children: [
                                          Text(
                                            "Age                                               ",
                                            style: TextStyle(
                                                fontSize: 10.sp,
                                                fontWeight: FontWeight.w300,
                                                color: AppColors.grey5),
                                          ),

                                          Text(
                                            "Gender                               ",
                                            style: TextStyle(
                                                fontSize: 10.sp,
                                                fontWeight: FontWeight.w300,
                                                color: AppColors.grey5),
                                          )
                                        ],
                                      ),
                                      SizedBox(height: 2.h,),

                                      Row(
                                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                        children: [
                                          Container(
                                            height: 6.5.h,
                                            width: 45.w,
                                            decoration: BoxDecoration(
                                                color: AppColors.grey6,
                                                borderRadius: BorderRadius.circular(2.w),
                                                border: Border.all(color: AppColors.grey6)),
                                            child: Padding(
                                              padding: EdgeInsets.all(
                                                1.5.h,
                                              ),
                                              child: TextFormField(
                                                decoration: InputDecoration(
                                                  border: InputBorder.none,
                                                  hintText: "34 Years",
                                                  hintStyle: TextStyle(
                                                      fontSize: 10.sp,
                                                      fontWeight: FontWeight.w500,
                                                      color: AppColors.black1),
                                                ),
                                              ),
                                            ),
                                          ),
                                          DecoratedBox(
                                            decoration: ShapeDecoration(
                                              color: AppColors.white1,
                                              shape: RoundedRectangleBorder(
                                                borderRadius: BorderRadius.all(Radius.circular(2.w)),
                                              ),
                                            ),
                                            child: Container(
                                              decoration: BoxDecoration(
                                                  color: AppColors.grey6,
                                                  borderRadius: BorderRadius.circular(2.w),
                                                  border: Border.all(color: AppColors.grey6)),
                                              height: 6.5.h,
                                              width: 45.w,
                                              child: DropdownButtonHideUnderline(
                                                child: Padding(
                                                  padding: EdgeInsets.symmetric(horizontal: 2.h),
                                                  child: DropdownButton<String>(
                                                    elevation: 0,
                                                    icon: Icon(
                                                      Icons.keyboard_arrow_down_sharp,
                                                      color: AppColors.black1,
                                                    ),
                                                    value: seconddropDownValue,
                                                    dropdownColor: AppColors.grey5,
                                                    items: <String>['Food Category', 'Select']
                                                        .map((String value) {
                                                      return DropdownMenuItem<String>(
                                                        value: value,
                                                        child: Text(
                                                          value,
                                                          style: TextStyle(fontSize: 10.sp),
                                                        ),
                                                      );
                                                    }).toList(),
                                                    onChanged: (value) {
                                                      setState(() {
                                                       seconddropDownValue = value;
                                                      });
                                                    },
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                      SizedBox(
                                        height: 2.h,
                                      ),
                                      Padding(
                                        padding:  EdgeInsets.only(right: 62.w),
                                        child: Text(
                                          "Location of Crime",
                                          style: TextStyle(
                                              fontSize: 10.sp,
                                              fontWeight: FontWeight.w300,
                                              color: AppColors.grey5),
                                        ),
                                      ),
                                      SizedBox(
                                        height: 2.h,
                                      ),
                                      Container(
                                        height: 6.5.h,
                                        width: 90.w,
                                        decoration: BoxDecoration(
                                            color: AppColors.grey6,
                                            borderRadius:
                                            BorderRadius.circular(2.w),
                                            border: Border.all(
                                                color: AppColors.grey6)),
                                        child: Padding(
                                          padding: EdgeInsets.all(
                                            1.5.h,
                                          ),
                                          child: TextFormField(
                                            decoration: InputDecoration(
                                              border: InputBorder.none,
                                              hintText: "1378 Bryan Avenue. Minneapolis",
                                              hintStyle: TextStyle(
                                                  fontSize: 10.sp,
                                                  fontWeight:
                                                  FontWeight.w500,
                                                  color: AppColors.black1),
                                            ),
                                          ),
                                        ),
                                      ),

                                      SizedBox(
                                        height: 2.h,
                                      ),


                                      DecoratedBox(
                                        decoration: ShapeDecoration(
                                          color: AppColors.white1,
                                          shape: RoundedRectangleBorder(
                                            borderRadius: BorderRadius.all(
                                                Radius.circular(2.w)),
                                          ),
                                        ),
                                        child: Container(
                                          decoration: BoxDecoration(
                                              color: AppColors.grey6,
                                              borderRadius:
                                              BorderRadius.circular(
                                                  2.w),
                                              border: Border.all(
                                                  color: AppColors.grey6)),
                                          height: 6.5.h,
                                          width: 90.w,
                                          child:
                                          DropdownButtonHideUnderline(
                                            child: Padding(
                                              padding: EdgeInsets.symmetric(
                                                  horizontal: 2.h),
                                              child: DropdownButton<String>(
                                                elevation: 0,
                                                icon: Icon(
                                                  Icons
                                                      .keyboard_arrow_down_sharp,
                                                  color: AppColors.black1,
                                                ),
                                                value: firstdropDownValue,
                                                dropdownColor:
                                                AppColors.grey5,
                                                items: <String>[
                                                  'Food Category',
                                                  'Select'
                                                ].map((String value) {
                                                  return DropdownMenuItem<
                                                      String>(
                                                    value: value,
                                                    child: Text(
                                                      value,
                                                      style: TextStyle(
                                                          fontSize: 10.sp),
                                                    ),
                                                  );
                                                }).toList(),
                                                onChanged: (value) {
                                                  setState(() {
                                                    firstdropDownValue =
                                                        value;
                                                  });
                                                },
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),

                                      SizedBox(
                                        height: 2.h,
                                      ),

                                      Padding(
                                        padding:  EdgeInsets.only(right: 18.w),
                                        child: Text("Reason (s) given by perpetrator(s) to commit/\njustify the hate crime? ",style: TextStyle(
                                            fontSize: 10.sp,
                                            fontWeight: FontWeight.w500,
                                            color: AppColors.grey5),),
                                      ),
                                      SizedBox(
                                        height: 3.h,
                                      ),
                                      Container(
                                        height: 20.h,
                                        width: 90.w,
                                        decoration: BoxDecoration(
                                            color: AppColors.grey6,
                                            borderRadius:
                                            BorderRadius.circular(2.w),
                                            border: Border.all(
                                                color: AppColors.grey6)),
                                        child: TextFormField(
                                          decoration: InputDecoration(
                                            border: InputBorder.none,
                                            hintText: "     Enter Details",
                                            hintStyle: TextStyle(
                                                fontSize: 10.sp,
                                                fontWeight:
                                                FontWeight.w300,
                                                color: AppColors.black1),
                                          ),
                                        ),
                                      ),

                                      SizedBox(
                                        height: 5.h,
                                      ),

                                      AppButton(
                                        text: "Add Details",
                                        onTap: () {},
                                        backgroundColor: AppColors.red1,
                                        heightsize: 8.h,
                                        widthsize: 90.w,
                                      ),
                                      SizedBox(height: 2.h,)
                                    ],
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ));
                },
              )),


        ],

      ),







    );
  }
}
