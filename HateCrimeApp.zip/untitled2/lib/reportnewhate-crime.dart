import 'package:flutter/material.dart';
import 'package:get/get.dart';

import 'package:sizer/sizer.dart';
import 'package:untitled2/NewHateCrime2.dart';
import 'package:untitled2/Report%20New%20Hate%20-Crime.dart';

import 'package:untitled2/utils/IcIcons.dart';
import 'package:untitled2/utils/colors.dart';

import 'DASHBOARD1.dart';

class ReportNewHateCrime extends StatefulWidget {
  static const route = "/reportNewHateCrime";

  ReportNewHateCrime({Key? key}) : super(key: key);

  @override
  State<ReportNewHateCrime> createState() => _ReportNewHateCrimeState();
}

class _ReportNewHateCrimeState extends State<ReportNewHateCrime> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        elevation: 0.0,
        title: Padding(
          padding: EdgeInsets.only(bottom: 2.5.h),
          child: Text(
            "Report New Hate-Crime",
            style: TextStyle(
              fontSize: 12.sp,
              fontWeight: FontWeight.bold,
              color: AppColors.black1,
            ),
          ),
        ),
        leading: IconButton(
            onPressed: () {Get.to(() => DashBoard1());},
            icon: Icon(Icons.arrow_back,color: AppColors.black1,size: 5.w,)),
        backgroundColor: AppColors.white1,
      ),
      body: SingleChildScrollView(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
        Container(),
SizedBox(height: 3.h,),
        Padding(
          padding:  EdgeInsets.only(right: 16.w),
          child: Text(
            "I am reporting this Hate-Crime against...",
            style: TextStyle(
                fontSize: 11.sp,
                fontWeight: FontWeight.bold,
                color: AppColors.black1),
          ),
        ),
        SizedBox(
          height: 2.h,
        ),
        GestureDetector(
            onTap: () {},
            child: Container(

              width: 90.w,
              height: 7.h,
              decoration: BoxDecoration(
            color: AppColors.litey,
                borderRadius: BorderRadius.circular(8.0),

                border: Border.all(
                  color: AppColors.lite1,
                  width: 0.2.h,
                ),
              ),
              child: Padding(
                padding: EdgeInsets.all(2.h),
                child: Row(
                  children: [
                    GestureDetector(
                      onTap: () {
                        Get.to(() => ReportNewHateCrime2());
                      },
                      child: Text(
                        "ME/MY FAMILY ",
                        style: TextStyle(
                          color: Colors.black87,
                          fontSize: 11.sp,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                    SizedBox(width: 52.w,),
                    Icon(Icons.arrow_forward_ios,size: 4.w,)
                  ],
                ),
              ),
            )),
                SizedBox(
                  height: 3.h,
                ),
                GestureDetector(
                    onTap: () {},
                    child: Container(

                      width: 90.w,
                      height: 7.h,
                      decoration: BoxDecoration(
                      color: AppColors.litey,
                        borderRadius: BorderRadius.circular(8.0),

                        border: Border.all(
                          color: AppColors.lite1,
                          width: 0.2.h,
                        ),
                      ),
                      child: Padding(
                        padding: EdgeInsets.all(2.h),
                        child: Row(
                          children: [
                            GestureDetector(
                              onTap: (){    Get.to(() => ReportNewHateCrime1());},
                              child: Text(
                                "SOMEONE ELSE",
                                style: TextStyle(
                                  color: Colors.black87,
                                  fontSize: 11.sp,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ),
                            SizedBox(width: 51.w,),
                            Icon(Icons.arrow_forward_ios,size: 4.w,)
                          ],
                        ),
                      ),
                    )),
        SizedBox(
          height: 50.h,
        ),
                Container(
                  height: 10.h,
                  width: 90.w,
                  decoration: BoxDecoration(
                    color: AppColors.litey,
                    borderRadius: BorderRadius.circular(2.w)
                  ),
                 
                  child: Padding(
                    padding:  EdgeInsets.only(left: 7.w,),
                    child: Row(
                      children: [
                        RichText(
                          text: TextSpan(
                          text: "Need help ?",style: TextStyle(height: 0.3.h,fontSize: 9.sp,fontWeight: FontWeight.w500,color: AppColors.black1),
                          children: [
                              TextSpan(
                              text: "\nFind suitable speciaslists",style: TextStyle(fontSize: 8.sp,fontWeight: FontWeight.w400,color: AppColors.grey2)
                              )]
                          ),




                            //
                //             


                        ),
                  Padding(
                                  padding:  EdgeInsets.only(left: 40.w,),
                                  child: GestureDetector(
                                    onTap: () {Get.to(() =>ReportNewHateCrime1());},
                                    child: CircleAvatar(
                                      radius: 4.w,
                                        backgroundColor: AppColors.white1,
                                        child: Icon(Icons.arrow_forward,size: 5.w,color: AppColors.black1,)),
                                  ),
                                ),
                      ],
                    ),
                  ),
                ),
                ])
      ),
    );
  }
}
