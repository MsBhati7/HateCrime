import 'package:flutter/material.dart';
class AppColors{
  static const Color white1 = Color(0xffFAFAFB);
  static const Color black1 = Color(0xff000000);
  static const Color grey1 = Color(0xffA4A6AF);
  static const Color grey2 = Color(0xff575E75);
  static const Color red1 = Color(0xffBE182F);
  static const Color grey3 = Color(0xff9E9EA5);
  static const Color grey4 = Color(0xffABADBB);
  static const Color grey5 = Color(0xff585F76);
  static const Color lite1 = Color(0xffE1DAC5);
  static const Color grey6 = Color(0xffF2F3F7);
  static const Color grey7 = Color(0xffF3F4F7);
  static const Color lite2 = Color(0xffA8A8A8);
  static const Color black2 = Color(0xff1B1E23);
  static const Color litey = Color(0xffEEE9DE);
  static const Color orange1 = Color(0xffFB844F);
  static const Color pink1= Color(0xffF95A7E);
  static const Color blue1 = Color(0xff5675E3);
  static const Color dark1 = Color(0xff62646D);
  static const Color orange2 = Color(0xffF99C44);

}