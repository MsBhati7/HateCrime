
class IcIcons{
  static String spalash  = "assets/images/Splash.png";
  static String group  = "assets/images/Group.png";
  static String group1  = "assets/images/group1.png";
  static String ellipse  = "assets/images/Ellipse 162.png";
  static String tick  = "assets/images/greentick.png";
  static String backarrow  = "assets/images/back.png";
  static String eye  = "assets/images/eye.png";
  static String eye1  = "assets/images/eye1.png";
  static String arrow  = "assets/images/red arrow.png";
  static String arrow1  = "assets/images/Vector.png";
  static String logo  = "assets/images/logo.png";
  static String Logo  = "assets/images/Logo red.png";
  static String drop  = "assets/images/drop arrow.png";
  static String profile  = "assets/images/Profile1.png";
  static String phone1  = "assets/images/phone1.png";
  static String mail  = "assets/images/mail.png";
  static String Dash  = "assets/images/dash.png";
  static String Image2 = "assets/images/report1.png";
  static String drop1 = "assets/images/drop arrow.png";
  static String tick4  = "assets/images/greytick.png";
  static String location5 = "assets/images/location1.png";
  static String location6 = "assets/images/location6.png";
  static String Close = "assets/images/cross.png";
  static String tick5  = "assets/images/orangetick.png";
  static String olocation  = "assets/images/orangelocation.png";
  static String orlcg  = "assets/images/loc.png";
  static String dish  = "assets/images/Image2.png";
  static String Forword1  = "assets/images/Forword.png";
  static String move1  = "assets/images/back1.png";
  static String schedule  = "assets/images/schedule icon.png";
  static String Dashb  = "assets/images/dashboard.png";
  static String Forward2  = "assets/images/Forword.png";
  static String arrowfor  = "assets/images/Vector6.png";
  static String Settings1  = "assets/images/settings.png";
  static String phone2  = "assets/images/Fill1.png";
  static String report2  = "assets/images/report2.png";
  static String per  = "assets/images/person4.png";
  static String image3  = "assets/images/rendy.png";
  static String image5  = "assets/images/Plus Button.png";
  static String notify  = "assets/images/schedule icon.png";
  static String notify1  = "assets/images/schedule icon1.png";
  static String arrow3  = "assets/images/back3.png";
  static String arrow4  = "assets/images/back5.png";
  static String tracking1  = "assets/images/tracking.png";
  static String tracking2  = "assets/images/Group 7093.png";
  static String History1 = "assets/images/history1.png";
  static String History2  = "assets/images/history2.png";
  static String History3  = "assets/images/history3.png";
  static String doats1  = "assets/images/threedoats.png";
  static String Numbers1  = "assets/images/1.png";
  static String Numbers2  = "assets/images/2.png";
  static String VideoImage  = "assets/images/video.png";
  static String VoiceImage  = "assets/images/speaker.png";
  static String PhotoImage  = "assets/images/picture.png";
  static String DeleteImage  = "assets/images/delete.png";
  static String backarrow2  = "assets/images/back1.png";
  static String bell1  = "assets/images/bell.png";
  static String Id1  = "assets/images/id.png";
  static String person1  = "assets/images/pro.png";
  static String person4  = "assets/images/cam.png";
  static String redarrow1  = "assets/images/redarrow.png";
  static String Welcome2  = "assets/images/welco.png";
  static String date1  = "assets/images/date.png";



}

