import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:sizer/sizer.dart';
import 'package:untitled2/YourDetails.dart';
import 'package:untitled2/utils/IcIcons.dart';
import 'package:untitled2/utils/colors.dart';
import 'Createnewaccount.dart';
import 'Widgets/appbuttons.dart';

class SignUp3 extends StatefulWidget {
  static const route = "/signUp3";

  SignUp3({Key? key}) : super(key: key);

  @override
  State<SignUp3> createState() => _SignUp3State();
}

class _SignUp3State extends State<SignUp3> {
  bool isYes = false;
  bool isNo = false;
  bool _checkbox = false;

  String? firstdropDownValue = "Food Category";
  String? seconddropDownValue = "Select Option";
  String? mandropDownValue = "Select Option";

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          elevation: 0.0,
          title: Padding(
            padding:  EdgeInsets.only(left: 6.w),
            child: Text(
              " Sign-up for Type 2 Account",
              style: TextStyle(
                fontSize: 12.sp,
                fontWeight: FontWeight.bold,
                color: AppColors.black1,
              ),
            ),
          ),
          leading: IconButton(
              onPressed: () { Get.to(() => CreateNewAccount());},
              icon: Icon(Icons.arrow_back,color: AppColors.black1,size: 5.w,)),
          backgroundColor: AppColors.white1,
        ),
        body: SingleChildScrollView(
            child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,

                children: [

              SizedBox(
                height: 1.h,
              ),
              Text(
                "Create Your Account",
                style: TextStyle(
                    fontSize: 16.sp,
                    fontWeight: FontWeight.bold,
                    color: AppColors.black1),
              ),
              SizedBox(
                height: 1.5.h,
              ),
              Column(crossAxisAlignment: CrossAxisAlignment.center, children: [
                Padding(
                  padding:  EdgeInsets.only(right: 8.w),
                  child: RichText(
                      text: TextSpan(
                          text: "Important:  ",
                          style: TextStyle(
                              fontSize: 10.sp,
                              fontWeight: FontWeight.w500,
                              color: AppColors.black1),
                          children: [
                        TextSpan(
                            text:
                                "Please note that to be able to become a\nType 2 Account holder you will need to dedicate\nsome time for community services and verifying",
                            style:
                                TextStyle(fontSize: 11.sp, color: AppColors.red1))
                      ])),
                ),
                SizedBox(
                  height: 5.h,
                ),
                Padding(
                  padding:  EdgeInsets.only(right: 10.w),
                  child: Text(
                    "Are you willing to invest some time and effort to\nsupport and strengthen your community?      ",
                    style: TextStyle(
                        height: 0.2.h,
                        fontSize: 11.sp,
                        fontWeight: FontWeight.bold,
                        color: AppColors.black1),
                  ),
                ),

        SizedBox(height: 2.h,),
        Padding(
            padding:  EdgeInsets.only(left: 8.w),
            child: Row(mainAxisAlignment: MainAxisAlignment.start, children: [
              Container(
                height: 4.5.h,
                width: 25.w,
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(1.5.w),
                    border: Border.all(color: Colors.grey)),
                child: Row(

                  children: [
                    Checkbox(
                      checkColor: AppColors.grey5,
                      value: isYes,
                      onChanged: (value) {
                        setState(() {
                           isYes = value!;
                           isNo = false;
                        });
                      },
                    ),
                    Text(
                      'Yes',
                      style: TextStyle(fontSize: 8.sp),
                    ),
                  ],
                ),
              ),
              SizedBox(width: 2.5.w,),
              Container(
                height: 4.5.h,
                width: 28.w,
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(1.5.w),
                    border: Border.all(color: Colors.grey)),
                child: Row(
                  children: [
                    Checkbox(
                      checkColor: AppColors.grey5,
                      value: isNo,
                      onChanged: (value) {
                        setState(() {
                           isNo = value!;
                           isYes = false;
                        });
                      },
                    ),
                    Text(
                      'NO',
                      style: TextStyle(fontSize: 8.sp),
                    ),
                  ],
                ),
              ),
                ]),
        ),
                SizedBox(
                  height: 3.5.h,
                ),
                Padding(
                  padding:  EdgeInsets.only(right: 17.w),
                  child: Text(
                    "How much time can you dedicate per week?",
                    style: TextStyle(
                        height: 0.1.h,
                        fontSize: 11.sp,
                        fontWeight: FontWeight.bold,
                        color: AppColors.black1),
                  ),
                ),
                SizedBox(
                  height: 2.h,
                ),
                DecoratedBox(
                  decoration: ShapeDecoration(
                    color: AppColors.white1,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.all(Radius.circular(2.w)),
                    ),
                  ),
                  child: Container(
                    decoration: BoxDecoration(
                        color: AppColors.grey6,
                        borderRadius: BorderRadius.circular(2.w),
                        border: Border.all(color: AppColors.grey6)),
                    height: 6.5.h,
                    width: 90.w,
                    child: DropdownButtonHideUnderline(
                      child: Padding(
                        padding: EdgeInsets.symmetric(horizontal: 2.h),
                        child: DropdownButton<String>(
                          elevation: 0,
                          icon: Icon(
                            Icons.keyboard_arrow_down_sharp,
                            color: AppColors.black1,
                          ),
                          value: seconddropDownValue,
                          dropdownColor: AppColors.grey5,
                          items: <String>['Food Category', 'Select Option']
                              .map((String value) {
                            return DropdownMenuItem<String>(
                              value: value,
                              child: Text(
                                value,
                                style: TextStyle(fontSize: 10.sp),
                              ),
                            );
                          }).toList(),
                          onChanged: (value) {
                            setState(() {
                              seconddropDownValue = value;
                            });
                          },
                        ),
                      ),
                    ),
                  ),
                ),
                SizedBox(
                  height: 2.5.h,
                ),
                Padding(
                  padding: EdgeInsets.only(right: 26.w),
                  child: Text(
                    "Additional Service/Time Commitment",
                    style: TextStyle(
                        height: 0.1.h,
                        fontSize: 11.sp,
                        fontWeight: FontWeight.bold,
                        color: AppColors.black1),
                  ),
                ),
                SizedBox(
                  height: 2.h,
                ),
                DecoratedBox(
                  decoration: ShapeDecoration(
                    color: AppColors.white1,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.all(Radius.circular(2.w)),
                    ),
                  ),
                  child: Container(
                    decoration: BoxDecoration(
                        color: AppColors.grey6,
                        borderRadius: BorderRadius.circular(2.w),
                        border: Border.all(color: AppColors.grey6)),
                    height: 6.5.h,
                    width: 90.w,
                    child: DropdownButtonHideUnderline(
                      child: Padding(
                        padding: EdgeInsets.symmetric(horizontal: 2.h),
                        child: DropdownButton<String>(
                          elevation: 0,
                          icon: Icon(
                            Icons.keyboard_arrow_down_sharp,
                            color: AppColors.black1,
                          ),
                          value: mandropDownValue,
                          dropdownColor: AppColors.grey5,
                          items: <String>['Food Category', 'Select Option']
                              .map((String value) {
                            return DropdownMenuItem<String>(
                              value: value,
                              child: Text(
                                value,
                                style: TextStyle(fontSize: 10.sp),
                              ),
                            );
                          }).toList(),
                          onChanged: (value) {
                            setState(() {
                              mandropDownValue = value;
                            });
                          },
                        ),
                      ),
                    ),
                  ),
                ),
                SizedBox(
                  height: 2.h,
                ),
                Padding(
                  padding: EdgeInsets.only(right: 15.w),
                  child: Text(
                    "Do you confirm to be available to swiftly \nto validate/verify hate-crime reports submitted by\nType 1 users?",
                    style: TextStyle(
                        height: 0.2.h,
                        fontSize: 10.sp,
                        fontWeight: FontWeight.bold,
                        color: AppColors.black1),
                  ),
                ),
                SizedBox(
                  height: 3.h,
                ),
        Padding(
            padding:  EdgeInsets.only(left: 8.w),
            child: Row(mainAxisAlignment: MainAxisAlignment.start, children: [
              Container(
                height: 4.5.h,
                width: 25.w,
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(1.5.w),
                    border: Border.all(color: Colors.grey)),
                child: Row(

                  children: [
                    Checkbox(
                      checkColor: AppColors.grey5,
                      value: _checkbox,
                      onChanged: (value) {
                        setState(() {
                          _checkbox = !_checkbox;
                        });
                      },
                    ),
                    Text(
                      'Yes',
                      style: TextStyle(fontSize: 8.sp),
                    ),
                  ],
                ),
              ),
                ]),),
                SizedBox(
                  height: 4.h,
                ),
                AppButton(
                  text: "NEXT",
                  onTap: () {Get.to(() => YourDetails());},
                  backgroundColor: AppColors.red1,
                  heightsize: 8.h,
                  widthsize: 85.w,
                ),
                SizedBox(
                  height: 10.h,
                ),
                      ])])));
  }
}
