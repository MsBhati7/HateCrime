import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get_navigation/src/root/get_material_app.dart';
import 'package:sizer/sizer.dart';
import 'package:untitled2/AddHouseholdMember.dart';
import 'package:untitled2/Add Household Member.dart';
import 'package:untitled2/AddPerpetrator.dart';
import 'package:untitled2/Alert.dart';
import 'package:untitled2/Bottom2.dart';
import 'package:untitled2/Createnewaccount.dart';
import 'package:untitled2/DASHBOARD1.dart';
import 'package:untitled2/ReportSubmitted.dart';
import 'package:untitled2/Email.dart';
import 'package:untitled2/HousingCharacteristics.dart';
import 'package:untitled2/HousingCensus.dart';
import 'package:untitled2/Myprofile.dart';
import 'package:untitled2/NewHateCrime2.dart';

import 'package:untitled2/Recoverpassword.dart';
import 'package:untitled2/SignUp2.dart';
import 'package:untitled2/SigninMobile.dart';
import 'package:untitled2/EndSession.dart';
import 'package:untitled2/Signup3.dart';
import 'package:untitled2/Verificationcode.dart';
import 'package:untitled2/YourDetails.dart';
import 'package:untitled2/addvictim.dart';
import 'package:untitled2/bottombar.dart';
import 'package:untitled2/Indemnification.dart';
import 'package:untitled2/HousingCensusForm1.dart';
import 'package:untitled2/gridview.dart';
import 'package:untitled2/proclamationform.dart';
import 'package:untitled2/reportnewhate-crime.dart';
import 'package:untitled2/spalash.dart';
import 'package:untitled2/welcome.dart';

import 'Drawer.dart';
import 'Profile.dart';
import 'Report New Hate -Crime.dart';
import 'Reports History.dart';
import 'Settings.dart';
import 'dropdown1.dart';

void main() {
  SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
      statusBarColor: Colors.transparent,
      statusBarIconBrightness: Brightness.dark // status bar color
  ));

  runApp(
    Sizer(builder: (context, orientation, deviceType) {

      return GetMaterialApp(
        debugShowCheckedModeBanner: false,
        theme: ThemeData(fontFamily: 'Poppins'),
        title: "Application",
          initialRoute: Spalash.route,
          routes: {
            Spalash.route: (context) => Spalash(),
            WelcomePage.route: (context) => WelcomePage(),
            SigninMobile.route: (context) => SigninMobile(),
            Email.route: (context) => Email(),
            RecoverPassword.route: (context) => RecoverPassword(),
            CreateNewAccount.route: (context) => CreateNewAccount(),
            VerificationCode.route: (context) => VerificationCode(),
             SignUoType2.route: (context) => SignUoType2(),
            SignUp3.route: (context) => SignUp3(),
            ProclamationForm.route: (context) => ProclamationForm(),
            ReportSubmitted.route: (context) => ReportSubmitted(),
            HousingCensusForm1.route: (context) => HousingCensusForm1(),
            YourDetails.route: (context) => YourDetails(),
            BottomSheet1.route: (context) => BottomSheet1(),
            BottomSheet2.route: (context) => BottomSheet2(),
            GridView1.route: (context) => GridView1(),
            MyTabBar.route: (context) => MyTabBar(),
            MyProfile2.route: (context) => MyProfile2(),
            SignUp2.route: (context) => SignUp2(),
            ReportNewHateCrime.route: (context) => ReportNewHateCrime(),
            AddVictim.route: (context) => AddVictim(),
            AddPerpetrator.route: (context) => AddPerpetrator(),
            AddHouseholdMember.route: (context) => AddHouseholdMember(),
            Housing.route: (context) => Housing(),
            AddMember.route: (context) => AddMember(),
            MyDrawer.route: (context) => MyDrawer(),
            DashBoard1.route: (context) => DashBoard1(),
            HousingCensusForm1.route: (context) => HousingCensusForm1(),
            HousingCensusForm.route: (context) => HousingCensusForm( ),
            Alerts.route: (context) => Alerts( ),
            ReportsHistory.route: (context) => ReportsHistory( ),
            ReportNewHateCrime1.route: (context) => ReportNewHateCrime1( ),
            MyTabBar.route: (context) => MyTabBar( ),

            MyProfile1.route: (context) => MyProfile1( ),
            ReportNewHateCrime2.route: (context) => ReportNewHateCrime2( ),
            Settings.route: (context) => Settings( ),




          },
      );
    }),
  );
}