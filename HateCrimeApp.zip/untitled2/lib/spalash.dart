import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:sizer/sizer.dart';
import 'package:untitled2/welcome.dart';

import '../../Utils/IcIcons.dart';

class Spalash extends StatefulWidget {
  static const route = '/spalash';
  const Spalash({Key? key}) : super(key: key);

  @override
  State<Spalash> createState() => _SpalashState();
}

class _SpalashState extends State<Spalash> {
  void initState() {
    Future.delayed(Duration(seconds: 5), () {
      //This block of code will execute after 3 sec of app launch
      Get.to(WelcomePage());
    });
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        height: MediaQuery.of(context).size.height,
        width: MediaQuery.of(context).size.width,
        child: Image(
          image: AssetImage(IcIcons.spalash),
          fit: BoxFit.fill,
        ),
      ),
    );
  }
}
// import 'package:flutter/material.dart';
// import 'package:get/get.dart';
// import 'package:get/get_core/src/get_main.dart';
// import 'package:sizer/sizer.dart';
// import 'package:untitled2/SigninMobile.dart';
// import 'package:untitled2/utils/IcIcons.dart';
// import 'package:untitled2/welcome.dart';
//
//
// class Spalash extends StatefulWidget {
//   static const route = "/spalash";
//   const Spalash({Key? key}) : super(key: key);
//
//   @override
//   void initState() {
//     Future.delayed(Duration(seconds: 5), () {
//       //This block of code will execute after 3 sec of app launch
//       Get.to(WelcomePage());
//     });
//     super.initState();
//   }
//
//   State<Spalash> createState() => _SpalashState();
// }
//
// class _SpalashState extends State<Spalash> {
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       body: Column(
//         children: [
//           Container(
//             width: 100.w,
// height: 100.h,
//             child:Image.asset(IcIcons.spalash, fit: BoxFit.fill),
//
//       ),
//     ]));
//   }
// }
