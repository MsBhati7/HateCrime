
import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';




class MyTabBar extends StatefulWidget {
  static const route = "/myTabBar";
  const MyTabBar({Key? key}) : super(key: key);

  @override
  State<MyTabBar> createState() => _MyTabBarState();
}

class _MyTabBarState extends State<MyTabBar> {
  int currentIndex = 0;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(),
        bottomNavigationBar: BottomNavigationBar(backgroundColor: Colors.white,
          currentIndex: currentIndex,
          onTap: (index) => setState(() => currentIndex = index),
          items:  [


            BottomNavigationBarItem(
              icon: Icon(Icons.home,color: Colors.deepOrange,size: 8.w,),
              label: "home",





            ),
            BottomNavigationBarItem(

              icon: Icon(Icons.party_mode_outlined,color: Colors.grey,),
              label: "Party",

                backgroundColor: Colors.blue,



            ),
            BottomNavigationBarItem(

              icon: Icon(Icons.party_mode_outlined,color: Colors.grey,size: 14.w,),
              label: "Party",
                backgroundColor: Colors.red,




            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.shopping_cart,color: Colors.grey,),
              label: "Cart",

                backgroundColor: Colors.green,



            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.person,color: Colors.grey,),
              label: "Profile",
              backgroundColor: Colors.deepOrange






            ),
          ],

        ),



        );
  }
}
