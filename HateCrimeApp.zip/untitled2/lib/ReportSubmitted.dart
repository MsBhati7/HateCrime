import 'package:flutter/material.dart';
import 'package:get/get.dart';


import 'package:sizer/sizer.dart';
import 'package:untitled2/Reports%20History.dart';

import 'package:untitled2/utils/IcIcons.dart';
import 'package:untitled2/utils/colors.dart';

import 'DASHBOARD1.dart';
import 'HousingCensusForm1.dart';
import 'Widgets/appbuttons.dart';



class ReportSubmitted extends StatefulWidget {

  static const route = "/reportSubmitted";

  ReportSubmitted({Key? key}) : super(key: key);


  @override
  State<ReportSubmitted> createState() => _ReportSubmittedState();
}

class _ReportSubmittedState extends State<ReportSubmitted> {




  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(

        elevation: 0.0,
        title: Padding(
          padding:  EdgeInsets.only( bottom: 2.5.h),
          child: Text(
            "Reported Submitted",
            style: TextStyle(
              fontSize: 16.sp,
              fontWeight: FontWeight.bold,
              color: AppColors.black1,
            ),
          ),
        ),
        leading: IconButton(
            onPressed: () {},
            icon: Image.asset(IcIcons.Dash,)

        ),

        backgroundColor: AppColors.white1,
      ),


      body: SingleChildScrollView(
          child: Column(children: [
            Container(

            ),


            Image.asset(IcIcons.Image2,height: 20.h,),
            SizedBox(
              height: 4.h,
            ),
            Text(
              "Report Submitted",
              style: TextStyle(fontSize: 20.sp,fontWeight: FontWeight.bold ,color: AppColors.black1),
            ),
            SizedBox(
              height: 5.h,
            ),

                  Padding(
                    padding:  EdgeInsets.only(left: 9.w,right: 5.w),
                    child: Text("  Thank you for submitting a hate-crime report.\nYour report will remain visible online as 'Pending\n  verification'. As soon as it  is verified hte status\nwill change to 'verified'. If the report is not verified\n   by our sources then we will remove the report.\n       Resolved reports are tagged as 'Resolved'",
                        style:TextStyle(
                        fontSize: 10.sp,
                        fontWeight: FontWeight.w500,
                        color: AppColors.grey5)),
                  ),




            SizedBox(height: 7.h,),
           Row(
             mainAxisAlignment: MainAxisAlignment.spaceEvenly,
             children: [

               AppButton(
                 text: "VIEW YOUR REPORT",

                 onTap: () { Get.to(() => HousingCensusForm1());},
                 backgroundColor: AppColors.red1,
                 heightsize: 8.h,
                 widthsize: 45.w,
               ),

               AppButton(
                 text: "EDIT YOUR REPORT",


                 onTap: () {},
                 backgroundColor: AppColors.red1,
                 heightsize: 8.h,
                 widthsize: 45.w,
               ),
             ],
           ),
SizedBox(height: 3.h,),
            AppButton(
              text: "VIEW ALL REPORTS ONLINE",

              onTap: () { Get.to(() => ReportsHistory());},
              backgroundColor: AppColors.red1,
              heightsize: 8.h,
              widthsize: 93.w,
            ),





            SizedBox(height: 3.h,),
            GestureDetector(
                onTap: () {   Get.to(() => ReportsHistory());},
                child: Container(
                  alignment: Alignment.center,
                  width: 92.w,
                  height: 8.h,
                  decoration: BoxDecoration(
                    color: AppColors.litey,
                    borderRadius: BorderRadius.circular(8.0),

                    border: Border.all(
                      color: AppColors.lite1,
                      width: 0.2.h,
                    ),
                  ),
                  child: Padding(
                    padding: EdgeInsets.all(2.h),
                    child: Text(
                      "GO TO DASHBOARD ",
                      style: TextStyle(
                        color: Colors.black87,
                        fontSize: 11.sp,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                )),

          ])),





    );
  }


}
