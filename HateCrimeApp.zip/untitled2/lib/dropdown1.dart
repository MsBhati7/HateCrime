// import 'package:flutter/material.dart';
//
// import 'package:sizer/sizer.dart';
//
//
// import 'package:untitled2/utils/colors.dart';
//
// class DropDown1 extends StatefulWidget {
//   static const route = "/dropDown1";
//
//   DropDown1({Key? key}) : super(key: key);
//
//   @override
//   State<DropDown1> createState() => _DropDown1State();
// }
//
// class _DropDown1State extends State<DropDown1> {
//   String ?valueChoose;
//   List  listItem = [ 'one','one1','one2'];
//
//   String get newItem => null;
//
//
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         elevation: 0.0,
//         title: Padding(
//           padding: EdgeInsets.only(bottom: 2.5.h),
//           child: Text(
//             "Report New Hate-Crime",
//             style: TextStyle(
//               fontSize: 12.sp,
//               fontWeight: FontWeight.bold,
//               color: AppColors.black1,
//             ),
//           ),
//         ),
//         leading: IconButton(
//             onPressed: () {},
//             icon: Icon(Icons.arrow_back)),
//         backgroundColor: AppColors.white1,
//       ),
//       body: Center(
//         child: DropdownButton(
//           value: valueChoose,
//     onChanged: (newValue) {
//       setState(() {
//
// valueChoose = newValue as String?;
//       });
//     },
//         items: listItem.map((valueItem){
//           return DropdownMenuItem(child: Text(newItem),
//           );
//
//         }).toList(),
//         ),
//
//
//
//     )
//     );
//           }
// }
