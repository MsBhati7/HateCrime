import 'package:flutter/material.dart';
import 'package:get/get.dart';

import 'package:sizer/sizer.dart';
import 'package:untitled2/DASHBOARD1.dart';

import 'package:untitled2/utils/IcIcons.dart';
import 'package:untitled2/utils/colors.dart';

import 'Widgets/appbuttons.dart';

class Housing extends StatefulWidget {
  static const route = "/housing";

  Housing({Key? key}) : super(key: key);

  @override
  State<Housing> createState() => _HousingState();
}

class _HousingState extends State<Housing> {
  String? firstdropDownValue = "Food Category";
  String? seconddropDownValue = "Select";
  String? thirddropDownValue = "Food Category";
  String? fourdropDownValue = "Select";
  String? fivedropDownValue = "Food Category";
  String? sixdropDownValue = "Select";
  String? sevendropDownValue = "Food Category";
  String? eightdropDownValue = "Select";
  String? ninedropDownValue = "Food Category";
  String? tendropDownValue = "Select";
  String? elevendropDownValue = "Food Category";
  String? onedropDownValue = "Select";
  String? twodropDownValue = "Food Category";




  bool isOwned = false;
  bool isRented = false;
  bool isOwned1 = false;
  bool isMale = false;
  bool isFemale = false;
  bool  isOther = false;
  bool isRadio = false;
  bool isTv = false;
  bool isNewsPaper = false;
  bool isTelephone = false;
  bool  isMobile = false;
  bool  isComputer = false;
  bool  isYes = false;
  bool  isNo = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        elevation: 0.0,
        title: Row(
          children: [
            Text(
              "Housing Characteristics",
              style: TextStyle(
                fontSize: 16.sp,
                fontWeight: FontWeight.bold,
                color: AppColors.black1,
              ),
            ),
            Padding(
              padding:  EdgeInsets.only(left:12.w),
              child: Image.asset(IcIcons.doats1,width: 1.w,),
            )
          ],
        ),
        leading: IconButton(
            onPressed: () {},
            icon: Image.asset(
              IcIcons.Dash,
            )),
        backgroundColor: AppColors.white1,
      ),
      body: SingleChildScrollView(
          child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
            Padding(
              padding: EdgeInsets.only(right: 82.w),
              child: Text(
                "Tenue",
                style: TextStyle(
                    fontSize: 12.sp,
                    fontWeight: FontWeight.bold,
                    color: AppColors.black1),
              ),
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                Container(
                  height: 4.5.h,
                  width: 28.w,
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(1.5.w),
                      border: Border.all(color: Colors.grey)),
                  child: Row(
                    children: [
                      Checkbox(
                        checkColor: AppColors.grey5,
                        value: isOwned,
                        onChanged: (value) {
                          setState(() {
                            isOwned = value!;
                             isRented = false;
                             isOwned1 = false;
                          });
                        },
                      ),
                      Text(
                        'Owned',
                        style: TextStyle(fontSize: 8.sp),
                      ),
                    ],
                  ),
                ),
                Container(
                  height: 4.5.h,
                  width: 28.w,
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(1.5.w),
                      border: Border.all(color: Colors.grey)),
                  child: Row(
                    children: [
                      Checkbox(
                        checkColor: AppColors.grey5,
                        value: isRented,
                        onChanged: (value) {
                          setState(() {
                            isRented = value!;
                            isOwned = false;
                            isOwned1 = false;
                          });
                        },
                      ),
                      Text(
                        'Rented',
                        style: TextStyle(fontSize: 8.sp),
                      ),
                    ],
                  ),
                ),
                Container(
                  height: 4.5.h,
                  width: 28.w,
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(1.5.w),
                      border: Border.all(color: Colors.grey)),
                  child: Row(
                    children: [
                      Checkbox(
                        checkColor: AppColors.grey5,
                        value: isOwned1,
                        onChanged: (value) {
                          setState(() {
                            isOwned1 = value!;
                            isOwned = false;
                            isRented = false;

                          });
                        },
                      ),
                      Text(
                        'Owned1',
                        style: TextStyle(fontSize: 8.sp),
                      ),
                    ],
                  ),
                ),
              ],
            ),
            Padding(
              padding:  EdgeInsets.only(right: 66.w),
              child: Text("Owner Gender" ,style: TextStyle(
                  fontSize: 12.sp,
                  fontWeight: FontWeight.bold,
                  color: AppColors.black1),),
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                Container(
                  height: 4.5.h,
                  width: 28.w,
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(1.5.w),
                      border: Border.all(color: Colors.grey)),
                  child: Row(
                    children: [
                      Checkbox(
                        checkColor: AppColors.grey6,
                        value: isMale,
                        onChanged: (value) {
                          setState(() {
                            isMale = value!;
                            isFemale = false;
                            isOther = false;
                          });
                        },
                      ),
                      Text(
                        'Male',
                        style: TextStyle(fontSize: 8.sp),
                      ),
                    ],
                  ),
                ),
                Container(
                  height: 4.5.h,
                  width: 25.w,
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(1.5.w),
                      border: Border.all(color: AppColors.grey3,)),
                  child: Row(
                    children: [
                      Checkbox(
                        checkColor: AppColors.grey5,
                        value: isFemale,
                        onChanged: (value) {
                          setState(() {
                            isFemale = value!;
                            isMale = false;
                            isOther = false;
                          });
                        },
                      ),
                      Text(
                        'Female',
                        style: TextStyle(fontSize: 8.sp),
                      ),
                    ],
                  ),
                ),
                Container(
                  height: 4.5.h,
                  width: 25.w,
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(1.5.w),
                      border: Border.all(color: Colors.grey)),
                  child: Row(
                    children: [
                      Checkbox(
                        checkColor: AppColors.grey5,
                        value: isOther,
                        onChanged: (value) {
                          setState(() {
                            isOther = value!;
                            isMale = false;
                            isFemale = false;

                          });
                        },
                      ),
                      Text(
                        'Other',
                        style: TextStyle(fontSize: 8.sp),
                      ),
                    ],
                  ),
                ),
              ],
            ),
            SizedBox(
              height: 2.h,
            ),
            Padding(
              padding: EdgeInsets.only(left: 4.w, right: 31.w),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [Text("Number of Rooms", style: TextStyle(
                    fontSize: 12.sp,
                    fontWeight: FontWeight.bold,
                    color: AppColors.black1),), Text("Year Built", style: TextStyle(
                    fontSize: 12.sp,
                    fontWeight: FontWeight.bold,
                    color: AppColors.black1),)],
              ),
            ),
            SizedBox(
              height: 2.h,
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                Container(
                  height: 6.5.h,
                  width: 45.w,
                  decoration: BoxDecoration(
                      color: AppColors.grey6,
                      borderRadius: BorderRadius.circular(2.w),
                      border: Border.all(color: AppColors.grey6)),
                  child: Padding(
                    padding: EdgeInsets.all(
                      1.5.h,
                    ),
                    child: TextFormField(
                      decoration: InputDecoration(
                        border: InputBorder.none,
                        hintText: "Enter No of Rooms",
                        hintStyle: TextStyle(
                            fontSize: 10.sp,
                            fontWeight: FontWeight.w300,
                            color: AppColors.black1),
                      ),
                    ),
                  ),
                ),
                DecoratedBox(
                  decoration: ShapeDecoration(
                    color: AppColors.white1,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.all(Radius.circular(2.w)),
                    ),
                  ),
                  child: Container(
                    decoration: BoxDecoration(
                        color: AppColors.grey6,
                        borderRadius: BorderRadius.circular(2.w),
                        border: Border.all(color: AppColors.grey6)),
                    height: 6.5.h,
                    width: 45.w,
                    child: DropdownButtonHideUnderline(
                      child: Padding(
                        padding: EdgeInsets.symmetric(horizontal: 2.h),
                        child: DropdownButton<String>(
                          elevation: 0,
                          icon: Icon(
                            Icons.keyboard_arrow_down_sharp,
                            color: AppColors.black1,
                          ),
                          value: seconddropDownValue,
                          dropdownColor: AppColors.grey5,
                          items: <String>['Food Category', 'Select']
                              .map((String value) {
                            return DropdownMenuItem<String>(
                              value: value,
                              child: Text(
                                value,
                                style: TextStyle(fontSize: 10.sp),
                              ),
                            );
                          }).toList(),
                          onChanged: (value) {
                            setState(() {
                              seconddropDownValue = value;
                            });
                          },
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
            SizedBox(
              height: 2.h,
            ),
            Padding(
              padding: EdgeInsets.only(left: 4.w, ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [Text("Construction Material", style: TextStyle(
                    fontSize: 12.sp,
                    fontWeight: FontWeight.bold,
                    color: AppColors.black1),), ],
              ),
            ),
            SizedBox(
              height: 2.h,
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                DecoratedBox(
                  decoration: ShapeDecoration(
                    color: AppColors.white1,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.all(Radius.circular(2.w)),
                    ),
                  ),
                  child: Container(
                    decoration: BoxDecoration(
                        color: AppColors.grey6,
                        borderRadius: BorderRadius.circular(2.w),
                        border: Border.all(color: AppColors.grey6)),
                    height: 6.5.h,
                    width: 45.w,
                    child: DropdownButtonHideUnderline(
                      child: Padding(
                        padding: EdgeInsets.symmetric(horizontal: 2.h),
                        child: DropdownButton<String>(
                          elevation: 0,
                          icon: Icon(
                            Icons.keyboard_arrow_down_sharp,
                            color: AppColors.black1,
                          ),
                          value: elevendropDownValue,
                          dropdownColor: AppColors.grey5,
                          items: <String>['Food Category', 'Select']
                              .map((String value) {
                            return DropdownMenuItem<String>(
                              value: value,
                              child: Text(
                                value,
                                style: TextStyle(fontSize: 10.sp),
                              ),
                            );
                          }).toList(),
                          onChanged: (value) {
                            setState(() {
                              elevendropDownValue = value;
                            });
                          },
                        ),
                      ),
                    ),
                  ),
                ),
                DecoratedBox(
                  decoration: ShapeDecoration(
                    color: AppColors.white1,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.all(Radius.circular(2.w)),
                    ),
                  ),
                  child: Container(
                    decoration: BoxDecoration(
                        color: AppColors.grey6,
                        borderRadius: BorderRadius.circular(2.w),
                        border: Border.all(color: AppColors.grey6)),
                    height: 6.5.h,
                    width: 45.w,
                    child: DropdownButtonHideUnderline(
                      child: Padding(
                        padding: EdgeInsets.symmetric(horizontal: 2.h),
                        child: DropdownButton<String>(
                          elevation: 0,
                          icon: Icon(
                            Icons.keyboard_arrow_down_sharp,
                            color: AppColors.black1,
                          ),
                          value: tendropDownValue,
                          dropdownColor: AppColors.grey5,
                          items: <String>['Food Category', 'Select']
                              .map((String value) {
                            return DropdownMenuItem<String>(
                              value: value,
                              child: Text(
                                value,
                                style: TextStyle(fontSize: 10.sp),
                              ),
                            );
                          }).toList(),
                          onChanged: (value) {
                            setState(() {
                              tendropDownValue = value!;

                            });
                          },
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
            SizedBox(
              height: 2.h,
            ),
            Padding(
              padding: EdgeInsets.only(left: 4.w, ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [Text("Source of Drinking Water", style: TextStyle(
                    fontSize: 12.sp,
                    fontWeight: FontWeight.bold,
                    color: AppColors.black1),), ],
              ),
            ),
            SizedBox(
              height: 2.h,
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                DecoratedBox(
                  decoration: ShapeDecoration(
                    color: AppColors.white1,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.all(Radius.circular(2.w)),
                    ),
                  ),
                  child: Container(
                    decoration: BoxDecoration(
                        color: AppColors.grey6,
                        borderRadius: BorderRadius.circular(2.w),
                        border: Border.all(color: AppColors.grey6)),
                    height: 6.5.h,
                    width: 45.w,
                    child: DropdownButtonHideUnderline(
                      child: Padding(
                        padding: EdgeInsets.symmetric(horizontal: 2.h),
                        child: DropdownButton<String>(
                          elevation: 0,
                          icon: Icon(
                            Icons.keyboard_arrow_down_sharp,
                            color: AppColors.black1,
                          ),
                          value: thirddropDownValue,
                          dropdownColor: AppColors.grey5,
                          items: <String>['Food Category', 'Select']
                              .map((String value) {
                            return DropdownMenuItem<String>(
                              value: value,
                              child: Text(
                                value,
                                style: TextStyle(fontSize: 10.sp),
                              ),
                            );
                          }).toList(),
                          onChanged: (value) {
                            setState(() {
                              thirddropDownValue
                              = value;
                            });
                          },
                        ),
                      ),
                    ),
                  ),
                ),
                DecoratedBox(
                  decoration: ShapeDecoration(
                    color: AppColors.white1,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.all(Radius.circular(2.w)),
                    ),
                  ),
                  child: Container(
                    decoration: BoxDecoration(
                        color: AppColors.grey6,
                        borderRadius: BorderRadius.circular(2.w),
                        border: Border.all(color: AppColors.grey6)),
                    height: 6.5.h,
                    width: 45.w,
                    child: DropdownButtonHideUnderline(
                      child: Padding(
                        padding: EdgeInsets.symmetric(horizontal: 2.h),
                        child: DropdownButton<String>(
                          elevation: 0,
                          icon: Icon(
                            Icons.keyboard_arrow_down_sharp,
                            color: AppColors.black1,
                          ),
                          value: fourdropDownValue,
                          dropdownColor: AppColors.grey5,
                          items: <String>['Food Category', 'Select']
                              .map((String value) {
                            return DropdownMenuItem<String>(
                              value: value,
                              child: Text(
                                value,
                                style: TextStyle(fontSize: 10.sp),
                              ),
                            );
                          }).toList(),
                          onChanged: (value) {
                            setState(() {
                              fourdropDownValue = value;
                            });
                          },
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
            SizedBox(
              height: 2.h,
            ),
            Padding(
              padding: EdgeInsets.only(left: 4.w, right: 40.w),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [Text("Source of Light", style: TextStyle(
                    fontSize: 12.sp,
                    fontWeight: FontWeight.bold,
                    color: AppColors.black1),), Text("Fuel", style: TextStyle(
                    fontSize: 12.sp,
                    fontWeight: FontWeight.bold,
                    color: AppColors.black1),)],
              ),
            ),
            SizedBox(
              height: 2.h,
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                DecoratedBox(
                  decoration: ShapeDecoration(
                    color: AppColors.white1,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.all(Radius.circular(2.w)),
                    ),
                  ),
                  child: Container(
                    decoration: BoxDecoration(
                        color: AppColors.grey6,
                        borderRadius: BorderRadius.circular(2.w),
                        border: Border.all(color: AppColors.grey6)),
                    height: 6.5.h,
                    width: 45.w,
                    child: DropdownButtonHideUnderline(
                      child: Padding(
                        padding: EdgeInsets.symmetric(horizontal: 2.h),
                        child: DropdownButton<String>(
                          elevation: 0,
                          icon: Icon(
                            Icons.keyboard_arrow_down_sharp,
                            color: AppColors.black1,
                          ),
                          value: fivedropDownValue,
                          dropdownColor: AppColors.grey5,
                          items: <String>['Food Category', 'Select']
                              .map((String value) {
                            return DropdownMenuItem<String>(
                              value: value,
                              child: Text(
                                value,
                                style: TextStyle(fontSize: 10.sp),
                              ),
                            );
                          }).toList(),
                          onChanged: (value) {
                            setState(() {
                              fivedropDownValue = value;
                            });
                          },
                        ),
                      ),
                    ),
                  ),
                ),
                DecoratedBox(
                  decoration: ShapeDecoration(
                    color: AppColors.white1,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.all(Radius.circular(2.w)),
                    ),
                  ),
                  child: Container(
                    decoration: BoxDecoration(
                        color: AppColors.grey6,
                        borderRadius: BorderRadius.circular(2.w),
                        border: Border.all(color: AppColors.grey6)),
                    height: 6.5.h,
                    width: 45.w,
                    child: DropdownButtonHideUnderline(
                      child: Padding(
                        padding: EdgeInsets.symmetric(horizontal: 2.h),
                        child: DropdownButton<String>(
                          elevation: 0,
                          icon: Icon(
                            Icons.keyboard_arrow_down_sharp,
                            color: AppColors.black1,
                          ),
                          value: sixdropDownValue,
                          dropdownColor: AppColors.grey5,
                          items: <String>['Food Category', 'Select']
                              .map((String value) {
                            return DropdownMenuItem<String>(
                              value: value,
                              child: Text(
                                value,
                                style: TextStyle(fontSize: 10.sp),
                              ),
                            );
                          }).toList(),
                          onChanged: (value) {
                            setState(() {
                              sixdropDownValue = value;
                            });
                          },
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
            SizedBox(
              height: 2.h,
            ),
            Padding(
              padding: EdgeInsets.only(left: 4.w, right: 35.w),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [Text("Kitchen", style: TextStyle(
                    fontSize: 12.sp,
                    fontWeight: FontWeight.bold,
                    color: AppColors.black1),), Text("Bathroom", style: TextStyle(
                    fontSize: 12.sp,
                    fontWeight: FontWeight.bold,
                    color: AppColors.black1),)],
              ),
            ),
            SizedBox(
              height: 2.h,
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                DecoratedBox(
                  decoration: ShapeDecoration(
                    color: AppColors.white1,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.all(Radius.circular(2.w)),
                    ),
                  ),
                  child: Container(
                    decoration: BoxDecoration(
                        color: AppColors.grey6,
                        borderRadius: BorderRadius.circular(2.w),
                        border: Border.all(color: AppColors.grey6)),
                    height: 6.5.h,
                    width: 45.w,
                    child: DropdownButtonHideUnderline(
                      child: Padding(
                        padding: EdgeInsets.symmetric(horizontal: 2.h),
                        child: DropdownButton<String>(
                          elevation: 0,
                          icon: Icon(
                            Icons.keyboard_arrow_down_sharp,
                            color: AppColors.black1,
                          ),
                          value: sevendropDownValue,
                          dropdownColor: AppColors.grey5,
                          items: <String>['Food Category', 'Select']
                              .map((String value) {
                            return DropdownMenuItem<String>(
                              value: value,
                              child: Text(
                                value,
                                style: TextStyle(fontSize: 10.sp),
                              ),
                            );
                          }).toList(),
                          onChanged: (value) {
                            setState(() {
                              sevendropDownValue = value;
                            });
                          },
                        ),
                      ),
                    ),
                  ),
                ),
                DecoratedBox(
                  decoration: ShapeDecoration(
                    color: AppColors.white1,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.all(Radius.circular(2.w)),
                    ),
                  ),
                  child: Container(
                    decoration: BoxDecoration(
                        color: AppColors.grey6,
                        borderRadius: BorderRadius.circular(2.w),
                        border: Border.all(color: AppColors.grey6)),
                    height: 6.5.h,
                    width: 45.w,
                    child: DropdownButtonHideUnderline(
                      child: Padding(
                        padding: EdgeInsets.symmetric(horizontal: 2.h),
                        child: DropdownButton<String>(
                          elevation: 0,
                          icon: Icon(
                            Icons.keyboard_arrow_down_sharp,
                            color: AppColors.black1,
                          ),
                          value: eightdropDownValue,
                          dropdownColor: AppColors.grey5,
                          items: <String>['Food Category', 'Select']
                              .map((String value) {
                            return DropdownMenuItem<String>(
                              value: value,
                              child: Text(
                                value,
                                style: TextStyle(fontSize: 10.sp),
                              ),
                            );
                          }).toList(),
                          onChanged: (value) {
                            setState(() {
                             eightdropDownValue = value;
                            });
                          },
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
            SizedBox(
              height: 2.h,
            ),

            Padding(
              padding: EdgeInsets.only(left: 4.w, right: 35.w),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text("Latrine", style: TextStyle(
                      fontSize: 12.sp,
                      fontWeight: FontWeight.bold,
                      color: AppColors.black1),),
                ],
              ),
            ),
            SizedBox(
              height: 2.h,
            ),
            Padding(
              padding:  EdgeInsets.only(left: 4.w),
              child: Row(mainAxisAlignment: MainAxisAlignment.start, children: [
                DecoratedBox(
                  decoration: ShapeDecoration(
                    color: AppColors.white1,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.all(Radius.circular(2.w)),
                    ),
                  ),
                  child: Container(
                    decoration: BoxDecoration(
                        color: AppColors.grey6,
                        borderRadius: BorderRadius.circular(2.w),
                        border: Border.all(color: AppColors.grey6)),
                    height: 6.5.h,
                    width: 45.w,
                    child: DropdownButtonHideUnderline(
                      child: Padding(
                        padding: EdgeInsets.symmetric(horizontal: 2.h),
                        child: DropdownButton<String>(
                          elevation: 0,
                          icon: Icon(
                            Icons.keyboard_arrow_down_sharp,
                            color: AppColors.black1,
                          ),
                          value: ninedropDownValue,
                          dropdownColor: AppColors.grey5,
                          items: <String>['Food Category', 'Select']
                              .map((String value) {
                            return DropdownMenuItem<String>(
                              value: value,
                              child: Text(
                                value,
                                style: TextStyle(fontSize: 10.sp),
                              ),
                            );
                          }).toList(),
                          onChanged: (value) {
                            setState(() {
                              ninedropDownValue = value;
                            });
                          },
                        ),
                      ),
                    ),
                  ),
                ),
              ]),
            ),
            Padding(
              padding:  EdgeInsets.only(right: 22.w),
              child: Text("Means of Information/Communication", style: TextStyle(
                  fontSize: 12.sp,
                  fontWeight: FontWeight.bold,
                  color: AppColors.black1),),
            ),
                SizedBox(height: 2.5.h,),
            Padding(
              padding:  EdgeInsets.only(left: 5.w),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  Container(
                    height: 4.5.h,
                    width: 28.w,
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(1.5.w),
                        border: Border.all(color: Colors.grey)),
                    child: Row(
                      children: [
                        Checkbox(
                          checkColor: AppColors.grey5,
                          value: isRadio,
                          onChanged: (value) {
                            setState(() {
                               isRadio = value!;
                               isTv = false;
                               isNewsPaper = false;
                               isTelephone = false;
                                isMobile = false;
                                isComputer = false;

                            });
                          },
                        ),
                        Text(
                          'Radio',
                          style: TextStyle(fontSize: 8.sp),
                        ),
                      ],
                    ),
                  ),
                  SizedBox(width: 2.5.w,),
                  Container(
                    height: 4.5.h,
                    width: 28.w,
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(1.5.w),
                        border: Border.all(color: Colors.grey)),
                    child: Row(
                      children: [
                        Checkbox(
                          checkColor: AppColors.grey5,
                          value: isTv,
                          onChanged: (value) {
                            setState(() {

                              isTv = value!;
                              isRadio = false;
                              isNewsPaper = false;
                             isTelephone = false;
                               isMobile = false;
                            isComputer = false;

                            });
                          },
                        ),
                        Text(
                          'T.V.',
                          style: TextStyle(fontSize: 8.sp),
                        ),
                      ],
                    ),
                  ),
                  SizedBox(width: 2.5.w,),
                  Container(
                    height: 4.5.h,
                    width: 28.w,
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(1.5.w),
                        border: Border.all(color: Colors.grey)),
                    child: Row(
                      children: [
                        Checkbox(
                          checkColor: AppColors.grey5,
                          value: isNewsPaper,
                          onChanged: (value) {
                            setState(() {



                              isNewsPaper = value!;
                              isRadio = false;
                               isTv = false;
                              isTelephone = false;
                              isMobile = false;
                              isComputer = false;

                            });
                          },
                        ),
                        Text(
                          'News',
                          style: TextStyle(fontSize: 8.sp),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
                SizedBox(height: 2.h,),
            Padding(
              padding:  EdgeInsets.only(left: 5.w),
              child: Row(mainAxisAlignment: MainAxisAlignment.start, children: [
                Container(
                  height: 4.5.h,
                  width: 28.w,
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(1.5.w),
                      border: Border.all(color: Colors.grey)),
                  child: Row(

                    children: [
                      Checkbox(
                        checkColor: AppColors.grey5,
                        value: isTelephone,
                        onChanged: (value) {
                          setState(() {


                            isTelephone = value!;
                            isRadio = false;
                            isTv = false;
                            isNewsPaper = false;
                            isMobile = false;
                            isComputer = false;
                          });
                        },
                      ),
                      Text(
                        'Telephone',
                        style: TextStyle(fontSize: 6.sp),
                      ),
                    ],
                  ),
                ),
                SizedBox(width: 5.w,),
                Container(
                  height: 4.5.h,
                  width: 28.w,
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(1.5.w),
                      border: Border.all(color: Colors.grey)),
                  child: Row(
                    children: [
                      Checkbox(
                        checkColor: AppColors.grey5,
                        value: isMobile,
                        onChanged: (value) {
                          setState(() {


                            isMobile = value!;
                            isRadio = false;
                            isTv = false;
                            isTelephone = false;
                            isNewsPaper = false;
                            isComputer = false;
                          });
                        },
                      ),
                      Text(
                        'Mobile',
                        style: TextStyle(fontSize: 8.sp),
                      ),
                    ],
                  ),
                ),
              ]),
            ),
                SizedBox(height: 2.h,),
            Padding(
              padding:  EdgeInsets.only(left: 5.w),
              child: Row(mainAxisAlignment: MainAxisAlignment.start, children: [
                Container(
                  height: 4.5.h,
                  width: 28.w,
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(1.5.w),
                      border: Border.all(color: Colors.grey)),
                  child: Row(
                    children: [
                      Checkbox(
                        checkColor: AppColors.grey5,
                        value: isComputer,
                        onChanged: (value) {
                          setState(() {


                            isComputer = value!;
                            isRadio = false;
                            isTv = false;
                            isTelephone = false;
                            isMobile = false;
                            isMobile = false;
                          });
                        },
                      ),
                      Text(
                        'Computer/',
                        style: TextStyle(fontSize: 6.sp),
                      ),
                    ],
                  ),
                ),
              ]),
            ),
                SizedBox(height: 2.h,),
                Padding(
                  padding:  EdgeInsets.only(right: 14.w),
                  child: Text("Has ant household Member/s Lived Abroad\nfor 6 Months or more ?", style: TextStyle(
                      fontSize: 12.sp,
                      fontWeight: FontWeight.bold,
                      color: AppColors.black1),),
                ),
                SizedBox(height: 2.h,),
                Padding(
                  padding:  EdgeInsets.only(left: 4.5.w),
                  child: Row(mainAxisAlignment: MainAxisAlignment.start, children: [
                    Container(
                      height: 4.5.h,
                      width: 28.w,
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(1.5.w),
                          border: Border.all(color: Colors.grey)),
                      child: Row(
                        children: [
                          Checkbox(
                            checkColor: AppColors.grey5,
                            value: isYes,
                            onChanged: (value) {
                              setState(() {
                                  isYes = value!;
                                  isNo = false;
                              });
                            },
                          ),
                          Text(
                            'Yes',
                            style: TextStyle(fontSize: 8.sp),
                          ),
                        ],
                      ),
                    ),
                    SizedBox(width: 2.5.w,),
                    Container(
                      height: 4.5.h,
                      width: 28.w,
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(1.5.w),
                          border: Border.all(color: Colors.grey)),
                      child: Row(
                        children: [
                          Checkbox(
                            checkColor: AppColors.grey5,
                            value: isNo,
                            onChanged: (value) {
                              setState(() {
                                isNo = value!;
                                isYes = false;

                              });
                            },
                          ),
                          Text(
                            'NO',
                            style: TextStyle(fontSize: 8.sp),
                          ),
                        ],
                      ),
                    ),

                  ]),
                ),
                SizedBox(height: 2.h,),
Padding(
  padding:  EdgeInsets.only(right: 61.w),
  child:   Text("If 'Yes' Give Number ",style: TextStyle(
      fontSize: 10.sp,
      fontWeight: FontWeight.bold,
      )),
),
                SizedBox(
                  height: 2.h,
                ),
                Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly, children: [
                  DecoratedBox(
                    decoration: ShapeDecoration(
                      color: AppColors.white1,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.all(Radius.circular(2.w)),
                      ),
                    ),
                    child: Container(
                      decoration: BoxDecoration(
                          color: AppColors.grey6,
                          borderRadius: BorderRadius.circular(2.w),
                          border: Border.all(color: AppColors.grey6)),
                      height: 6.5.h,
                      width: 45.w,
                      child: DropdownButtonHideUnderline(
                        child: Padding(
                          padding: EdgeInsets.symmetric(horizontal: 2.h),
                          child: DropdownButton<String>(
                            elevation: 0,
                            icon: Icon(
                              Icons.keyboard_arrow_down_sharp,
                              color: AppColors.black1,
                            ),
                            value: onedropDownValue,
                            dropdownColor: AppColors.grey5,
                            items: <String>['Food Category', 'Select']
                                .map((String value) {
                              return DropdownMenuItem<String>(
                                value: value,
                                child: Text(
                                  value,
                                  style: TextStyle(fontSize: 10.sp),
                                ),
                              );
                            }).toList(),
                            onChanged: (value) {
                              setState(() {
                                onedropDownValue = value!;

                              });
                            },
                          ),
                        ),
                      ),
                    ),
                  ),
                  DecoratedBox(
                    decoration: ShapeDecoration(
                      color: AppColors.white1,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.all(Radius.circular(2.w)),
                      ),
                    ),
                    child: Container(
                      decoration: BoxDecoration(
                          color: AppColors.grey6,
                          borderRadius: BorderRadius.circular(2.w),
                          border: Border.all(color: AppColors.grey6)),
                      height: 6.5.h,
                      width: 45.w,
                      child: DropdownButtonHideUnderline(
                        child: Padding(
                          padding: EdgeInsets.symmetric(horizontal: 2.h),
                          child: DropdownButton<String>(
                            elevation: 0,
                            icon: Icon(
                              Icons.keyboard_arrow_down_sharp,
                              color: AppColors.black1,
                            ),
                            value: twodropDownValue,
                            dropdownColor: AppColors.grey5,
                            items: <String>['Food Category', 'Select']
                                .map((String value) {
                              return DropdownMenuItem<String>(
                                value: value,
                                child: Text(
                                  value,
                                  style: TextStyle(fontSize: 10.sp),
                                ),
                              );
                            }).toList(),
                            onChanged: (value) {
                              setState(() {
                                twodropDownValue = value;
                              });
                            },
                          ),
                        ),
                      ),
                    ),
                  ),
                ]),
                SizedBox(height: 2.h,),
                Padding(
                  padding:  EdgeInsets.only(right: 43.w),
                  child: Text("Name of Head/Respondent", style: TextStyle(
                      fontSize: 12.sp,
                      fontWeight: FontWeight.bold,
                      color: AppColors.black1),),
                ),
            Container(
              width: 90.w,
              height: 15.h,
              decoration: BoxDecoration(
              color: AppColors.grey6,
                borderRadius: BorderRadius.circular(7.w)
              ),
              child: TextFormField(
                decoration: InputDecoration(
                    border: InputBorder.none,
contentPadding: EdgeInsets.only(left: 4.w),
                  hintText: "Enter Head/Respondent Name"
                ),
              ),
            ),
            SizedBox(
              height: 4.h,
            ),
            AppButton(
              text: "SUBMIT",
              onTap: () {Get.to(() =>  DashBoard1());},
              backgroundColor: AppColors.red1,
              heightsize: 9.h,
              widthsize: 93.w,
            ),
            SizedBox(
              height: 10.h,
            ),
          ])),
    );
  }
}
