import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:otp_text_field/otp_field.dart';
import 'package:otp_text_field/style.dart';

import 'package:sizer/sizer.dart';
import 'package:untitled2/Createnewaccount.dart';
import 'package:untitled2/Profile.dart';
import 'package:untitled2/Signup3.dart';
import 'package:untitled2/utils/IcIcons.dart';
import 'package:untitled2/utils/colors.dart';

import 'Widgets/appbuttons.dart';

class ProclamationForm extends StatelessWidget {
  static const route = "/proclamationForm";

  bool _checkbox = false;
  String? firstdropDownValue = "Food Category";
  String? seconddropDownValue = "Select";
  DateTime date = DateTime(2022, 12, 24);

  var DatePicker;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          elevation: 0.0,
          title: Padding(
            padding: EdgeInsets.only(left: 8.w),
            child: Text(
              "Proclamation Form",
              style: TextStyle(
                fontSize: 14.sp,
                fontWeight: FontWeight.bold,
                color: AppColors.grey2,
              ),
            ),
          ),
          leading: IconButton(
              onPressed: () { Get.to(() => CreateNewAccount());},
              icon: Icon(Icons.arrow_back,color: AppColors.black1,size: 5.w,)),
          backgroundColor: AppColors.white1,
        ),
        body: SingleChildScrollView(
          child: SizedBox(
            height: 100.h,
            child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  Container(),

                  Text(
                    " Confession of Christian Faith ",
                    style: TextStyle(
                        fontSize: 17.sp,
                        fontWeight: FontWeight.bold,
                        color: AppColors.black1),
                  ),


                  SizedBox(
                    height: 1.5.h,
                  ),
                  Text(
                    "I believe with all my heart that Load Jesus Christ is\nthe Son of the living Almighty GOD.\nI believe with all my heart that Lord Jesus Christ\nDied on the cross for my sms and resurrected from\nthe dead.\nI believe with all my heart that through His death\nand resurrection, Lord Jesus Christ bore in my place\n the punishment of my sin and opened the door for\nmy salavation so that i become the heir of eternal life\nis the Kingdom of God",
                    style: TextStyle(

                        fontSize: 11.5.sp,
                        fontWeight: FontWeight.w500,
                        color: AppColors.grey2),
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text("Full Name",style: TextStyle(
                          fontSize: 10.sp,
                          fontWeight: FontWeight.w400,
                          color: AppColors.grey2),),
                      Container(
                        alignment: Alignment.center,
                        height: 8.h,
                        width: 60.w,
                        decoration: BoxDecoration(
                            color: AppColors.grey7,
                            borderRadius: BorderRadius.circular(3.w)
                        ),
                        child: TextFormField(
                          keyboardType: TextInputType.emailAddress,

                          decoration: InputDecoration(
                              hintText: "Email Address",
                              border: InputBorder.none,
                              focusedBorder: InputBorder.none,
                              enabledBorder: InputBorder.none,
                              errorBorder: InputBorder.none,
                              disabledBorder: InputBorder.none,
                              hintStyle: TextStyle(
                                  fontSize: 14.sp,
                                  fontWeight: FontWeight.w500,
                                  color: AppColors.grey4),
                              contentPadding: EdgeInsets.only(left: 5.w)
                          ),
                        ),
                      ),
                    ],
                  ),
   // adb devices
                  // 8c54f29d	device
                  // 8c54f29d


                  Row(
                    children: [
                      Padding(
                        padding: EdgeInsets.only( bottom: 8.h),
                        child: Checkbox(

                          checkColor: AppColors.grey5,
                          value: _checkbox,
                          onChanged: (value) {
                            setState(() {
                              _checkbox = !_checkbox;
                            });
                          },
                        ),
                      ),
                      Text(
                        'By checking this box and writing my full name\nhereunder, I solemnly affirm without ant coercion or\nmis-understanding and being in my full senses,that I\nfully believe in the above statements central to my\n Christian faith and that I am a true',
                        style: TextStyle(
                            fontSize: 10.sp,
                            fontWeight: FontWeight.w500,
                            color: AppColors.grey5),
                      ),
                    ],
                  ),
                  SizedBox(
                    height: 2.h,
                  ),
                  AppButton(
                    text: "GENERATE VERIFICATION CODE",
                    onTap: () {},
                    backgroundColor: AppColors.red1,
                    heightsize: 8.h,
                    widthsize: 88.w,
                  ),
                  SizedBox(
                    height: 2.h,
                  ),
                  Text("ENTER VERIFICATION CODE RECEIVED",
                      style: TextStyle(
                          fontSize: 8.sp,
                          fontWeight: FontWeight.bold,
                          color: AppColors.grey2)),
                  SizedBox(
                    height: 2.h,
                  ),
                  Container(
                    width: 60.w,
                    child: OTPTextField(

                      length: 4,
                      fieldWidth: 12.w,
                      style: TextStyle(fontSize: 14.sp),
                      textFieldAlignment: MainAxisAlignment.spaceAround,
                      fieldStyle: FieldStyle.box,
                      onCompleted: (pin) {
                        print("Completed: " + pin);
                      },
                    ),
                  ),
                  SizedBox(
                    height: 2.h,
                  ),
                  Container(
                    child: Column(
                      children: [
                        AppButton(
                          text: "NEXT",
                          onTap: () {
                            showModalBottomSheet(context: context,
                            shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.vertical(
                            top: Radius.circular(5.w)
                            )
                            ),
                                builder: (context) => Center(
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.center,
                                    children: [

                                      SizedBox(height: 4.h,),
                                      Row(
                                        children: [
                                          Padding(
                                            padding:  EdgeInsets.only(left: 7.w),
                                            child: Text("About Indemnification\nof COMMUNION",
                                              style: TextStyle(
                                                  fontSize: 16.sp,
                                                  fontWeight: FontWeight.w500,
                                                  color: AppColors.black1),

                                            ),
                                          ),
                                          Padding(
                                            padding: EdgeInsets.only(left:25.w,bottom: 2.h),
                                            child: CircleAvatar(
                                              radius: 5.w,
                                              backgroundColor: AppColors.litey,
                                              child: Icon(Icons.close,color: AppColors.black1,),
                                            ),
                                          )
                                        ],
                                      ),
                                      SizedBox(height: 5.h,),
                                      Row(
                                        children: [
                                          Padding(
                                            padding: EdgeInsets.only( bottom: 11.h),
                                            child: Checkbox(
                                              checkColor: AppColors.grey5,
                                              value: _checkbox,
                                              onChanged: (value) {
                                                setState(() {
                                                  _checkbox = !_checkbox;
                                                });
                                              },
                                            ),
                                          ),

                                          Text(
                                            'If in really I am not a Christian and I still\nprocess to make an account by agreeing to\nthe above creed of Christian faith, I\nunderstand that I will be solely responsible for\nany and all legal, criminal\nconsequences, for which COMMUNION shall',
                                            style: TextStyle(
                                                fontSize: 11.sp,
                                                fontWeight: FontWeight.w500,
                                                color: AppColors.grey5),
                                          ),
                                        ],
                                      ),
                                      SizedBox(height: 9.h,),

                                      Padding(
                                        padding: const EdgeInsets.all(8.0),
                                        child: AppButton(
                                          text: "CONTINUE",
                                          onTap: () {Get.to(() => CreateNewAccount());},
                                          backgroundColor: AppColors.red1,
                                          heightsize: 8.h,
                                          widthsize: 90.w,
                                        ),
                                      ),
                                    ],
                                  ),
                                ));
                          },
                          backgroundColor: AppColors.red1,
                          heightsize: 8.h,
                          widthsize: 88.w,
                        ),
                      ],

                    ),
                  ),
                  SizedBox(
                    height: 1.h,
                  ),
                  Text("DID NOT RECEIVE VERIFICATION CODE?",
                      style: TextStyle(
                          fontSize: 9.sp,
                          fontWeight: FontWeight.bold,
                          color: AppColors.grey2)),
                  SizedBox(
                    height: 1.5.h,
                  ),
                  GestureDetector(
                      onTap: () {},
                      child: Container(
                        alignment: Alignment.center,
                        width: 45.w,
                        height: 5.h,
                        decoration: BoxDecoration(
color: AppColors.grey7,
                          borderRadius: BorderRadius.circular(1.5.w),

                          border: Border.all(
                            color: AppColors.red1,
                            width: 0.2.w,
                          ),
                        ),
                        child: Text(
                          "RESEND VERIFICATION CODE ",
                          style: TextStyle(
                            color: Colors.black,
                            fontSize: 8.sp,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      )),
                  SizedBox(
                    height: 2.h,
                  ),

                ]),
          ),
        ));
  }

  void setState(Null Function() param0) {}

  DatePickerWidget({required bool looping, required DateTime firstDate, required DateTime lastDate, required DateTime initialDate, required String dateFormat, required locale, required DateTime Function(DateTime newDate, dynamic _) onChange, required pickerTheme}) {}
}
// ElevatedButton( child: Text("Open Bottom Sheet"),
// onPressed: () {
// showModalBottomSheet(context: context,
// shape: RoundedRectangleBorder(
// borderRadius: BorderRadius.vertical(
// top: Radius.circular(5.w)
// )
// ),
// builder: (context) => Center(
// child: ElevatedButton(
// child: Text('close'),
// onPressed: () => Navigator.pop(context),
// ),
// )
