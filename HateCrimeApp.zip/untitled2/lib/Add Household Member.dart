import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';
import 'package:untitled2/Widgets/appbuttons.dart';
import 'package:untitled2/utils/IcIcons.dart';

import 'package:untitled2/utils/colors.dart';

class AddMember extends StatefulWidget {
  static const route = "/addMember";

  AddMember({Key? key}) : super(key: key);

  @override
  State<AddMember> createState() => _AddMemberState();
}

class _AddMemberState extends State<AddMember> {
  String? firstdropDownValue = "Food Category";
  String? seconddropDownValue = "Select";
  bool _checkbox = false;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
              child: ElevatedButton(
            child: Text("Open Bottom Sheet"),
            onPressed: () {
              showModalBottomSheet(
                  context: context,
                  shape: RoundedRectangleBorder(
                      borderRadius:
                          BorderRadius.vertical(top: Radius.circular(5.w))),
                  builder: (context) => Container(
                    

                        decoration: BoxDecoration(
                          color: AppColors.lite1,
                          borderRadius: BorderRadius.only(
                              topRight: Radius.circular(5.w),
                              topLeft: Radius.circular(5.w)),
                        ),
                        child: Stack(
                          children: [
                            Padding(
                              padding: EdgeInsets.only(top: 3.h),
                              child: SingleChildScrollView(
                                child: Container(
                                  decoration: BoxDecoration(
                                    color: AppColors.white1,
                                    borderRadius: BorderRadius.only(
                                        topRight: Radius.circular(5.w),
                                        topLeft: Radius.circular(5.w)),
                                  ),
                                  height: 130.h,
                                  child: Column(
                                    children: [
                                      SizedBox(height: 2.h,),
                                      Row(
                                        children: [
                                          Text("     Add Household Member",style: TextStyle(
                                          fontSize: 13.sp,
fontWeight: FontWeight.bold,
                                          color: AppColors.black1)),
                                          Padding(
                                            padding:  EdgeInsets.only(left: 35.w),
                                            child: CircleAvatar(
                                              backgroundColor: AppColors.white1,
                                              child:
                                             Icon(Icons.close,color: AppColors.black1,)
                                            ),
                                          )
                                        ],
                                      ),

                                      Padding(
                                        padding:  EdgeInsets.only(right: 45
                                            .w),
                                        child: Text("Household Member Name",
                                            style: TextStyle(
                                                fontSize: 11.sp,

                                                color: AppColors.grey1)),
                                      ),
SizedBox(height: 2.h,),
                                      SingleChildScrollView(
                                        child: Container(
                                          height: 6.5.h,
                                          width: 90.w,
                                          decoration: BoxDecoration(
                                              color: AppColors.grey6,
                                              borderRadius:
                                              BorderRadius.circular(2.w),
                                              border: Border.all(
                                                  color: AppColors.grey6)),
                                          child: Padding(
                                            padding: EdgeInsets.all(
                                              1.5.h,
                                            ),
                                            child: TextFormField(
                                              decoration: InputDecoration(
                                                border: InputBorder.none,
                                                hintText: "Sarah M. Holiday",
                                                hintStyle: TextStyle(
                                                    fontSize: 10.sp,
                                                    fontWeight:
                                                    FontWeight.w300,
                                                    color: AppColors.black1),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                      SizedBox(height: 2.h,),
                                      Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.spaceEvenly,
                                        children: [
                                          Text(
                                            "Relation with head                  ",
                                            style: TextStyle(
                                                fontSize: 10.sp,
                                                fontWeight: FontWeight.w300,
                                                color: AppColors.grey5),
                                          ),

                                          Text(
                                            "Marital Status                           ",
                                            style: TextStyle(
                                                fontSize: 10.sp,
                                                fontWeight: FontWeight.w300,
                                                color: AppColors.grey5),
                                          )
                                        ],
                                      ),
                                      SizedBox(height: 2.h,),
                                      Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.spaceEvenly,
                                        children: [
                                          DecoratedBox(
                                            decoration: ShapeDecoration(
                                              color: AppColors.white1,
                                              shape: RoundedRectangleBorder(
                                                borderRadius: BorderRadius.all(
                                                    Radius.circular(2.w)),
                                              ),
                                            ),
                                            child: Container(
                                              decoration: BoxDecoration(
                                                  color: AppColors.grey6,
                                                  borderRadius:
                                                      BorderRadius.circular(
                                                          2.w),
                                                  border: Border.all(
                                                      color: AppColors.grey6)),
                                              height: 6.5.h,
                                              width: 45.w,
                                              child:
                                                  DropdownButtonHideUnderline(
                                                child: Padding(
                                                  padding: EdgeInsets.symmetric(
                                                      horizontal: 2.h),
                                                  child: DropdownButton<String>(
                                                    elevation: 0,
                                                    icon: Icon(
                                                      Icons
                                                          .keyboard_arrow_down_sharp,
                                                      color: AppColors.black1,
                                                    ),
                                                    value: seconddropDownValue,
                                                    dropdownColor:
                                                        AppColors.grey5,
                                                    items: <String>[
                                                      'Food Category',
                                                      'Select'
                                                    ].map((String value) {
                                                      return DropdownMenuItem<
                                                          String>(
                                                        value: value,
                                                        child: Text(
                                                          value,
                                                          style: TextStyle(
                                                              fontSize: 10.sp),
                                                        ),
                                                      );
                                                    }).toList(),
                                                    onChanged: (value) {
                                                      setState(() {
                                                        firstdropDownValue =
                                                            value;
                                                      });
                                                    },
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ),
                                          DecoratedBox(
                                            decoration: ShapeDecoration(
                                              color: AppColors.white1,
                                              shape: RoundedRectangleBorder(
                                                borderRadius: BorderRadius.all(
                                                    Radius.circular(2.w)),
                                              ),
                                            ),
                                            child: Container(
                                              decoration: BoxDecoration(
                                                  color: AppColors.grey6,
                                                  borderRadius:
                                                      BorderRadius.circular(
                                                          2.w),
                                                  border: Border.all(
                                                      color: AppColors.grey6)),
                                              height: 6.5.h,
                                              width: 45.w,
                                              child:
                                                  DropdownButtonHideUnderline(
                                                child: Padding(
                                                  padding: EdgeInsets.symmetric(
                                                      horizontal: 2.h),
                                                  child: DropdownButton<String>(
                                                    elevation: 0,
                                                    icon: Icon(
                                                      Icons
                                                          .keyboard_arrow_down_sharp,
                                                      color: AppColors.black1,
                                                    ),
                                                    value: seconddropDownValue,
                                                    dropdownColor:
                                                        AppColors.grey5,
                                                    items: <String>[
                                                      'Food Category',
                                                      'Select'
                                                    ].map((String value) {
                                                      return DropdownMenuItem<
                                                          String>(
                                                        value: value,
                                                        child: Text(
                                                          value,
                                                          style: TextStyle(
                                                              fontSize: 10.sp),
                                                        ),
                                                      );
                                                    }).toList(),
                                                    onChanged: (value) {
                                                      setState(() {
                                                        firstdropDownValue =
                                                            value;
                                                      });
                                                    },
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                      SizedBox(
                                        height: 2.h,
                                      ),
                                      Padding(
                                        padding: EdgeInsets.only(
                                            left: 4.w, right: 23.w),
                                        child: Row(
                                          mainAxisAlignment:
                                              MainAxisAlignment.spaceBetween,
                                          children: [
                                            Text(
                                              "Member Age",
                                              style: TextStyle(
                                                  fontSize: 10.sp,
                                                  fontWeight: FontWeight.w300,
                                                  color: AppColors.grey5),
                                            ),
                                            Text(
                                              "Member Gender",
                                              style: TextStyle(
                                                  fontSize: 10.sp,
                                                  fontWeight: FontWeight.w300,
                                                  color: AppColors.grey5),
                                            )
                                          ],
                                        ),
                                      ),

                                      SizedBox(height: 2.h,),
                                      Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.spaceEvenly,
                                        children: [
                                          Container(
                                            height: 6.5.h,
                                            width: 45.w,
                                            decoration: BoxDecoration(
                                                color: AppColors.grey6,
                                                borderRadius:
                                                    BorderRadius.circular(2.w),
                                                border: Border.all(
                                                    color: AppColors.grey6)),
                                            child: Padding(
                                              padding: EdgeInsets.all(
                                                1.5.h,
                                              ),
                                              child: TextFormField(
                                                decoration: InputDecoration(
                                                  border: InputBorder.none,
                                                  hintText: "34 years",
                                                  hintStyle: TextStyle(
                                                      fontSize: 10.sp,
                                                      fontWeight:
                                                          FontWeight.w300,
                                                      color: AppColors.grey5),
                                                ),
                                              ),
                                            ),
                                          ),
                                          DecoratedBox(
                                            decoration: ShapeDecoration(
                                              color: AppColors.white1,
                                              shape: RoundedRectangleBorder(
                                                borderRadius: BorderRadius.all(
                                                    Radius.circular(2.w)),
                                              ),
                                            ),
                                            child: Container(
                                              decoration: BoxDecoration(
                                                  color: AppColors.grey6,
                                                  borderRadius:
                                                      BorderRadius.circular(
                                                          2.w),
                                                  border: Border.all(
                                                      color: AppColors.grey6)),
                                              height: 6.5.h,
                                              width: 45.w,
                                              child:
                                                  DropdownButtonHideUnderline(
                                                child: Padding(
                                                  padding: EdgeInsets.symmetric(
                                                      horizontal: 2.h),
                                                  child: DropdownButton<String>(
                                                    elevation: 0,
                                                    icon: Icon(
                                                      Icons
                                                          .keyboard_arrow_down_sharp,
                                                      color: AppColors.black1,
                                                    ),
                                                    value: seconddropDownValue,
                                                    dropdownColor:
                                                        AppColors.grey5,
                                                    items: <String>[
                                                      'Food Category',
                                                      'Select'
                                                    ].map((String value) {
                                                      return DropdownMenuItem<
                                                          String>(
                                                        value: value,
                                                        child: Text(
                                                          value,
                                                          style: TextStyle(
                                                              fontSize: 10.sp),
                                                        ),
                                                      );
                                                    }).toList(),
                                                    onChanged: (value) {
                                                      setState(() {
                                                        firstdropDownValue =
                                                            value;
                                                      });
                                                    },
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                      SizedBox(
                                        height: 2.h,
                                      ),
                                      Padding(
                                        padding: EdgeInsets.only(
                                            left: 4.w, right: 27.w),
                                        child: Row(
                                          mainAxisAlignment:
                                              MainAxisAlignment.spaceBetween,
                                          children: [
                                            Text(
                                              "Religion",
                                              style: TextStyle(
                                                  fontSize: 10.sp,
                                                  fontWeight: FontWeight.w300,
                                                  color: AppColors.grey5),
                                            ),
                                            Padding(
                                              padding:  EdgeInsets.only(left: 30.w),
                                              child: Text(
                                                "Mother Tongue",
                                                style: TextStyle(
                                                    fontSize: 9.sp,
                                                    fontWeight: FontWeight.w300,
                                                    color: AppColors.grey5),
                                              ),
                                            )
                                          ],
                                        ),
                                      ),
                                      SizedBox(
                                        height: 2.h,
                                      ),
                                      Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.spaceEvenly,
                                        children: [
                                          DecoratedBox(
                                            decoration: ShapeDecoration(
                                              color: AppColors.white1,
                                              shape: RoundedRectangleBorder(
                                                borderRadius: BorderRadius.all(
                                                    Radius.circular(2.w)),
                                              ),
                                            ),
                                            child: Container(
                                              decoration: BoxDecoration(
                                                  color: AppColors.grey6,
                                                  borderRadius:
                                                      BorderRadius.circular(
                                                          2.w),
                                                  border: Border.all(
                                                      color: AppColors.grey6)),
                                              height: 6.5.h,
                                              width: 45.w,
                                              child:
                                                  DropdownButtonHideUnderline(
                                                child: Padding(
                                                  padding: EdgeInsets.symmetric(
                                                      horizontal: 2.h),
                                                  child: DropdownButton<String>(
                                                    elevation: 0,
                                                    icon: Icon(
                                                      Icons
                                                          .keyboard_arrow_down_sharp,
                                                      color: AppColors.black1,
                                                    ),
                                                    value: seconddropDownValue,
                                                    dropdownColor:
                                                        AppColors.grey5,
                                                    items: <String>[
                                                      'Food Category',
                                                      'Select'
                                                    ].map((String value) {
                                                      return DropdownMenuItem<
                                                          String>(
                                                        value: value,
                                                        child: Text(
                                                          value,
                                                          style: TextStyle(
                                                              fontSize: 10.sp),
                                                        ),
                                                      );
                                                    }).toList(),
                                                    onChanged: (value) {
                                                      setState(() {
                                                        firstdropDownValue =
                                                            value;
                                                      });
                                                    },
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ),
                                          DecoratedBox(
                                            decoration: ShapeDecoration(
                                              color: AppColors.white1,
                                              shape: RoundedRectangleBorder(
                                                borderRadius: BorderRadius.all(
                                                    Radius.circular(2.w)),
                                              ),
                                            ),
                                            child: Container(
                                              decoration: BoxDecoration(
                                                  color: AppColors.grey6,
                                                  borderRadius:
                                                      BorderRadius.circular(
                                                          2.w),
                                                  border: Border.all(
                                                      color: AppColors.grey6)),
                                              height: 6.5.h,
                                              width: 45.w,
                                              child:
                                                  DropdownButtonHideUnderline(
                                                child: Padding(
                                                  padding: EdgeInsets.symmetric(
                                                      horizontal: 2.h),
                                                  child: DropdownButton<String>(
                                                    elevation: 0,
                                                    icon: Icon(
                                                      Icons
                                                          .keyboard_arrow_down_sharp,
                                                      color: AppColors.black1,
                                                    ),
                                                    value: seconddropDownValue,
                                                    dropdownColor:
                                                        AppColors.grey5,
                                                    items: <String>[
                                                      'Food Category',
                                                      'Select'
                                                    ].map((String value) {
                                                      return DropdownMenuItem<
                                                          String>(
                                                        value: value,
                                                        child: Text(
                                                          value,
                                                          style: TextStyle(
                                                              fontSize: 10.sp),
                                                        ),
                                                      );
                                                    }).toList(),
                                                    onChanged: (value) {
                                                      setState(() {
                                                        firstdropDownValue =
                                                            value;
                                                      });
                                                    },
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                      SizedBox(
                                        height: 2.h,
                                      ),
                                      Padding(
                                        padding: EdgeInsets.only(
                                            left: 4.w, right: 31.w),
                                        child: Row(
                                          mainAxisAlignment:
                                              MainAxisAlignment.spaceBetween,
                                          children: [
                                            Text(
                                              "Nationality",
                                              style: TextStyle(
                                                  fontSize: 10.sp,
                                                  fontWeight: FontWeight.w300,
                                                  color: AppColors.grey5),
                                            ),
                                            Text(
                                              "Literacy       ",
                                              style: TextStyle(
                                                  fontSize: 10.sp,
                                                  fontWeight: FontWeight.w300,
                                                  color: AppColors.grey5),
                                            )
                                          ],
                                        ),
                                      ),
                                      SizedBox(
                                        height: 2.h,
                                      ),
                                      Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.spaceEvenly,
                                        children: [
                                          DecoratedBox(
                                            decoration: ShapeDecoration(
                                              color: AppColors.white1,
                                              shape: RoundedRectangleBorder(
                                                borderRadius: BorderRadius.all(
                                                    Radius.circular(2.w)),
                                              ),
                                            ),
                                            child: Container(
                                              decoration: BoxDecoration(
                                                  color: AppColors.grey6,
                                                  borderRadius:
                                                      BorderRadius.circular(
                                                          2.w),
                                                  border: Border.all(
                                                      color: AppColors.grey6)),
                                              height: 6.5.h,
                                              width: 45.w,
                                              child:
                                                  DropdownButtonHideUnderline(
                                                child: Padding(
                                                  padding: EdgeInsets.symmetric(
                                                      horizontal: 2.h),
                                                  child: DropdownButton<String>(
                                                    elevation: 0,
                                                    icon: Icon(
                                                      Icons
                                                          .keyboard_arrow_down_sharp,
                                                      color: AppColors.black1,
                                                    ),
                                                    value: seconddropDownValue,
                                                    dropdownColor:
                                                        AppColors.grey5,
                                                    items: <String>[
                                                      'Food Category',
                                                      'Select'
                                                    ].map((String value) {
                                                      return DropdownMenuItem<
                                                          String>(
                                                        value: value,
                                                        child: Text(
                                                          value,
                                                          style: TextStyle(
                                                              fontSize: 10.sp),
                                                        ),
                                                      );
                                                    }).toList(),
                                                    onChanged: (value) {
                                                      setState(() {
                                                        firstdropDownValue =
                                                            value;
                                                      });
                                                    },
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ),
                                          DecoratedBox(
                                            decoration: ShapeDecoration(
                                              color: AppColors.white1,
                                              shape: RoundedRectangleBorder(
                                                borderRadius: BorderRadius.all(
                                                    Radius.circular(2.w)),
                                              ),
                                            ),
                                            child: Container(
                                              decoration: BoxDecoration(
                                                  color: AppColors.grey6,
                                                  borderRadius:
                                                      BorderRadius.circular(
                                                          2.w),
                                                  border: Border.all(
                                                      color: AppColors.grey6)),
                                              height: 6.5.h,
                                              width: 45.w,
                                              child:
                                                  DropdownButtonHideUnderline(
                                                child: Padding(
                                                  padding: EdgeInsets.symmetric(
                                                      horizontal: 2.h),
                                                  child: DropdownButton<String>(
                                                    elevation: 0,
                                                    icon: Icon(
                                                      Icons
                                                          .keyboard_arrow_down_sharp,
                                                      color: AppColors.black1,
                                                    ),
                                                    value: seconddropDownValue,
                                                    dropdownColor:
                                                        AppColors.grey5,
                                                    items: <String>[
                                                      'Food Category',
                                                      'Select'
                                                    ].map((String value) {
                                                      return DropdownMenuItem<
                                                          String>(
                                                        value: value,
                                                        child: Text(
                                                          value,
                                                          style: TextStyle(
                                                              fontSize: 10.sp),
                                                        ),
                                                      );
                                                    }).toList(),
                                                    onChanged: (value) {
                                                      setState(() {
                                                        firstdropDownValue =
                                                            value;
                                                      });
                                                    },
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                      SizedBox(
                                        height: 2.h,
                                      ),
                                      Padding(
                                        padding:  EdgeInsets.only(right: 60.w),
                                        child: Text(
                                          "Education Level           ",
                                          style: TextStyle(
                                              fontSize: 10.sp,
                                              fontWeight: FontWeight.w300,
                                              color: AppColors.grey5),
                                        ),
                                      ),
                                      SizedBox(
                                        height: 2.h,
                                      ),
                                      DecoratedBox(
                                        decoration: ShapeDecoration(
                                          color: AppColors.white1,
                                          shape: RoundedRectangleBorder(
                                            borderRadius: BorderRadius.all(
                                                Radius.circular(2.w)),
                                          ),
                                        ),
                                        child: Container(
                                          decoration: BoxDecoration(
                                              color: AppColors.grey6,
                                              borderRadius:
                                                  BorderRadius.circular(2.w),
                                              border: Border.all(
                                                  color: AppColors.grey6)),
                                          height: 6.5.h,
                                          width: 90.w,
                                          child: DropdownButtonHideUnderline(
                                            child: Padding(
                                              padding: EdgeInsets.symmetric(
                                                  horizontal: 2.h),
                                              child: DropdownButton<String>(
                                                elevation: 0,
                                                icon: Icon(
                                                  Icons
                                                      .keyboard_arrow_down_sharp,
                                                  color: AppColors.black1,
                                                ),
                                                value: seconddropDownValue,
                                                dropdownColor: AppColors.grey5,
                                                items: <String>[
                                                  'Food Category',
                                                  'Select'
                                                ].map((String value) {
                                                  return DropdownMenuItem<
                                                      String>(
                                                    value: value,
                                                    child: Text(
                                                      value,
                                                      style: TextStyle(
                                                          fontSize: 10.sp),
                                                    ),
                                                  );
                                                }).toList(),
                                                onChanged: (value) {
                                                  setState(() {
                                                    firstdropDownValue = value;
                                                  });
                                                },
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                      SizedBox(
                                        height: 2.h,
                                      ),

                                      Padding(
                                        padding: EdgeInsets.only(right: 45.w),
                                        child: Text(
                                         "Activity During Last 12 Months",
                                          style: TextStyle(
                                              fontSize: 10.sp,
                                              fontWeight: FontWeight.w300,
                                              color: AppColors.grey5),
                                        ),
                                      ),
                                      SizedBox(
                                        height: 2.h,
                                      ),
                                      DecoratedBox(
                                        decoration: ShapeDecoration(
                                          color: AppColors.white1,
                                          shape: RoundedRectangleBorder(
                                            borderRadius: BorderRadius.all(
                                                Radius.circular(2.w)),
                                          ),
                                        ),
                                        child: Container(
                                          decoration: BoxDecoration(
                                              color: AppColors.grey6,
                                              borderRadius:
                                                  BorderRadius.circular(2.w),
                                              border: Border.all(
                                                  color: AppColors.grey6)),
                                          height: 6.5.h,
                                          width: 90.w,
                                          child: DropdownButtonHideUnderline(
                                            child: Padding(
                                              padding: EdgeInsets.symmetric(
                                                  horizontal: 2.h),
                                              child: DropdownButton<String>(
                                                elevation: 0,
                                                icon: Icon(
                                                  Icons
                                                      .keyboard_arrow_down_sharp,
                                                  color: AppColors.black1,
                                                ),
                                                value: seconddropDownValue,
                                                dropdownColor: AppColors.grey5,
                                                items: <String>[
                                                  'Food Category',
                                                  'Select'
                                                ].map((String value) {
                                                  return DropdownMenuItem<
                                                      String>(
                                                    value: value,
                                                    child: Text(
                                                      value,
                                                      style: TextStyle(
                                                          fontSize: 10.sp),
                                                    ),
                                                  );
                                                }).toList(),
                                                onChanged: (value) {
                                                  setState(() {
                                                    firstdropDownValue = value;
                                                  });
                                                },
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                      Padding(
                                        padding:  EdgeInsets.only(right: 52.w, top: 1.h),
                                        child: Text("For 18 Years & Above"),
                                      ),
                                      SizedBox(
                                        height: 2.h,
                                      ),
                                      Padding(
                                        padding:  EdgeInsets.only(right: 70.w),
                                        child: Text("Cnic Holder"),
                                      ),
                                      SizedBox(
                                        height: 2.h,
                                      ),
                                      Padding(
                                        padding:  EdgeInsets.only(left: 4.5.w),
                                        child: Row(mainAxisAlignment: MainAxisAlignment.start, children: [
                                          Container(
                                            height: 4.5.h,
                                            width: 20.w,
                                            decoration: BoxDecoration(
                                                borderRadius: BorderRadius.circular(1.5.w),
                                                border: Border.all(color: Colors.grey)),
                                            child: Row(
                                              children: [
                                                Checkbox(
                                                  checkColor: AppColors.grey5,
                                                  value: _checkbox,
                                                  onChanged: (value) {
                                                    setState(() {
                                                      _checkbox = !_checkbox;
                                                    });
                                                  },
                                                ),
                                                Text(
                                                  'Yes',
                                                  style: TextStyle(fontSize: 8.sp),
                                                ),
                                              ],
                                            ),
                                          ),
                                          SizedBox(width: 5.w,),
                                          Container(
                                            height: 4.5.h,
                                            width: 20.w,
                                            decoration: BoxDecoration(
                                                borderRadius: BorderRadius.circular(1.5.w),
                                                border: Border.all(color: Colors.grey)),
                                            child: Row(
                                              children: [
                                                Checkbox(
                                                  checkColor: AppColors.grey5,
                                                  value: _checkbox,
                                                  onChanged: (value) {
                                                    setState(() {
                                                      _checkbox = !_checkbox;
                                                    });
                                                  },
                                                ),
                                                Text(
                                                  'NO',
                                                  style: TextStyle(fontSize: 8.sp),
                                                ),
                                              ],
                                            ),
                                          ),

                                        ]),
                                      ),
                                      SizedBox(
                                        height: 5.h,
                                      ),

                                      AppButton(
                                        text: "Add Member",
                                        onTap: () {},
                                        backgroundColor: AppColors.red1,
                                        heightsize: 8.h,
                                        widthsize: 90.w,
                                      ),
                                      SizedBox(height: 2.h,)
                                    ],
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ));
            },
          )),


        ],
      ),
    );
  }
}
