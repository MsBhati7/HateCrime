import 'package:flutter/material.dart';
import 'package:get/get_navigation/src/extension_navigation.dart';
import 'package:get/instance_manager.dart';

import 'package:sizer/sizer.dart';
import 'package:untitled2/Myprofile.dart';
import 'package:untitled2/Profile.dart';
import 'package:untitled2/SignUp2.dart';
import 'package:untitled2/SigninMobile.dart';
import 'package:untitled2/EndSession.dart';
import 'package:untitled2/Signup3.dart';
import 'package:untitled2/proclamationform.dart';
import 'package:untitled2/utils/IcIcons.dart';
import 'package:untitled2/utils/colors.dart';
import 'package:untitled2/welcome.dart';

import 'Widgets/appbuttons.dart';

class CreateNewAccount extends StatelessWidget {
  // final person = List<String>.generate(3, (i) => 'Person ${i+1 }' );
  static const route = "/createNewAccount";

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(

        elevation: 0.0,
        title: Padding(
          padding: EdgeInsets.only(left: 6.w),
          child: Text(
            " Create new account",
            style: TextStyle(
              fontSize: 14.sp,
              fontWeight: FontWeight.bold,
              color: AppColors.black1,
            ),
          ),
        ),
        leading: IconButton(
            onPressed: () { Get.to(() => WelcomePage());},
            icon: Icon(Icons.arrow_back,color: AppColors.black1,size: 5.w,)),
        backgroundColor: AppColors.white1,
      ),
      body: SingleChildScrollView(
          child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
            Container(),
            SizedBox(
              height: 3.h,
            ),
            Text(
              "Select the Type of account\n   that suits you sign-up",
              style: TextStyle(
                  fontSize: 16.sp,
                  fontWeight: FontWeight.bold,
                  color: AppColors.black1),
            ),
            SizedBox(
              height: 7.h,
            ),
            Container(

              height: 15.h,
              width: 90.w,
              decoration: BoxDecoration(
                  color: AppColors.lite1,
                borderRadius: BorderRadius.circular(3.w)
              ),

              child: Column(
                children: [
                  SizedBox(height: 0.8.h,),
                  AppButton(
                    text: "TYPE 1 ACCOUNT",
                    onTap: () {Get.to(() => MyProfile2());},
                    backgroundColor: AppColors.red1,
                    heightsize: 7.h,
                    widthsize: 85.w,
                  ),
                  SizedBox(
                    height: 2.h,
                  ),
                  Text(
                    "For those who want to report ant hate-crime against",
                    style: TextStyle(
                        fontSize: 9.5.sp,
                        fontWeight: FontWeight.w500,
                        color: AppColors.grey5),
                  ),
                  Text(
                    "Christians - minimum details needed.",
                    style: TextStyle(
                        fontSize: 9.5.sp,
                        fontWeight: FontWeight.w500,
                        color: AppColors.grey5),
                  ),
                ],
              ),
            ),
            // SizedBox(
            //   height: 2.h,
            // ),
            // Text(
            //   "For those who want to report ant hate-crime against",
            //   style: TextStyle(
            //       fontSize: 9.5.sp,
            //       fontWeight: FontWeight.w500,
            //       color: AppColors.grey5),
            // ),
            // Text(
            //   "Christians - minimum details needed.",
            //   style: TextStyle(
            //       fontSize: 9.5.sp,
            //       fontWeight: FontWeight.w500,
            //       color: AppColors.grey5),
            // ),
            // SizedBox(
            //   height: 10.h,
            // ),
            // GestureDetector(
            //   onTap: () {
            //     Get.to(() => SignUoType2());
            //   },
            //   child: AppButton(
            //     text: "TYPE 2 ACCOUNT",
            //     onTap: () {},
            //     backgroundColor: AppColors.red1,
            //     heightsize: 6.5.h,
            //     widthsize: 90.w,
            //   ),
            // ),
            // SizedBox(
            //   height: 2.h,
            // ),

                SizedBox(
                   height: 5.h,
                 ),
                Container(

                  height: 27.h,
                  width: 90.w,
                  decoration: BoxDecoration(
                      color: AppColors.lite1,
                      borderRadius: BorderRadius.circular(3.w)
                  ),

                  child: Column(
                    children: [
                      SizedBox(height: 0.5.h,),
                      AppButton(
                        text: "TYPE 2 ACCOUNT",
                        onTap: () {Get.to(() => MyProfile2());},
                        backgroundColor: AppColors.red1,
                        heightsize: 6.5.h,
                        widthsize: 85.w,
                      ),
                      SizedBox(
                        height: 2.h,
                      ),
                      Text(
                        "For those who are actively engaged with the local church \n           youth group(s) or are volunteers,community   \n                            workers or activists.\n       Type 2 Account allows reporting and additional\n             community services responsibilities and\n                        development opportunities.\nReference checks will be required for type 2 Account     ",
                        style: TextStyle(

                            fontSize: 10.sp,
                            fontWeight: FontWeight.w500,
                            color: AppColors.grey2),
                      ),
                    ],
                  ),
                ),
          // onPressed: () { Get.to(() => CreateNewAccount());},
          // icon: Icon(Icons.arrow_back,color: AppColors.black1,size: 5.w,)),
            SizedBox(
              height: 10.h,
            ),
            GestureDetector(
              onTap: () {Get.to(() => SigninMobile());},
              child: Container(
                alignment: Alignment.center,
                 height: 8.h,
                width: 90.w,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(2.5.w),
                 color: AppColors.grey7,
                  border: Border.all(
                    color: AppColors.red1,
                    width: 0.2.h,
                  ),
                ),
                child: RichText(
                  text: TextSpan(
                      text: "ALREADY HAVE AN ACCOUNT? ",
                      style: TextStyle(
                        color: AppColors.grey2,
                        fontWeight: FontWeight.w500,
                        fontSize: 10.sp,
                      ),
                      children: [
                        TextSpan(
                          text: "SIGN-IN",
                          style: TextStyle(
                            color: Colors.black54,
                            fontSize: 10.sp,
                            fontWeight: FontWeight.bold,
                          ),
                        )
                      ]),
                ),
              ),
            ),
            SizedBox(
              height: 7.h,
            ),
          ])),
    );
  }
}
