import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:otp_text_field/otp_field.dart';
import 'package:otp_text_field/style.dart';

import 'package:sizer/sizer.dart';
import 'package:untitled2/HousingCharacteristics.dart';

import 'package:untitled2/utils/IcIcons.dart';
import 'package:untitled2/utils/colors.dart';


import 'Widgets/appbuttons.dart';

class HousingCensusForm1 extends StatefulWidget {
  static const route = "/housingCensusForm1";

  @override
  State<HousingCensusForm1> createState() => _HousingCensusForm1State();
}

class _HousingCensusForm1State extends State<HousingCensusForm1> {
  String? firstdropDownValue = "Food Category";
  String? seconddropDownValue = "Select";

  @override
  bool isYes = false;
  bool isNo = false;
  bool isRegular = false;
  bool isIntituonal = false;
  bool isHomeless = false;
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          elevation: 0.0,
          title: Row(
            children: [
              Text(
                "Housing Census Form",
                style: TextStyle(
                  fontSize: 14.sp,
                  fontWeight: FontWeight.bold,
                  color: AppColors.black1,
                ),
              ),

            ],
          ),
          leading:
              IconButton(onPressed: () {}, icon: Image.asset(IcIcons.Dash)),
          backgroundColor: AppColors.white1,
        ),
        body: SingleChildScrollView(
            child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
              Container(),
              SizedBox(
                height: 3.h,
              ),
                  Padding(
                    padding:  EdgeInsets.only(right: 45.w),
                    child: Text("Household SI Number",
                        style: TextStyle(
                            fontSize: 14.sp,
                            fontWeight: FontWeight.w500,
                            color: AppColors.black1)),
                  ),
                  SizedBox(height: 2.h,),
                  Container(
                    height: 7.h,
                    width: 92.w,
                    decoration: BoxDecoration(
                      color: AppColors.grey6,
                      borderRadius: BorderRadius.circular(2.w)
                    ),
                    child: Padding(
                      padding:  EdgeInsets.symmetric(horizontal: 3.h,vertical: 3.w),
                      child: TextFormField(
                        decoration: InputDecoration(
                           border: InputBorder.none,
                          hintText: "Enter Si Number",
                          hintStyle: TextStyle(
                              fontSize: 12.sp,
                              fontWeight: FontWeight.w500,
                              color: AppColors.grey1),
                        ),
                      ),
                    ),
                  ),
                  SizedBox(height: 2.h,),
              Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly, children: [
                Container(

                    height: 11.h,
                    width: 28.w,
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(1.5.w),
                        border: Border.all(color: Colors.grey)),
                    child: Column(
                      children: [
                        Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                          Checkbox(
                            checkColor: AppColors.grey5,
                            value: isRegular,
                            onChanged: (value) {
                              setState(() {
                                 isRegular = value!;
                               isIntituonal = false;
                                 isHomeless = false;
                              });
                            },
                          ),

                        ]),
                        Text("Regular HH", style: TextStyle(fontSize: 10.sp),)
                      ],
                    )),
                Container(
                    height: 11.h,
                    width: 28.w,
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(1.5.w),
                        border: Border.all(color: Colors.grey)),
                    child: Column(
                      children: [
                        Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                          Checkbox(
                            checkColor: AppColors.grey5,
                            value: isIntituonal,
                            onChanged: (value) {
                              setState(() {
                                 isRegular = false;
                                 isIntituonal = value!;
                                 isHomeless = false;
                              });
                            },
                          ),

                        ]),
                        Text("Regular HH", style: TextStyle(fontSize: 10.sp),)
                      ],
                    )),
                Container(
                    height: 11.h,
                    width: 28.w,
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(1.5.w),
                        border: Border.all(color: Colors.grey)),
                    child: Column(
                      children: [
                        Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                          Checkbox(
                            checkColor: AppColors.grey5,
                            value: isHomeless,
                            onChanged: (value) {
                              setState(() {
                                 isRegular = false;
                                 isIntituonal = false;
                                 isHomeless = value!;
                              });
                            },
                          ),

                        ]),
                        Text("Regular HH", style: TextStyle(fontSize: 10.sp),)
                      ],
                    )),
              ]),
                  SizedBox(height: 2.h,),
                  Padding(
                    padding:  EdgeInsets.only(right: 67.w),
                    child: Text("Block Code",
                        style: TextStyle(
                            fontSize: 14.sp,
                            fontWeight: FontWeight.w500,
                            color: AppColors.black1)),
                  ),
                  SizedBox(height:3.h),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: [
                      Text("Block"),
                      Text("Circle"),
                      Text("Charge")
                  ],),
                  SizedBox(height:3.h),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      Container(

                        width: 30.w,
                        child: OTPTextField(
                          length: 2,
// width: MediaQuery.of(context).size.width,
                          fieldWidth: 12.w,
                          style: TextStyle(

                              fontSize: 12.sp,
                              fontWeight: FontWeight.bold
                          ),
                          textFieldAlignment: MainAxisAlignment.spaceAround,
                          fieldStyle: FieldStyle.box,
                          onCompleted: (pin) {
                            print("Completed: " + pin);
                          },
                        ),
                      ),
                      Container(

                        width: 30.w,
                        child: OTPTextField(
                          length: 2,
// width: MediaQuery.of(context).size.width,
                          fieldWidth: 12.w,
                          style: TextStyle(

                              fontSize: 12.sp,
                              fontWeight: FontWeight.bold
                          ),
                          textFieldAlignment: MainAxisAlignment.spaceAround,
                          fieldStyle: FieldStyle.box,
                          onCompleted: (pin) {
                            print("Completed: " + pin);
                          },
                        ),
                      ),
                      Container(

                        width: 30.w,
                        child: OTPTextField(
                          length: 2,
// width: MediaQuery.of(context).size.width,
                          fieldWidth: 12.w,
                          style: TextStyle(

                              fontSize: 12.sp,
                              fontWeight: FontWeight.bold
                          ),
                          textFieldAlignment: MainAxisAlignment.spaceAround,
                          fieldStyle: FieldStyle.box,
                          onCompleted: (pin) {
                            print("Completed: " + pin);
                          },
                        ),
                      ),
                    ],
                  ),
                  SizedBox(height:3.h),
                  Padding(
                    padding:  EdgeInsets.only(right: 65.w),
                    child: Text("Census District",style: TextStyle(color: AppColors.grey5),),
                  ),
                  SizedBox(height:3.h),
                  Padding(
                    padding:  EdgeInsets.only(right: 35.w),
                    child: Container(

                      width: 45.w,
                      child: OTPTextField(
                        length: 3,
// width: MediaQuery.of(context).size.width,
                        fieldWidth: 12.w,
                        style: TextStyle(

                            fontSize: 12.sp,
                            fontWeight: FontWeight.bold
                        ),
                        textFieldAlignment: MainAxisAlignment.spaceAround,
                        fieldStyle: FieldStyle.box,
                        onCompleted: (pin) {
                          print("Completed: " + pin);
                        },
                      ),
                    ),
                  ),
                  Column(
                    children: [
                      Container(
                        height: 25.h,
                        child: Container(

                          height: 10.h,
                          width: 90.w,
                          decoration: BoxDecoration(
                              color: AppColors.white1,
                              borderRadius: BorderRadius.circular(2.w)),
                          child: Column(
                            children: [
                              Card(
                                elevation: 0.0,
                                color: AppColors.white1,
                                child: ListTile(
                                  leading: Image.asset(IcIcons.Numbers1,width: 10.w,),
                                  title: Row(
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    children: [
                                      Padding(
                                        padding:  EdgeInsets.only(top: 1.h,right: 2.5.w),
                                        child: Text(
                                          "Amira Parvej (36) F",
                                          style: TextStyle(
                                              fontSize: 10.sp,
                                              fontWeight: FontWeight.bold,
                                              color: AppColors.black1),
                                        ),
                                      ),
                                      SizedBox(
                                        width: 5.w,
                                      ),

                                    ],
                                  ),
                                  trailing: Padding(
                                    padding: EdgeInsets.only(bottom: 8.w, ),
                                    child: Image.asset(
                                      IcIcons.doats1,
                                      width: 0.5.w,
                                    ),
                                  ),
                                  subtitle: Padding(
                                    padding:  EdgeInsets.only(bottom: 2.2.h,top: 1.5.h),
                                    child: Text(
                                      "Spouse",
                                      style: TextStyle(
                                          fontSize: 8.sp,
                                          fontWeight: FontWeight.w500,
                                          color: AppColors.grey1),
                                    ),
                                  ),
                                ),
                              ),
                              SizedBox(height: 2.h,),
                              Container(

                                height: 10.h,
                                width: 90.w,
                                decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(7.w)),
                                child: Card(
                                  elevation: 0.0,
                                  color: AppColors.white1,
                                  child: ListTile(
                                    leading: Image.asset(IcIcons.Numbers1,width: 10.w,),
                                    title: Row(
                                      mainAxisAlignment: MainAxisAlignment.start,
                                      children: [
                                        Padding(
                                          padding:  EdgeInsets.only(top: 1.h,right: 2.5.w),
                                          child: Text(
                                            "Masum Parvej (24) M",
                                            style: TextStyle(
                                                fontSize: 10.sp,
                                                fontWeight: FontWeight.bold,
                                                color: AppColors.black1),
                                          ),
                                        ),
                                        SizedBox(
                                          width: 5.w,
                                        ),

                                      ],
                                    ),
                                    trailing: Padding(
                                      padding: EdgeInsets.only(bottom: 8.w, ),
                                      child: Image.asset(
                                        IcIcons.doats1,
                                        width: 0.5.w,
                                      ),
                                    ),
                                    subtitle: Padding(
                                      padding:  EdgeInsets.only(bottom: 2.2.h,top: 1.5.h),
                                      child: Text(
                                        "Son",
                                        style: TextStyle(
                                            fontSize: 8.sp,
                                            fontWeight: FontWeight.w500,
                                            color: AppColors.grey1),
                                      ),
                                    ),
                                  ),
                                ),

                              ),

                            ],
                          ),
                        ),
                      ),
                      SizedBox(height: 2.h,),
                      GestureDetector(
                          onTap: () {
                          },
                          child: Container(
                            alignment: Alignment.center,
                            width: 88.w,
                            height: 7.h,
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(8.0),
                              color: AppColors.lite1,
                              border: Border.all(
                                color: AppColors.lite1,
                                width: 0.2.h,
                              ),
                            ),
                            child: Text(
                              "ADD NEW Member",
                              style: TextStyle(
                                color: AppColors.dark1,
                                fontSize: 10.sp,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          )),
                      SizedBox(height: 3.5.h,),
                      Padding(
                        padding:  EdgeInsets.only(right: 72.w),
                        child: Text("CNIC Number",
                            style: TextStyle(
                                fontSize: 10.sp,
                                fontWeight: FontWeight.w500,
                                color: AppColors.black1)),
                      ),
                      SizedBox(height: 2.h,),
                      Container(
                        height: 7.h,
                        width: 92.w,
                        decoration: BoxDecoration(
                            color: AppColors.grey6,
                            borderRadius: BorderRadius.circular(2.w)
                        ),
                        child: Padding(
                          padding:  EdgeInsets.symmetric(horizontal: 3.h,vertical: 3.w),
                          child: TextFormField(
                            decoration: InputDecoration(
                              border: InputBorder.none,
                              hintText: "Enter Si Number",
                              hintStyle: TextStyle(
                                  fontSize: 8.sp,
                                  fontWeight: FontWeight.w500,
                                  color: AppColors.grey1),
                            ),
                          ),
                        ),
                      ),
                      SizedBox(height: 7.h,),

                      Column(
                        children: [
                          AppButton(
                            text: "CONTINUE",
                            onTap: () {
                              showModalBottomSheet(
                                  context: context,
                                  shape: RoundedRectangleBorder(
                                      borderRadius:
                                      BorderRadius.vertical(top: Radius.circular(5.w))),
                                  builder: (context) => Container(


                                    decoration: BoxDecoration(
                                      color: AppColors.lite1,
                                      borderRadius: BorderRadius.only(
                                          topRight: Radius.circular(5.w),
                                          topLeft: Radius.circular(5.w)),
                                    ),
                                    child: Stack(
                                      children: [
                                        Padding(
                                          padding: EdgeInsets.only(top: 3.h),
                                          child: SingleChildScrollView(
                                            child: Container(
                                              decoration: BoxDecoration(
                                                color: AppColors.white1,
                                                borderRadius: BorderRadius.only(
                                                    topRight: Radius.circular(5.w),
                                                    topLeft: Radius.circular(5.w)),
                                              ),
                                              height: 130.h,
                                              child: Column(
                                                children: [
                                                  SizedBox(height: 2.h,),
                                                  Row(
                                                    children: [
                                                      Text("     Add Household Member",style: TextStyle(
                                                          fontSize: 13.sp,
                                                          fontWeight: FontWeight.bold,
                                                          color: AppColors.black1)),
                                                      Padding(
                                                        padding:  EdgeInsets.only(left: 35.w),
                                                        child: CircleAvatar(
                                                            backgroundColor: AppColors.white1,
                                                            child:
                                                            Icon(Icons.close,color: AppColors.black1,)
                                                        ),
                                                      )
                                                    ],
                                                  ),

                                                  Padding(
                                                    padding:  EdgeInsets.only(right: 45
                                                        .w),
                                                    child: Text("Household Member Name",
                                                        style: TextStyle(
                                                            fontSize: 11.sp,

                                                            color: AppColors.grey1)),
                                                  ),
                                                  SizedBox(height: 2.h,),
                                                  SingleChildScrollView(
                                                    child: Container(
                                                      height: 6.5.h,
                                                      width: 90.w,
                                                      decoration: BoxDecoration(
                                                          color: AppColors.grey6,
                                                          borderRadius:
                                                          BorderRadius.circular(2.w),
                                                          border: Border.all(
                                                              color: AppColors.grey6)),
                                                      child: Padding(
                                                        padding: EdgeInsets.all(
                                                          1.5.h,
                                                        ),
                                                        child: TextFormField(
                                                          decoration: InputDecoration(
                                                            border: InputBorder.none,
                                                            hintText: "Sarah M. Holiday",
                                                            hintStyle: TextStyle(
                                                                fontSize: 10.sp,
                                                                fontWeight:
                                                                FontWeight.w300,
                                                                color: AppColors.black1),
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                  SizedBox(height: 2.h,),
                                                  Row(
                                                    mainAxisAlignment:
                                                    MainAxisAlignment.spaceEvenly,
                                                    children: [
                                                      Text(
                                                        "Relation with head                  ",
                                                        style: TextStyle(
                                                            fontSize: 10.sp,
                                                            fontWeight: FontWeight.w300,
                                                            color: AppColors.grey5),
                                                      ),

                                                      Text(
                                                        "Marital Status                           ",
                                                        style: TextStyle(
                                                            fontSize: 10.sp,
                                                            fontWeight: FontWeight.w300,
                                                            color: AppColors.grey5),
                                                      )
                                                    ],
                                                  ),
                                                  SizedBox(height: 2.h,),
                                                  Row(
                                                    mainAxisAlignment:
                                                    MainAxisAlignment.spaceEvenly,
                                                    children: [
                                                      DecoratedBox(
                                                        decoration: ShapeDecoration(
                                                          color: AppColors.white1,
                                                          shape: RoundedRectangleBorder(
                                                            borderRadius: BorderRadius.all(
                                                                Radius.circular(2.w)),
                                                          ),
                                                        ),
                                                        child: Container(
                                                          decoration: BoxDecoration(
                                                              color: AppColors.grey6,
                                                              borderRadius:
                                                              BorderRadius.circular(
                                                                  2.w),
                                                              border: Border.all(
                                                                  color: AppColors.grey6)),
                                                          height: 6.5.h,
                                                          width: 45.w,
                                                          child:
                                                          DropdownButtonHideUnderline(
                                                            child: Padding(
                                                              padding: EdgeInsets.symmetric(
                                                                  horizontal: 2.h),
                                                              child: DropdownButton<String>(
                                                                elevation: 0,
                                                                icon: Icon(
                                                                  Icons
                                                                      .keyboard_arrow_down_sharp,
                                                                  color: AppColors.black1,
                                                                ),
                                                                value: seconddropDownValue,
                                                                dropdownColor:
                                                                AppColors.grey5,
                                                                items: <String>[
                                                                  'Food Category',
                                                                  'Select'
                                                                ].map((String value) {
                                                                  return DropdownMenuItem<
                                                                      String>(
                                                                    value: value,
                                                                    child: Text(
                                                                      value,
                                                                      style: TextStyle(
                                                                          fontSize: 10.sp),
                                                                    ),
                                                                  );
                                                                }).toList(),
                                                                onChanged: (value) {
                                                                  setState(() {
                                                                    firstdropDownValue =
                                                                        value;
                                                                  });
                                                                },
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                      DecoratedBox(
                                                        decoration: ShapeDecoration(
                                                          color: AppColors.white1,
                                                          shape: RoundedRectangleBorder(
                                                            borderRadius: BorderRadius.all(
                                                                Radius.circular(2.w)),
                                                          ),
                                                        ),
                                                        child: Container(
                                                          decoration: BoxDecoration(
                                                              color: AppColors.grey6,
                                                              borderRadius:
                                                              BorderRadius.circular(
                                                                  2.w),
                                                              border: Border.all(
                                                                  color: AppColors.grey6)),
                                                          height: 6.5.h,
                                                          width: 45.w,
                                                          child:
                                                          DropdownButtonHideUnderline(
                                                            child: Padding(
                                                              padding: EdgeInsets.symmetric(
                                                                  horizontal: 2.h),
                                                              child: DropdownButton<String>(
                                                                elevation: 0,
                                                                icon: Icon(
                                                                  Icons
                                                                      .keyboard_arrow_down_sharp,
                                                                  color: AppColors.black1,
                                                                ),
                                                                value: seconddropDownValue,
                                                                dropdownColor:
                                                                AppColors.grey5,
                                                                items: <String>[
                                                                  'Food Category',
                                                                  'Select'
                                                                ].map((String value) {
                                                                  return DropdownMenuItem<
                                                                      String>(
                                                                    value: value,
                                                                    child: Text(
                                                                      value,
                                                                      style: TextStyle(
                                                                          fontSize: 10.sp),
                                                                    ),
                                                                  );
                                                                }).toList(),
                                                                onChanged: (value) {
                                                                  setState(() {
                                                                    firstdropDownValue =
                                                                        value;
                                                                  });
                                                                },
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                  SizedBox(
                                                    height: 2.h,
                                                  ),
                                                  Padding(
                                                    padding: EdgeInsets.only(
                                                        left: 4.w, right: 23.w),
                                                    child: Row(
                                                      mainAxisAlignment:
                                                      MainAxisAlignment.spaceBetween,
                                                      children: [
                                                        Text(
                                                          "Member Age",
                                                          style: TextStyle(
                                                              fontSize: 10.sp,
                                                              fontWeight: FontWeight.w300,
                                                              color: AppColors.grey5),
                                                        ),
                                                        Text(
                                                          "Member Gender",
                                                          style: TextStyle(
                                                              fontSize: 10.sp,
                                                              fontWeight: FontWeight.w300,
                                                              color: AppColors.grey5),
                                                        )
                                                      ],
                                                    ),
                                                  ),

                                                  SizedBox(height: 2.h,),
                                                  Row(
                                                    mainAxisAlignment:
                                                    MainAxisAlignment.spaceEvenly,
                                                    children: [
                                                      Container(
                                                        height: 6.5.h,
                                                        width: 45.w,
                                                        decoration: BoxDecoration(
                                                            color: AppColors.grey6,
                                                            borderRadius:
                                                            BorderRadius.circular(2.w),
                                                            border: Border.all(
                                                                color: AppColors.grey6)),
                                                        child: Padding(
                                                          padding: EdgeInsets.all(
                                                            1.5.h,
                                                          ),
                                                          child: TextFormField(
                                                            decoration: InputDecoration(
                                                              border: InputBorder.none,
                                                              hintText: "34 years",
                                                              hintStyle: TextStyle(
                                                                  fontSize: 10.sp,
                                                                  fontWeight:
                                                                  FontWeight.w300,
                                                                  color: AppColors.grey5),
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                      DecoratedBox(
                                                        decoration: ShapeDecoration(
                                                          color: AppColors.white1,
                                                          shape: RoundedRectangleBorder(
                                                            borderRadius: BorderRadius.all(
                                                                Radius.circular(2.w)),
                                                          ),
                                                        ),
                                                        child: Container(
                                                          decoration: BoxDecoration(
                                                              color: AppColors.grey6,
                                                              borderRadius:
                                                              BorderRadius.circular(
                                                                  2.w),
                                                              border: Border.all(
                                                                  color: AppColors.grey6)),
                                                          height: 6.5.h,
                                                          width: 45.w,
                                                          child:
                                                          DropdownButtonHideUnderline(
                                                            child: Padding(
                                                              padding: EdgeInsets.symmetric(
                                                                  horizontal: 2.h),
                                                              child: DropdownButton<String>(
                                                                elevation: 0,
                                                                icon: Icon(
                                                                  Icons
                                                                      .keyboard_arrow_down_sharp,
                                                                  color: AppColors.black1,
                                                                ),
                                                                value: seconddropDownValue,
                                                                dropdownColor:
                                                                AppColors.grey5,
                                                                items: <String>[
                                                                  'Food Category',
                                                                  'Select'
                                                                ].map((String value) {
                                                                  return DropdownMenuItem<
                                                                      String>(
                                                                    value: value,
                                                                    child: Text(
                                                                      value,
                                                                      style: TextStyle(
                                                                          fontSize: 10.sp),
                                                                    ),
                                                                  );
                                                                }).toList(),
                                                                onChanged: (value) {
                                                                  setState(() {
                                                                    firstdropDownValue =
                                                                        value;
                                                                  });
                                                                },
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                  SizedBox(
                                                    height: 2.h,
                                                  ),
                                                  Padding(
                                                    padding: EdgeInsets.only(
                                                        left: 4.w, right: 27.w),
                                                    child: Row(
                                                      mainAxisAlignment:
                                                      MainAxisAlignment.spaceBetween,
                                                      children: [
                                                        Text(
                                                          "Religion",
                                                          style: TextStyle(
                                                              fontSize: 10.sp,
                                                              fontWeight: FontWeight.w300,
                                                              color: AppColors.grey5),
                                                        ),
                                                        Padding(
                                                          padding:  EdgeInsets.only(left: 30.w),
                                                          child: Text(
                                                            "Mother Tongue",
                                                            style: TextStyle(
                                                                fontSize: 9.sp,
                                                                fontWeight: FontWeight.w300,
                                                                color: AppColors.grey5),
                                                          ),
                                                        )
                                                      ],
                                                    ),
                                                  ),
                                                  SizedBox(
                                                    height: 2.h,
                                                  ),
                                                  Row(
                                                    mainAxisAlignment:
                                                    MainAxisAlignment.spaceEvenly,
                                                    children: [
                                                      DecoratedBox(
                                                        decoration: ShapeDecoration(
                                                          color: AppColors.white1,
                                                          shape: RoundedRectangleBorder(
                                                            borderRadius: BorderRadius.all(
                                                                Radius.circular(2.w)),
                                                          ),
                                                        ),
                                                        child: Container(
                                                          decoration: BoxDecoration(
                                                              color: AppColors.grey6,
                                                              borderRadius:
                                                              BorderRadius.circular(
                                                                  2.w),
                                                              border: Border.all(
                                                                  color: AppColors.grey6)),
                                                          height: 6.5.h,
                                                          width: 45.w,
                                                          child:
                                                          DropdownButtonHideUnderline(
                                                            child: Padding(
                                                              padding: EdgeInsets.symmetric(
                                                                  horizontal: 2.h),
                                                              child: DropdownButton<String>(
                                                                elevation: 0,
                                                                icon: Icon(
                                                                  Icons
                                                                      .keyboard_arrow_down_sharp,
                                                                  color: AppColors.black1,
                                                                ),
                                                                value: seconddropDownValue,
                                                                dropdownColor:
                                                                AppColors.grey5,
                                                                items: <String>[
                                                                  'Food Category',
                                                                  'Select'
                                                                ].map((String value) {
                                                                  return DropdownMenuItem<
                                                                      String>(
                                                                    value: value,
                                                                    child: Text(
                                                                      value,
                                                                      style: TextStyle(
                                                                          fontSize: 10.sp),
                                                                    ),
                                                                  );
                                                                }).toList(),
                                                                onChanged: (value) {
                                                                  setState(() {
                                                                    firstdropDownValue =
                                                                        value;
                                                                  });
                                                                },
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                      DecoratedBox(
                                                        decoration: ShapeDecoration(
                                                          color: AppColors.white1,
                                                          shape: RoundedRectangleBorder(
                                                            borderRadius: BorderRadius.all(
                                                                Radius.circular(2.w)),
                                                          ),
                                                        ),
                                                        child: Container(
                                                          decoration: BoxDecoration(
                                                              color: AppColors.grey6,
                                                              borderRadius:
                                                              BorderRadius.circular(
                                                                  2.w),
                                                              border: Border.all(
                                                                  color: AppColors.grey6)),
                                                          height: 6.5.h,
                                                          width: 45.w,
                                                          child:
                                                          DropdownButtonHideUnderline(
                                                            child: Padding(
                                                              padding: EdgeInsets.symmetric(
                                                                  horizontal: 2.h),
                                                              child: DropdownButton<String>(
                                                                elevation: 0,
                                                                icon: Icon(
                                                                  Icons
                                                                      .keyboard_arrow_down_sharp,
                                                                  color: AppColors.black1,
                                                                ),
                                                                value: seconddropDownValue,
                                                                dropdownColor:
                                                                AppColors.grey5,
                                                                items: <String>[
                                                                  'Food Category',
                                                                  'Select'
                                                                ].map((String value) {
                                                                  return DropdownMenuItem<
                                                                      String>(
                                                                    value: value,
                                                                    child: Text(
                                                                      value,
                                                                      style: TextStyle(
                                                                          fontSize: 10.sp),
                                                                    ),
                                                                  );
                                                                }).toList(),
                                                                onChanged: (value) {
                                                                  setState(() {
                                                                    firstdropDownValue =
                                                                        value;
                                                                  });
                                                                },
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                  SizedBox(
                                                    height: 2.h,
                                                  ),
                                                  Padding(
                                                    padding: EdgeInsets.only(
                                                        left: 4.w, right: 31.w),
                                                    child: Row(
                                                      mainAxisAlignment:
                                                      MainAxisAlignment.spaceBetween,
                                                      children: [
                                                        Text(
                                                          "Nationality",
                                                          style: TextStyle(
                                                              fontSize: 10.sp,
                                                              fontWeight: FontWeight.w300,
                                                              color: AppColors.grey5),
                                                        ),
                                                        Text(
                                                          "Literacy       ",
                                                          style: TextStyle(
                                                              fontSize: 10.sp,
                                                              fontWeight: FontWeight.w300,
                                                              color: AppColors.grey5),
                                                        )
                                                      ],
                                                    ),
                                                  ),
                                                  SizedBox(
                                                    height: 2.h,
                                                  ),
                                                  Row(
                                                    mainAxisAlignment:
                                                    MainAxisAlignment.spaceEvenly,
                                                    children: [
                                                      DecoratedBox(
                                                        decoration: ShapeDecoration(
                                                          color: AppColors.white1,
                                                          shape: RoundedRectangleBorder(
                                                            borderRadius: BorderRadius.all(
                                                                Radius.circular(2.w)),
                                                          ),
                                                        ),
                                                        child: Container(
                                                          decoration: BoxDecoration(
                                                              color: AppColors.grey6,
                                                              borderRadius:
                                                              BorderRadius.circular(
                                                                  2.w),
                                                              border: Border.all(
                                                                  color: AppColors.grey6)),
                                                          height: 6.5.h,
                                                          width: 45.w,
                                                          child:
                                                          DropdownButtonHideUnderline(
                                                            child: Padding(
                                                              padding: EdgeInsets.symmetric(
                                                                  horizontal: 2.h),
                                                              child: DropdownButton<String>(
                                                                elevation: 0,
                                                                icon: Icon(
                                                                  Icons
                                                                      .keyboard_arrow_down_sharp,
                                                                  color: AppColors.black1,
                                                                ),
                                                                value: seconddropDownValue,
                                                                dropdownColor:
                                                                AppColors.grey5,
                                                                items: <String>[
                                                                  'Food Category',
                                                                  'Select'
                                                                ].map((String value) {
                                                                  return DropdownMenuItem<
                                                                      String>(
                                                                    value: value,
                                                                    child: Text(
                                                                      value,
                                                                      style: TextStyle(
                                                                          fontSize: 10.sp),
                                                                    ),
                                                                  );
                                                                }).toList(),
                                                                onChanged: (value) {
                                                                  setState(() {
                                                                    firstdropDownValue =
                                                                        value;
                                                                  });
                                                                },
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                      DecoratedBox(
                                                        decoration: ShapeDecoration(
                                                          color: AppColors.white1,
                                                          shape: RoundedRectangleBorder(
                                                            borderRadius: BorderRadius.all(
                                                                Radius.circular(2.w)),
                                                          ),
                                                        ),
                                                        child: Container(
                                                          decoration: BoxDecoration(
                                                              color: AppColors.grey6,
                                                              borderRadius:
                                                              BorderRadius.circular(
                                                                  2.w),
                                                              border: Border.all(
                                                                  color: AppColors.grey6)),
                                                          height: 6.5.h,
                                                          width: 45.w,
                                                          child:
                                                          DropdownButtonHideUnderline(
                                                            child: Padding(
                                                              padding: EdgeInsets.symmetric(
                                                                  horizontal: 2.h),
                                                              child: DropdownButton<String>(
                                                                elevation: 0,
                                                                icon: Icon(
                                                                  Icons
                                                                      .keyboard_arrow_down_sharp,
                                                                  color: AppColors.black1,
                                                                ),
                                                                value: seconddropDownValue,
                                                                dropdownColor:
                                                                AppColors.grey5,
                                                                items: <String>[
                                                                  'Food Category',
                                                                  'Select'
                                                                ].map((String value) {
                                                                  return DropdownMenuItem<
                                                                      String>(
                                                                    value: value,
                                                                    child: Text(
                                                                      value,
                                                                      style: TextStyle(
                                                                          fontSize: 10.sp),
                                                                    ),
                                                                  );
                                                                }).toList(),
                                                                onChanged: (value) {
                                                                  setState(() {
                                                                    firstdropDownValue =
                                                                        value;
                                                                  });
                                                                },
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                  SizedBox(
                                                    height: 2.h,
                                                  ),
                                                  Padding(
                                                    padding:  EdgeInsets.only(right: 60.w),
                                                    child: Text(
                                                      "Education Level           ",
                                                      style: TextStyle(
                                                          fontSize: 10.sp,
                                                          fontWeight: FontWeight.w300,
                                                          color: AppColors.grey5),
                                                    ),
                                                  ),
                                                  SizedBox(
                                                    height: 2.h,
                                                  ),
                                                  DecoratedBox(
                                                    decoration: ShapeDecoration(
                                                      color: AppColors.white1,
                                                      shape: RoundedRectangleBorder(
                                                        borderRadius: BorderRadius.all(
                                                            Radius.circular(2.w)),
                                                      ),
                                                    ),
                                                    child: Container(
                                                      decoration: BoxDecoration(
                                                          color: AppColors.grey6,
                                                          borderRadius:
                                                          BorderRadius.circular(2.w),
                                                          border: Border.all(
                                                              color: AppColors.grey6)),
                                                      height: 6.5.h,
                                                      width: 90.w,
                                                      child: DropdownButtonHideUnderline(
                                                        child: Padding(
                                                          padding: EdgeInsets.symmetric(
                                                              horizontal: 2.h),
                                                          child: DropdownButton<String>(
                                                            elevation: 0,
                                                            icon: Icon(
                                                              Icons
                                                                  .keyboard_arrow_down_sharp,
                                                              color: AppColors.black1,
                                                            ),
                                                            value: seconddropDownValue,
                                                            dropdownColor: AppColors.grey5,
                                                            items: <String>[
                                                              'Food Category',
                                                              'Select'
                                                            ].map((String value) {
                                                              return DropdownMenuItem<
                                                                  String>(
                                                                value: value,
                                                                child: Text(
                                                                  value,
                                                                  style: TextStyle(
                                                                      fontSize: 10.sp),
                                                                ),
                                                              );
                                                            }).toList(),
                                                            onChanged: (value) {
                                                              setState(() {
                                                                firstdropDownValue = value;
                                                              });
                                                            },
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                  SizedBox(
                                                    height: 2.h,
                                                  ),

                                                  Padding(
                                                    padding: EdgeInsets.only(right: 45.w),
                                                    child: Text(
                                                      "Activity During Last 12 Months",
                                                      style: TextStyle(
                                                          fontSize: 10.sp,
                                                          fontWeight: FontWeight.w300,
                                                          color: AppColors.grey5),
                                                    ),
                                                  ),
                                                  SizedBox(
                                                    height: 2.h,
                                                  ),
                                                  DecoratedBox(
                                                    decoration: ShapeDecoration(
                                                      color: AppColors.white1,
                                                      shape: RoundedRectangleBorder(
                                                        borderRadius: BorderRadius.all(
                                                            Radius.circular(2.w)),
                                                      ),
                                                    ),
                                                    child: Container(
                                                      decoration: BoxDecoration(
                                                          color: AppColors.grey6,
                                                          borderRadius:
                                                          BorderRadius.circular(2.w),
                                                          border: Border.all(
                                                              color: AppColors.grey6)),
                                                      height: 6.5.h,
                                                      width: 90.w,
                                                      child: DropdownButtonHideUnderline(
                                                        child: Padding(
                                                          padding: EdgeInsets.symmetric(
                                                              horizontal: 2.h),
                                                          child: DropdownButton<String>(
                                                            elevation: 0,
                                                            icon: Icon(
                                                              Icons
                                                                  .keyboard_arrow_down_sharp,
                                                              color: AppColors.black1,
                                                            ),
                                                            value: seconddropDownValue,
                                                            dropdownColor: AppColors.grey5,
                                                            items: <String>[
                                                              'Food Category',
                                                              'Select'
                                                            ].map((String value) {
                                                              return DropdownMenuItem<
                                                                  String>(
                                                                value: value,
                                                                child: Text(
                                                                  value,
                                                                  style: TextStyle(
                                                                      fontSize: 10.sp),
                                                                ),
                                                              );
                                                            }).toList(),
                                                            onChanged: (value) {
                                                              setState(() {
                                                                firstdropDownValue = value;
                                                              });
                                                            },
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                  Padding(
                                                    padding:  EdgeInsets.only(right: 52.w, top: 1.h),
                                                    child: Text("For 18 Years & Above"),
                                                  ),
                                                  SizedBox(
                                                    height: 2.h,
                                                  ),
                                                  Padding(
                                                    padding:  EdgeInsets.only(right: 70.w),
                                                    child: Text("Cnic Holder"),
                                                  ),
                                                  SizedBox(
                                                    height: 2.h,
                                                  ),
                                                  Padding(
                                                    padding:  EdgeInsets.only(left: 4.5.w),
                                                    child: Row(mainAxisAlignment: MainAxisAlignment.start, children: [
                                                      Container(
                                                        height: 4.5.h,
                                                        width: 20.w,
                                                        decoration: BoxDecoration(
                                                            borderRadius: BorderRadius.circular(1.5.w),
                                                            border: Border.all(color: Colors.grey)),
                                                        child: Row(
                                                          children: [
                                                            Checkbox(
                                                              checkColor: AppColors.grey5,
                                                              value: isYes,
                                                              onChanged: (value) {
                                                                setState(() {
                                                                  isYes= value!;
                                                                  isNo = false;

                                                                });
                                                              },
                                                            ),
                                                            Text(
                                                              'Yes',
                                                              style: TextStyle(fontSize: 8.sp),
                                                            ),
                                                          ],
                                                        ),
                                                      ),
                                                      SizedBox(width: 5.w,),
                                                      Container(
                                                        height: 4.5.h,
                                                        width: 20.w,
                                                        decoration: BoxDecoration(
                                                            borderRadius: BorderRadius.circular(1.5.w),
                                                            border: Border.all(color: Colors.grey)),
                                                        child: Row(
                                                          children: [
                                                            Checkbox(
                                                              checkColor: AppColors.grey5,
                                                              value: isNo,
                                                              onChanged: (value) {
                                                                setState(() {
                                                                  isNo= value!;
                                                                  isYes = false;
                                                                });
                                                              },
                                                            ),
                                                            Text(
                                                              'NO',
                                                              style: TextStyle(fontSize: 8.sp),
                                                            ),
                                                          ],
                                                        ),
                                                      ),

                                                    ]),
                                                  ),
                                                  SizedBox(
                                                    height: 5.h,
                                                  ),

                                                  AppButton(
                                                    text: "Add Member",
                                                    onTap: () {Get.to(() => Housing());},
                                                    backgroundColor: AppColors.red1,
                                                    heightsize: 8.h,
                                                    widthsize: 90.w,
                                                  ),
                                                  SizedBox(height: 2.h,)
                                                ],
                                              ),
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ));

                            },
                            backgroundColor: AppColors.red1,
                            heightsize: 8.h,
                            widthsize: 90.w,
                          ),
                        ],
                      ),


                      SizedBox(height: 7.h,),

                    ],
                  ),
            ])));
  }
}
