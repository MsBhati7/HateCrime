import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:sizer/sizer.dart';
import 'package:untitled2/SigninMobile.dart';
import 'package:untitled2/utils/IcIcons.dart';
import 'package:untitled2/utils/colors.dart';

import 'Createnewaccount.dart';
import 'Reports History.dart';
import 'Widgets/appbuttons.dart';

class WelcomePage extends StatelessWidget {
  static const route = "/welcomePage";
  const WelcomePage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
    Stack(
      children: [
        Container(
          color: AppColors.red1,
          width: 100.w,
          height: 100.h,
          child:  Image.asset(IcIcons.Welcome2,fit: BoxFit.fill,),
        ),
        Padding(
          padding:  EdgeInsets.only(left: 25.w,top: 30.h),
          child: Image.asset(IcIcons.group1,width: 50.w,),
        ),
        Padding(
          padding:  EdgeInsets.only(left: 37.w,top: 7.h),
          child: Image.asset(IcIcons.group,width: 25.w,),
        ),
        Padding(
          padding: EdgeInsets.only(left: 33.w,top: 20.h),
          child: Text("WELCOME TO",style: TextStyle(fontSize: 16.sp,fontWeight: FontWeight.bold,color: AppColors.black1),),
        ),
Padding(
  padding:  EdgeInsets.only(left: 23.w,top: 25.h),
  child:   Text("BUILDING A STRONG SELF-RELIANT\n                     COMMUNITY",style: TextStyle(fontSize: 10.sp,fontWeight: FontWeight.bold,color: AppColors.grey1),),
),
Padding(
  padding: EdgeInsets.only(left: 17.w,top: 55.h),
  child:   Text("     COMMUNION is an online platform that enables\n  strengthening of community through authentic and   \ninstances hate-crime reporting, authentic census for     \n      the community and eventually through various\n                    empowerment opportunities. ",style: TextStyle(fontSize: 9.sp,fontWeight: FontWeight.bold,color: AppColors.grey1),),
),
        SizedBox(height: 7.h,),
        Padding(
          padding:  EdgeInsets.only(left: 3.h,top: 70.h),
          child:    GestureDetector(
            onTap: () {

              Get.to(() => SigninMobile());

            },
            child: Container(
                alignment: Alignment.center,
                width: 90.w,
                height: 8.h,
                decoration: BoxDecoration(
                  color: AppColors.grey7,
                  borderRadius: BorderRadius.circular(3.w),

                ),
                child: Padding(
                  padding: EdgeInsets.all(1.h),
                  child: Text(
                    "SIGN-IN WITH MOBILE NUMBER",
                    style: TextStyle(
                      color: AppColors.red1,
                      fontSize: 9.sp,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                )),
          ),

        ),
        Padding(
          padding:  EdgeInsets.only(left: 3.h,top: 80.h),
          child:    GestureDetector(
            onTap: () {

              Get.to(() => SigninMobile());

            },
            child: Container(
                alignment: Alignment.center,
                width: 90.w,
                height: 8.h,
                decoration: BoxDecoration(
                  color: AppColors.grey7,
                  borderRadius: BorderRadius.circular(3.w),

                  border: Border.all(
                    color: AppColors.white1,
                    width: 0.2.h,
                  ),
                ),
                child: Padding(
                  padding: EdgeInsets.all(1.h),
                  child: Text(
                    "SIGN-IN WITH EMAIL ADDRESS",
                    style: TextStyle(
                      color: AppColors.red1,
                      fontSize: 9.sp,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                )),
          ),

        ),
        Padding(
          padding:  EdgeInsets.only(left: 3.h,top: 90.h),
          child:    GestureDetector(
            onTap: () {

              Get.to(() => CreateNewAccount());

            },
            child: Container(
                alignment: Alignment.center,
                width: 90.w,
                height: 8.h,
                decoration: BoxDecoration(
                  color: AppColors.red1,
                  borderRadius: BorderRadius.circular(3.w),

                  border: Border.all(
                    color: AppColors.white1,
                    width: 0.2.h,
                  ),
                ),
                child: Text(
                  "CREATE NEW ACCOUNT",
                  style: TextStyle(
                    color: AppColors.white1,
                    fontSize: 9.sp,
                    fontWeight: FontWeight.bold,
                  ),
                )),
          ),

        ),




      ],
    )
              
        ]));
  }
}
