import 'package:flutter/material.dart';
import 'package:get/get.dart';

import 'package:sizer/sizer.dart';
import 'package:untitled2/Alert.dart';
import 'package:untitled2/DASHBOARD1.dart';
import 'package:untitled2/Drawer.dart';

import 'package:untitled2/utils/IcIcons.dart';
import 'package:untitled2/utils/colors.dart';



class ReportsHistory extends StatefulWidget {
  static const route = "/reportsHistory";

  ReportsHistory({Key? key}) : super(key: key);

  @override
  State<ReportsHistory> createState() => _ReportsHistoryState();
}

class _ReportsHistoryState extends State<ReportsHistory> {

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        elevation: 0.0,
        title: Text(
          "Reports History",
          style: TextStyle(
            fontSize: 14.sp,
            fontWeight: FontWeight.bold,
            color: AppColors.black1,
          ),
        ),
        leading: IconButton(onPressed: () { Get.to(() => Alerts());},
            icon: Icon(Icons.arrow_back,color: AppColors.black1,size: 5.w,)),
        backgroundColor: AppColors.white1,
      ),
      body: SingleChildScrollView(
          child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Padding(
                  padding:  EdgeInsets.only(right: 45.w),
                  child: Text("Hate-Crime Reports",style: TextStyle(
                    fontSize: 14.sp,
                    fontWeight: FontWeight.bold,
                    color: AppColors.black1,
                  ),),
                ),
                Container(),
                SizedBox(
                  height: 3.h,
                ),
                Padding(
                  padding:  EdgeInsets.only(left: 4.w),
                  child: Row(
                    children: [
                      Image.asset(IcIcons.History1,width: 15.w,),

                      Padding(
                        padding:  EdgeInsets.only(left: 4.w),
                        child: RichText(text: TextSpan(
                            text: "Hate-Crime Report Title 003\n",style: TextStyle(height: 0.3.h,fontSize: 10.sp,fontWeight: FontWeight.bold,color: AppColors.black1),

                            children: [
                              TextSpan(
                                  text: "8304 W Central Ave, Wichita, KS 67212\n",style: TextStyle(fontSize: 8.sp,color: AppColors.grey5)),

                              TextSpan(
                                text: "12 Dec 2021",style: TextStyle(fontSize: 10.sp,color: AppColors.grey1),
                              ),

                              TextSpan(
                                text: " 12:30 PM",style: TextStyle(fontSize: 10.sp,color: AppColors.black1),
                              ),

                            ])),
                      ),

                      Padding(
                        padding:  EdgeInsets.only(left: 9.w,top: 4.5.h),
                        child: Container(
                          alignment: Alignment.center,
                          height: 2.5.h,
                          width: 13.w,
                          decoration: BoxDecoration(
                              color: Colors.green,
                              borderRadius: BorderRadius.circular(2.w)
                          ),
                          child: Text("Verified",style: TextStyle(fontSize: 7.sp,color: AppColors.white1)),
                        ),
                      ),
                      Padding(
                        padding:  EdgeInsets.only(bottom: 7.h,),
                        child: Image.asset(IcIcons.doats1,width: 0.6.w,),
                      )
                    ],
                  ),
                ),
                Divider(),
                Padding(
                  padding:  EdgeInsets.only(left: 4.w),
                  child: Row(
                    children: [
                      Image.asset(IcIcons.History2,width: 15.w,),

                      Padding(
                        padding:  EdgeInsets.only(left: 4.w),
                        child: RichText(text: TextSpan(
                            text: "Hate-Crime Report Title 003\n",style: TextStyle(height: 0.3.h,fontSize: 10.sp,fontWeight: FontWeight.bold,color: AppColors.black1),

                            children: [
                              TextSpan(
                                  text: "8304 W Central Ave, Wichita, KS 67212\n",style: TextStyle(fontSize: 8.sp,color: AppColors.grey5)),

                              TextSpan(
                                text: "12 Dec 2021",style: TextStyle(fontSize: 10.sp,color: AppColors.grey1),
                              ),

                              TextSpan(
                                text: " 12:30 PM",style: TextStyle(fontSize: 10.sp,color: AppColors.black1),
                              ),

                            ])),
                      ),

                      Padding(
                        padding:  EdgeInsets.only(top: 5.h),
                        child: Container(
                          alignment: Alignment.center,
                          height: 2.5.h,
                          width: 20.w,
                          decoration: BoxDecoration(
                              color: Colors.yellow,
                              borderRadius: BorderRadius.circular(2.w)
                          ),
                          child: Text("Pending Verification",style: TextStyle(fontWeight: FontWeight.bold,fontSize: 6.sp,color: AppColors.white1)),
                        ),
                      ),
                      Padding(
                        padding:  EdgeInsets.only(bottom: 2.h,),
                        child: Image.asset(IcIcons.doats1,width: 0.6.w,),
                      )
                    ],
                  ),
                ),

                Divider(),
                Padding(
                  padding:  EdgeInsets.only(left: 4.w),
                  child: Row(
                    children: [
                      Image.asset(IcIcons.History3,width: 15.w,),

                      Padding(
                        padding:  EdgeInsets.only(left: 4.w),
                        child: RichText(text: TextSpan(
                            text: "Hate-Crime Report Title 003\n",style: TextStyle(height: 0.3.h,fontSize: 10.sp,fontWeight: FontWeight.bold,color: AppColors.black1),

                            children: [
                            TextSpan(
                            text: "8304 W Central Ave, Wichita, KS 67212\n",style: TextStyle(fontSize: 8.sp,color: AppColors.grey5)),

                              TextSpan(
                                text: "12 Dec 2021",style: TextStyle(fontSize: 10.sp,color: AppColors.grey1),
                              ),

                              TextSpan(
                                text: " 12:30 PM",style: TextStyle(fontSize: 10.sp,color: AppColors.black1),
                              ),

                            ])),
                      ),

                      Padding(
                        padding:  EdgeInsets.only(left: 9.w,top: 4.5.h),
                        child: Container(
                          alignment: Alignment.center,
                          height: 2.5.h,
                          width: 13.w,
                          decoration: BoxDecoration(
                              color: Colors.blue,
                              borderRadius: BorderRadius.circular(2.w)
                          ),
                          child: Text("Resolved",style: TextStyle(fontSize: 7.sp,color: AppColors.white1)),
                        ),
                      ),
   Padding(
     padding:  EdgeInsets.only(bottom: 7.h,),
     child: Image.asset(IcIcons.doats1,width: 0.6.w,),
   )
                    ],
                  ),
                ),

              ])),
    );
  }
}
