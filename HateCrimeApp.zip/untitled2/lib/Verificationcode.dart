import 'package:flutter/material.dart';
import 'package:get/route_manager.dart';
import 'package:otp_text_field/otp_field.dart';
import 'package:otp_text_field/style.dart';

import 'package:sizer/sizer.dart';
import 'package:untitled2/DASHBOARD1.dart';
import 'package:untitled2/Email.dart';
import 'package:untitled2/Recoverpassword.dart';

import 'package:untitled2/utils/IcIcons.dart';
import 'package:untitled2/utils/colors.dart';

import 'SigninMobile.dart';
import 'Widgets/appbuttons.dart';

class VerificationCode extends StatelessWidget {
  // final person = List<String>.generate(3, (i) => 'Person ${i+1 }' );
  static const route = "/verificationCode";

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        elevation: 0.0,
        title: Padding(
          padding: EdgeInsets.only(left: 12.w),
          child: Text(
            " Verification Code",
            style: TextStyle(
              fontSize: 14.sp,
              fontWeight: FontWeight.w500,
              color: Colors.black87,
            ),
          ),
        ),
        leading: IconButton(
            onPressed: () {Get.to(() => SigninMobile());},
            icon: Icon(Icons.arrow_back,color: AppColors.black1,size: 5.w,)),
        backgroundColor: AppColors.white1,
      ),
      body: SingleChildScrollView(
          child: Padding(
            padding: EdgeInsets.only(left: 4.w),
            child: Column(
               mainAxisAlignment: MainAxisAlignment.center,

                children: [

                  Text(
                    "Enter Verification Code",
                    style: TextStyle(
                        height: 0.3.h,
                        fontSize: 18.sp,
                        fontWeight: FontWeight.bold,
                        color: Colors.black),
                  ),

                  Text(
                    "We have sent you a 4 digit ",
                    style: TextStyle(
                       height: 0.7.h,
                        fontSize: 11.sp,
                        fontWeight: FontWeight.w500,
                        color: AppColors.grey2),
                  ),

          Text(
            "Verification code on +199988550090",
            style: TextStyle(
                fontSize: 11.sp,
                fontWeight: FontWeight.w500,
                color: AppColors.grey2),
          ),
                  SizedBox(
                    height: 5.h,
                  ),

                  Container(

                    width: 70.w,
                    child: OTPTextField(
                      length: 4,
// width: MediaQuery.of(context).size.width,
                      fieldWidth: 14.w,
                      style: TextStyle(

                          fontSize: 12.sp,
                        fontWeight: FontWeight.bold
                      ),
                      textFieldAlignment: MainAxisAlignment.spaceAround,
                      fieldStyle: FieldStyle.box,
                      onCompleted: (pin) {
                        print("Completed: " + pin);
                      },
                    ),
                  ),
SizedBox(height: 7.h,),

                  Text(
                    "DID NOT RECEIVE VERIFICATION CODE?",
                    style: TextStyle(
                        fontSize: 10.sp,
                        fontWeight: FontWeight.w500,
                        color: AppColors.grey5),
                  ),
SizedBox(height: 3.h,),
                  GestureDetector(
                      onTap: () {},
                      child: Container(
                        alignment: Alignment.center,
                        width: 50.w,
                        height: 5.h,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(1.5.w),
                          color: AppColors.grey7,
                          border: Border.all(
                            color: AppColors.red1,
                            width: 0.2.h,
                          ),
                        ),
                        child: Text(
                          "RESEND VERIFICATION CODE ",
                          style: TextStyle(
                            color: Colors.black87,
                            fontSize: 9.sp,
                            fontWeight: FontWeight.bold,

                          ),
                        ),
                      )),


SizedBox(height: 25.h,),


            AppButton(
              text: "SUBMIT AND SIGN-IN",

              onTap: () {
                Get.to(() => SigninMobile());
              },
              backgroundColor: AppColors.red1,
              heightsize: 9.h,
              widthsize: 93.w,
            ),

                  SizedBox(
                    height: 8.h,
                  ),


                ]),
          )),
    );
  }
}
