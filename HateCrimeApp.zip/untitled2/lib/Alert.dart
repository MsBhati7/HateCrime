import 'package:flutter/material.dart';
import 'package:get/get.dart';

import 'package:sizer/sizer.dart';
import 'package:untitled2/AddHouseholdMember.dart';
import 'package:untitled2/Add Household Member.dart';
import 'package:untitled2/Drawer.dart';
import 'package:untitled2/HousingCensus.dart';
import 'package:untitled2/HousingCensusForm1.dart';

import 'package:untitled2/utils/IcIcons.dart';
import 'package:untitled2/utils/colors.dart';



class Alerts extends StatefulWidget {
  static const route = "/alerts";

  Alerts({Key? key}) : super(key: key);

  @override
  State<Alerts> createState() => _AlertsState();
}

class _AlertsState extends State<Alerts> {

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        elevation: 0.0,
        title: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Padding(
              padding:  EdgeInsets.only(right: 15.w),
              child: Text(
                "Alerts",
                style: TextStyle(
                  fontSize: 14.sp,
                  fontWeight: FontWeight.bold,
                  color: AppColors.black1,
                ),
              ),
            ),



          ],
        ),
        leading: IconButton(onPressed: () { Get.to(() =>HousingCensusForm1());},
           icon: Icon(Icons.arrow_back,color: AppColors.black1,size: 5.w,)),
        backgroundColor: AppColors.white1,
      ),
      body: SingleChildScrollView(
          child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Container(),
                SizedBox(
                  height: 3.h,
                ),
             
                ListTile(
                  leading: CircleAvatar(
                    radius: 7.w,
                      backgroundColor: AppColors.orange1,
                      child: Image.asset(IcIcons.bell1,width: 5.w,)),
                  title: Text("The Crime-Tracking App Which Recently\nLaunched",style: TextStyle(fontSize: 10.sp,fontWeight: FontWeight.bold),),
  //
  //                 subtitle: Padding(
  // padding:  EdgeInsets.only(left: 50.w),
  // child:   Text("30 minutes"),

trailing: Padding(
  padding: EdgeInsets.only(bottom: 4.h,right: 4.w),
  child:   CircleAvatar(
    radius: 0.8.w,
    backgroundColor: AppColors.red1,
  ),
),
                                   subtitle: Padding(
                                     padding:  EdgeInsets.only(left: 45.w),
                                     child: Text(" 30 minutes",style: TextStyle(fontSize: 8.sp),),
                                   ),

                ),


                Divider(),
                ListTile(
                  leading: Image.asset(IcIcons.tracking2),
                  title: Text("The Crime-Tracking App Which Recently\nLaunched",style: TextStyle(fontSize: 10.sp,fontWeight: FontWeight.bold),),
                  subtitle: Padding(
                    padding:  EdgeInsets.only(left: 45.w),
                    child: Text(" 1 hour agp",style: TextStyle(fontSize: 8.sp),),
                  ),
                  trailing: Padding(
                    padding: EdgeInsets.only(bottom: 4.h,right: 4.w),
                    child:   CircleAvatar(
                      radius: 0.8.w,
                      backgroundColor: AppColors.red1,
                    ),
                  ),
                ),
                Divider(),
                ListTile(
                  leading: Image.asset(IcIcons.tracking1,width: 14.w,),
                  title: Text("The Crime-Tracking App Which Recently\nLaunched",style: TextStyle(fontSize: 10.sp,fontWeight: FontWeight.bold),),
                  subtitle: Padding(
                    padding:  EdgeInsets.only(left: 45.w),
                    child: Text(" 1 hour ago",style: TextStyle(fontSize: 8.sp),),
                  ),
                  trailing: Padding(
                    padding: EdgeInsets.only(bottom: 5.h,right: 4.w),
                    child:   CircleAvatar(
                      radius: 0.8.w,
                      backgroundColor: AppColors.red1,
                    ),
                  ),
                ),

                SizedBox(
                  height: 8.h,
                ),
              ])),
    );
  }
}
