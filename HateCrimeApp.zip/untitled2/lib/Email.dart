import 'package:flutter/material.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:get/get_navigation/get_navigation.dart';

import 'package:sizer/sizer.dart';
import 'package:untitled2/Createnewaccount.dart';
import 'package:untitled2/SigninMobile.dart';
import 'package:untitled2/utils/IcIcons.dart';
import 'package:untitled2/utils/colors.dart';

import 'Recoverpassword.dart';

class Email extends StatelessWidget {
  // final person = List<String>.generate(3, (i) => 'Person ${i+1 }' );
  static const route = "/email";

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(

        elevation: 0.0,
        title: Text(
          " Sign-  ",
          style: TextStyle(
            fontSize: 16.sp,
            fontWeight: FontWeight.bold,
            color: AppColors.black1,
          ),
        ),
        leading: IconButton(
            onPressed: () {},
            icon: GestureDetector(
    onTap: () {
    Get.to(() => SigninMobile ());
    },
    child:Image.asset(IcIcons.backarrow,width: 5.w,)

        ),),
        backgroundColor: AppColors.white1,
      ),

      body: SingleChildScrollView(
          child:
              Column(
                  crossAxisAlignment: CrossAxisAlignment.center, children: [
                SizedBox(height: 7.h,),
                Text(
                  "Sign-in to your account",
                  style: TextStyle(fontSize: 20.sp,fontWeight: FontWeight.bold ,color: AppColors.black1),
                ),
        SizedBox(height: 7.h,),
        Container(
          alignment: Alignment.center,
          height: 8.h,
          width: 90.w,
          decoration: BoxDecoration(
            color: AppColors.grey7,
            borderRadius: BorderRadius.circular(3.w)
          ),
          child: TextFormField(
            keyboardType: TextInputType.emailAddress,

            decoration: InputDecoration(
              hintText: "Email Address",
              border: InputBorder.none,
              focusedBorder: InputBorder.none,
              enabledBorder: InputBorder.none,
              errorBorder: InputBorder.none,
              disabledBorder: InputBorder.none,
              hintStyle: TextStyle(
                  fontSize: 14.sp,
                  fontWeight: FontWeight.w500,
                  color: AppColors.grey4),
             contentPadding: EdgeInsets.only(left: 5.w)
            ),
          ),
        ),
       SizedBox(height: 6.w,),
                Container(
                  alignment: Alignment.center,
                  height: 8.h,
                  width: 90.w,
                  decoration: BoxDecoration(
                      color: AppColors.grey7,
                      borderRadius: BorderRadius.circular(3.w)
                  ),
                  child: TextFormField(
          keyboardType: TextInputType.number,
          decoration: InputDecoration(
              hintText: "Password",
              border: InputBorder.none,
              focusedBorder: InputBorder.none,
              enabledBorder: InputBorder.none,
              errorBorder: InputBorder.none,
              disabledBorder: InputBorder.none,
              hintStyle: TextStyle(
                    fontSize: 14.sp,
                    fontWeight: FontWeight.w500,
                    color: AppColors.grey4),
contentPadding: EdgeInsets.only(left: 5.w, top: 2.h),
              suffixIcon: Image.asset(
                  IcIcons.eye1,

              )),
        ),
                ),
        SizedBox(
          height: 2.h,
        ),
        Padding(
          padding: EdgeInsets.only(right: 5.w),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              Text(
                "Forgot Your Password ?  ",
                style: TextStyle(
                    fontSize: 10.sp,
                    fontWeight: FontWeight.w500,
                    color: AppColors.red1),
              ),
              Image.asset(
                IcIcons.arrow,
                width: 4.w,
              )
            ],
          ),
        ),
        SizedBox(
          height: 25.h,
        ),
        GestureDetector(
            onTap: () {},
            child: Container(
              alignment: Alignment.center,
              width: 90.w,
              height: 9.h,
              decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(10.0),
              color: AppColors.red1
              ),
              child: Padding(
                padding: EdgeInsets.all(1.w),
                child: GestureDetector(
                  onTap: () {
                    Get.to(() => SigninMobile());
                  },

                  child:Text(
                  "SIGN-IN ",
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 10.sp,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            )),
        ),
        SizedBox(
          height: 3.h,
        ),
        GestureDetector(
            onTap: () {

              Get.to(() => CreateNewAccount());

            },
            child: Container(
              alignment: Alignment.center,
              width: 90.w,
              height: 9.h,
              decoration: BoxDecoration(
                color: AppColors.grey7,
                borderRadius: BorderRadius.circular(3.w),

                border: Border.all(
                  color: AppColors.red1,
                  width: 0.2.h,
                ),
              ),
              child: Padding(
                padding: EdgeInsets.all(1.h),
                child: Text(
                    "CREATE A NEW ACCOUNT ",
                    style: TextStyle(
                      color: Colors.black54,
                      fontSize: 12.sp,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
            )),
        ),
                SizedBox(height: 5.h,),
              ]


              )
      ),
    );
  }
}
