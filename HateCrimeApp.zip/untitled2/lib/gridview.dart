import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';
import 'package:untitled2/utils/IcIcons.dart';
// import 'package:sizer/sizer.dart';
// import 'package:untitled2/utils/IcIcons.dart';
//
// import 'package:untitled2/utils/colors.dart';



class GridView1 extends StatefulWidget {
  static const route = "/gridView1";

  @override
  State<GridView1> createState() => _GridView1State();
}

class _GridView1State extends State<GridView1> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(

          elevation: 0.0,
          title: Padding(
            padding:  EdgeInsets.only(left: 5.w),
            child: Text(
              " Chefs near by me  ",
              style: TextStyle(
                fontSize: 16.sp,
                fontWeight: FontWeight.bold,
                color: Colors.black,
              ),
            ),
          ),
          leading: IconButton(
              onPressed: () {},
              icon: Image.asset(IcIcons.backarrow,width: 5.w,)

          ),
          backgroundColor: Colors.white,
        ),
             body: GridView.builder(
                 itemCount: 20,


                 gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2),
                 itemBuilder: (context,index){
                   return Container(
                     width: 50.w,
                     child: Card(
                       elevation: 0.0,
                       color: Colors.white,
                       child: Column(
                         children: [
                           Image.asset(IcIcons.tick5, ),
                           SizedBox(height: 3.h),
                           Text("Delicious sea food"),
                           Text("Cia Home Food"),
                           Padding(
                             padding:  EdgeInsets.only(right: 22.w),
                             child: Container(
                               alignment: Alignment.center,
                               decoration: BoxDecoration(
                                   color: Colors.deepOrange,
                                 borderRadius: BorderRadius.circular(5.w)
                               ),
                               height: 3.h,
                               width: 20.w,
child: Row(
  children: [
    Text("      3 KM",style: TextStyle(color: Colors.white),)
  ],
),
                             ),
                           )
                         ],
                       ),
                     ),
                   );


                 })
        
        
        
        
        // ListView.separated(
      //   itemCount: 10,
      //   itemBuilder: (BuildContext context, int index) {
      //     return Container(
      //         color: Colors.white24,
      //         child: Column(
      //
      //             children: [
      //               Container(
      //
      //                   padding: EdgeInsets.only(top: 1.h),
      //
      //                   height: 35.h,
      //                   width: 45.h,
      //
      //                   child: Card(
      //                     child: Image.asset(IcIcons.tick5,fit: BoxFit.fill,),
      //                   ))]));
      //
      //   },
      //   separatorBuilder: (BuildContext context, int index) {
      //     return SizedBox(
      //       height: 3.h,
      //     );
      //   },
      // )
        );
        
          }
}
