import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_core/get_core.dart';

import 'package:sizer/sizer.dart';
import 'package:untitled2/DASHBOARD1.dart';
import 'package:untitled2/YourDetails.dart';
import 'package:untitled2/spalash.dart';
import 'package:untitled2/utils/IcIcons.dart';
import 'package:untitled2/utils/colors.dart';


import 'Widgets/appbuttons.dart';

class SignUoType2 extends StatelessWidget {

  static const route = "/signUoType2";

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(

        elevation: 0.0,
        title: Text(
          " Sign-up for Type 2 Account",
          style: TextStyle(
            fontSize: 12.sp,
            fontWeight: FontWeight.bold,
            color: AppColors.black1,
          ),
        ),
        leading: IconButton(
            onPressed: () {Get.to(() => YourDetails());},
            icon: Icon(Icons.arrow_back,color: AppColors.black1,size: 5.w,)),
        backgroundColor: AppColors.white1,
      ),


      body: SingleChildScrollView(
          child: Column(children: [
            Container(

            ),
            SizedBox(
              height: 3.h,
            ),
            Padding(
              padding:  EdgeInsets.only(right: 5.w),
              child: Text(
               "Thank you for your intention and will to serve and\nhelp your community\nwe have received your details and request for a\nType 2 Account.\nwe will contract your pastor/priest and as soon as\nwe receive confirmation form them we will enable\nyour Type 2 Account which will provide you \nenhanced functions and opportunities.\nyou will we alerted by a text message on your given\nphone number when your account has been\nactivated.\nThank you ",
                style: TextStyle(fontSize: 11.sp,fontWeight: FontWeight.w500 ,color: AppColors.grey2, height: 0.2.h),


                  ),
            ),






            SizedBox(
              height: 15.h,
            ),

          Image.asset(IcIcons.Logo,width: 30.w,),
            SizedBox(height: 10.h,),
          GestureDetector(
              onTap: () {
                Get.to(() => Spalash ());
              },

              child:AppButton(
              text: "END SESSION",

              onTap: () {Get.to(() => DashBoard1());},
              backgroundColor: AppColors.red1,
              heightsize: 8.h,
              widthsize: 90.w,
            ),
          ),
SizedBox(height: 5.h,),

          ])),





    );
  }
}
