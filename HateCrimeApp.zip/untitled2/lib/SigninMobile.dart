import 'package:flutter/material.dart';
import 'package:get/get_core/get_core.dart';
import 'package:get/get_navigation/get_navigation.dart';


import 'package:sizer/sizer.dart';
import 'package:untitled2/Createnewaccount.dart';
import 'package:untitled2/Email.dart';

import 'package:untitled2/Recoverpassword.dart';
import 'package:untitled2/Verificationcode.dart';
import 'package:untitled2/proclamationform.dart';

import 'package:untitled2/utils/IcIcons.dart';
import 'package:untitled2/utils/colors.dart';

import 'Widgets/appbuttons.dart';

class SigninMobile extends StatelessWidget {

  static const route = "/signinMobile";

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2,
      child:(
        Scaffold(
            appBar: AppBar(

              elevation: 0.0,
              title: Padding(
                padding:  EdgeInsets.only(left: 22.w),
                child: Text(
                  " Sign- in",
                  style: TextStyle(
                    fontSize: 12.sp,

                    color: AppColors.black1,
                  ),
                ),
              ),
              leading: IconButton(
                onPressed: () {Get.to(() =>CreateNewAccount());},
                  icon: Icon(Icons.arrow_back,color: AppColors.black1,size: 5.w,)),
              backgroundColor: AppColors.white1,
                ),




            body: SingleChildScrollView(
                child: Column(children: [
              Container(

              ),
              SizedBox(
                height: 2.h,
              ),
              Text(
                "Sign-in to your account",
                style: TextStyle(fontSize: 16.sp,fontWeight: FontWeight.bold ,color: AppColors.black1),
              ),
              SizedBox(
                height: 7.h,
              ),
Container(
  height: 7.h,
  width: 65.w,
  decoration: BoxDecoration(
        color: AppColors.grey7,
        borderRadius: BorderRadius.circular(3.w)
  ),
  child:   Padding(
    padding:  EdgeInsets.all(2.w),
    child: TabBar(
        indicator: BoxDecoration(color: AppColors.white1,borderRadius: BorderRadius.circular(2.w)),
        tabs: [

      Text(
        "  MOBILE",
        style: TextStyle(fontSize: 10.sp, color: AppColors.black1),
      ),
      Text(
        "  EMAIL",
        style: TextStyle(fontSize: 10.sp, color: AppColors.black1),
      ),
    ]),
  ),
),
SizedBox(height: 7.h,),

                  SizedBox(
                    height: 60.h,
                    child: TabBarView(
                      children: [
                        Column(
                          children: [
                            Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [

                                Container(
height: 8.h,
                                  width: 90.w,
                                  decoration: BoxDecoration(
                                    color: AppColors.grey6,
                                    borderRadius: BorderRadius.circular(2.w)
                                  ),
                                  child: TextFormField(

                                    keyboardType: TextInputType.phone,

                                    decoration: InputDecoration(
                                      icon: Text("  +1", style:TextStyle(fontSize: 11.sp, fontWeight: FontWeight.w500 ,color: Colors.black87),),
                                      contentPadding: EdgeInsets.only(top: 2.5.h),
                                        border: InputBorder.none,
                                        focusedBorder: InputBorder.none,
                                        enabledBorder: InputBorder.none,
                                        errorBorder: InputBorder.none,
                                        disabledBorder: InputBorder.none,
                                        hintText: "9988550090",
                                        hintStyle:
                                        TextStyle(fontSize: 11.sp, fontWeight: FontWeight.w500 ,color: Colors.black87),
                                        suffixIcon: Image.asset(IcIcons.arrow1,width: 2.5.w,)
                                    ),
                                  ),
                    ),
                                  ]),
                                  SizedBox(height: 5.h,),
                                  Text("CLICK HERE TO CONTRACT ADMIN IF YOUR",style: TextStyle(fontSize: 9.sp,fontWeight: FontWeight.bold,color: Colors.black54),),


                                  SizedBox(height: 3.h,),

                                  GestureDetector(
                                    onTap: () {},
                                    child: Container(
                                        alignment: Alignment.center,
                                        width: 50.w,
                                        decoration: BoxDecoration(
                                          color: AppColors.grey7,
                                          borderRadius: BorderRadius.circular(8.0),

                                          border: Border.all(
                                            color: AppColors.red1,
                                            width: 0.2.h,
                                          ),
                                        ),
                                        child: Padding(
                                          padding: EdgeInsets.all(2.h),
                                          child: Text(
                                            "CONTRACT ADMINISTRATOR ",
                                            style: TextStyle(
                                              color: Colors.black87,
                                              fontSize: 7.sp,
                                              fontWeight: FontWeight.bold,

                                            ),
                                          ),
                                        )),
                                  ),
                                  SizedBox(height: 10.h,),
                                  AppButton(
                                    text: "REQUEST VERIFICATION CODE",

                                    onTap: () {Get.to(() => VerificationCode ());},
                                    backgroundColor: AppColors.red1,
                                    heightsize: 9.h,
                                    widthsize: 90.w,
                                  ),
                                  SizedBox(height: 3.h,),

                                  GestureDetector(
                                      onTap: () {  Get.to(() => CreateNewAccount ());},
                                      child: Container(
                                        alignment: Alignment.center,
                                        width: 90.w,
                                        height: 9.h,
                                        decoration: BoxDecoration(
                                          color: AppColors.grey7,
                                          borderRadius: BorderRadius.circular(3.w),


                                          border: Border.all(
                                            color: AppColors.red1,
                                            width: 0.2.h,
                                          ),
                                        ),
                                        child: Padding(
                                          padding: EdgeInsets.all(3.h),
                                          child: Text(
                                            "CREATE A NEW ACCOUNT ",
                                            style: TextStyle(
                                              color: Colors.black54,
                                              fontSize: 8.sp,
                                              fontWeight: FontWeight.bold,

                                            ),
                                          ),
                                        ),
                                      )),


                              ],
                            ),

                        Column(
                            crossAxisAlignment: CrossAxisAlignment.center, children: [


                          Container(
                            alignment: Alignment.center,
                            height: 8.h,
                            width: 90.w,
                            decoration: BoxDecoration(
                                color: AppColors.grey7,
                                borderRadius: BorderRadius.circular(3.w)
                            ),
                            child: TextFormField(
                              keyboardType: TextInputType.emailAddress,

                              decoration: InputDecoration(
                                  hintText: "Email Address",
                                  border: InputBorder.none,
                                  focusedBorder: InputBorder.none,
                                  enabledBorder: InputBorder.none,
                                  errorBorder: InputBorder.none,
                                  disabledBorder: InputBorder.none,
                                  hintStyle: TextStyle(
                                      fontSize: 11.sp,
                                      fontWeight: FontWeight.w500,
                                      color: AppColors.grey4),
                                  contentPadding: EdgeInsets.only(left: 5.w)
                              ),
                            ),
                          ),
                          SizedBox(height: 6.w,),
                          Container(
                            alignment: Alignment.center,
                            height: 8.h,
                            width: 90.w,
                            decoration: BoxDecoration(
                                color: AppColors.grey7,
                                borderRadius: BorderRadius.circular(3.w)
                            ),
                            child: TextFormField(
                              keyboardType: TextInputType.number,
                              decoration: InputDecoration(
                                  hintText: "Password",
                                  border: InputBorder.none,
                                  focusedBorder: InputBorder.none,
                                  enabledBorder: InputBorder.none,
                                  errorBorder: InputBorder.none,
                                  disabledBorder: InputBorder.none,
                                  hintStyle: TextStyle(
                                      fontSize: 11.sp,
                                      fontWeight: FontWeight.w500,
                                      color: AppColors.grey4),
                                  contentPadding: EdgeInsets.only(left: 5.w, top: 2.h),
                                  suffixIcon: Image.asset(
                                    IcIcons.eye1,
                                    width: 5.w,

                                  )),
                            ),
                          ),
                          SizedBox(
                            height: 2.h,
                          ),
                          Padding(
                            padding: EdgeInsets.only(right: 5.w),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.end,
                              children: [
                                GestureDetector(
                                  onTap: () {
                          Get.to(() => RecoverPassword());
                          },
                                  child: Text(

                                    "Forgot Your Password ?  ",
                                    style: TextStyle(
                                        fontSize: 10.sp,
                                        fontWeight: FontWeight.bold,
                                        color: AppColors.red1),
                                  ),
                                ),
                                Image.asset(
                                  IcIcons.arrow,
                                  width: 4.w,
                                )
                              ],
                            ),
                          ),
                          SizedBox(
                            height: 12.h,
                          ),
                          GestureDetector(
                            onTap: () {Get.to(() => ProclamationForm());},
                            child: Container(
                                alignment: Alignment.center,
                                width: 90.w,
                                height: 9.h,
                                decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(10.0),
                                    color: AppColors.red1
                                ),
                                child: Padding(
                                  padding: EdgeInsets.all(1.w),
                                  child: Text(
                                    "SIGN-IN ",
                                    style: TextStyle(
                                      color: Colors.white,
                                      fontSize: 10.sp,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                )),
                          ),
                          SizedBox(
                            height: 3.h,
                          ),
                          GestureDetector(
                            onTap: () {

                              Get.to(() => CreateNewAccount());

                            },
                            child: Container(
                                alignment: Alignment.center,
                                width: 90.w,
                                height: 9.h,
                                decoration: BoxDecoration(
                                  color: AppColors.grey7,
                                  borderRadius: BorderRadius.circular(3.w),

                                  border: Border.all(
                                    color: AppColors.red1,
                                    width: 0.2.h,
                                  ),
                                ),
                                child: Padding(
                                  padding: EdgeInsets.all(1.h),
                                  child: Text(
                                    "CREATE A NEW ACCOUNT ",
                                    style: TextStyle(
                                      color: Colors.black87,
                                      fontSize: 10.sp,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                )),
                          ),

                        ]


                        )
                      ],
                    ),
                  ),



            ])),







            )   ));
  }
}
