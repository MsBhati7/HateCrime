import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';
import 'package:untitled2/utils/IcIcons.dart';
import 'package:untitled2/utils/colors.dart';



class BottomSheet2 extends StatefulWidget {
  static const route = "/bottomSheet2";

  @override
  State<BottomSheet2> createState() => _BottomSheet2State();
}

class _BottomSheet2State extends State<BottomSheet2> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body:  Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
              child:  ElevatedButton( child: Text("Open Bottom Sheet"),
                onPressed: () {
                  showModalBottomSheet(context: context,
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.vertical(
                              top: Radius.circular(10.w)
                          )
                      ),
                      builder: (context) => Center(
                        child: Column(
                          children: [

                            SizedBox(height: 4.h,),
                            Text("Share your address with\n             us to order",style: TextStyle(fontSize: 14.sp,fontWeight: FontWeight.bold),),
                            SizedBox(height: 4.h,),

                            Padding(
                              padding:  EdgeInsets.only(left: 7.w),
                              child: TextFormField(
                                decoration: InputDecoration(
                                    icon: Image.asset(IcIcons.orlcg,width: 7.w,),
                                    border: InputBorder.none,
                                    hintText: "Enable Device Location",
                                    hintStyle: TextStyle(
                                        fontSize: 12.sp,
                                        fontWeight: FontWeight.w500,
                                        color: Colors.deepOrange),

                                ),
                              ),
                            ),

                            Padding(
                              padding:  EdgeInsets.only(left: 7.w),
                              child: TextFormField(
                                decoration: InputDecoration(
                                  icon: Image.asset(IcIcons.location5,width: 3.w,),
                                  border: InputBorder.none,
                                  hintText: "Enter location Manually",
                                  hintStyle: TextStyle(
                                      fontSize: 12.sp,
                                      fontWeight: FontWeight.w500,
                                      color: Colors.grey),



                                ),
                              ),
                            ),

                          ],
                        ),
                      ));
                },

              )

          ),


        ],

      ),







    );
  }
}
