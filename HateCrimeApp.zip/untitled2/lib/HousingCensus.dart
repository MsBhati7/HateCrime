import 'package:flutter/material.dart';

import 'package:sizer/sizer.dart';

import 'package:untitled2/utils/IcIcons.dart';
import 'package:untitled2/utils/colors.dart';



class HousingCensusForm extends StatefulWidget {
  static const route = "/housingCensusForm";

  HousingCensusForm({Key? key}) : super(key: key);

  @override
  State<HousingCensusForm> createState() => _HousingCensusFormState();
}

class _HousingCensusFormState extends State<HousingCensusForm> {
  String? firstdropDownValue = "Food Category";
  String? seconddropDownValue = "Select";
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        elevation: 0.0,
        title: Row(
          children: [
            Text(
              "Dashboard",
              style: TextStyle(
                fontSize: 14.sp,
                fontWeight: FontWeight.bold,
                color: AppColors.black1,
              ),
            ),
            Padding(
              padding:  EdgeInsets.only(left: 37.7.w),
              child: Image.asset(IcIcons.notify,width: 3.w,),
            ),

            Image.asset(IcIcons.notify1,width: 12.w,)
          ],
        ),
        leading: IconButton(onPressed: () {}, icon: Image.asset(IcIcons.Dash)),
        backgroundColor: AppColors.white1,
      ),
      body: SingleChildScrollView(
          child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Container(),
                SizedBox(
                  height: 3.h,
                ),
                Padding(
                  padding:  EdgeInsets.only(right: 60.w),
                  child: RichText(text: TextSpan(
                      text: "Hello ",style: TextStyle(fontSize: 14.sp,fontWeight: FontWeight.bold,color: AppColors.black1),
                      children: [
                        TextSpan(
                            text: "Amanda!",style: TextStyle(fontSize: 14.sp,fontWeight: FontWeight.bold,color: AppColors.red1))
                      ]
                  )),
                ),
                SizedBox(
                  height: 1.h,
                ),
                Padding(
                  padding:  EdgeInsets.only(right: 35.w),
                  child: Text( "Welcome to COMMUNION ",style: TextStyle(fontSize: 14.sp,color: AppColors.black1)),
                ),
                SizedBox(
                  height: 6.h,
                ),
                Container(
                  width: 90.w,
                  height: 9.h,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(8.0),
                    color: AppColors.litey,
                    border: Border.all(
                      color: AppColors.lite1,
                      width: 0.2.h,
                    ),
                  ),
                  child: Padding(
                    padding: EdgeInsets.all(2.h),
                    child: Row(
                      children: [
                        Text(
                          "REPORT HATE-CRIME",
                          style: TextStyle(
                            color: Colors.black87,
                            fontSize: 11.sp,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        SizedBox(
                          width: 40.w,
                        ),
                        Image.asset(IcIcons.Forword1)
                      ],
                    ),
                  ),
                ),
                SizedBox(
                  height: 3.h,
                ),
                Container(
                  width: 90.w,
                  height: 9.h,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(8.0),
                    color: AppColors.litey,
                    border: Border.all(
                      color: AppColors.lite1,
                      width: 0.2.h,
                    ),
                  ),
                  child: Padding(
                    padding: EdgeInsets.all(2.h),
                    child: Row(
                      children: [
                        Text(
                          "VALIDATE HATE CRIME",
                          style: TextStyle(
                            color: Colors.black87,
                            fontSize: 11.sp,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        SizedBox(
                          width: 40.w,
                        ),
                        Image.asset(IcIcons.Forword1)
                      ],
                    ),
                  ),
                ),
                SizedBox(
                  height: 3.h,
                ),
                Container(
                  width: 90.w,
                  height: 9.h,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(8.0),
                    color: AppColors.litey,
                    border: Border.all(
                      color: AppColors.lite1,
                      width: 0.2.h,
                    ),
                  ),
                  child: Padding(
                    padding: EdgeInsets.all(2.h),
                    child: Row(
                      children: [
                        Text(
                          "ENTER CENSUS DATA",
                          style: TextStyle(
                            color: Colors.black87,
                            fontSize: 11.sp,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        SizedBox(
                          width: 40.w,
                        ),
                        Image.asset(IcIcons.Forword1)
                      ],
                    ),
                  ),
                ),

                SizedBox(
                  height: 6.h,
                ),
                Padding(
                  padding:  EdgeInsets.only(right: 60.w),
                  child: Text( "View Reports ",style: TextStyle(fontSize: 14.sp,color: AppColors.black1)),
                ),
                SizedBox(
                  height: 2.h,
                ),
                DecoratedBox(
                  decoration: ShapeDecoration(
                    color: AppColors.white1,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.all(
                          Radius.circular(2.w)),
                    ),
                  ),
                  child: Container(
                    decoration: BoxDecoration(
                        color: AppColors.grey6,
                        borderRadius:
                        BorderRadius.circular(
                            2.w),
                        border: Border.all(
                            color: AppColors.grey6)),
                    height: 7.h,
                    width: 90.w,
                    child:
                    DropdownButtonHideUnderline(
                      child: Padding(
                        padding: EdgeInsets.symmetric(
                            horizontal: 2.h),
                        child: DropdownButton<String>(
                          elevation: 0,
                          icon: Icon(
                            Icons
                                .keyboard_arrow_down_sharp,
                            color: AppColors.black1,
                          ),
                          value: seconddropDownValue,
                          dropdownColor:
                          AppColors.grey5,
                          items: <String>[
                            'Food Category',
                            'Select'
                          ].map((String value) {
                            return DropdownMenuItem<
                                String>(
                              value: value,
                              child: Text(
                                value,
                                style: TextStyle(
                                    fontSize: 10.sp),
                              ),
                            );
                          }).toList(),
                          onChanged: (value) {
                            setState(() {
                              firstdropDownValue =
                                  value;
                            });
                          },
                        ),
                      ),
                    ),
                  ),
                ),
                SizedBox(
                  height: 5.h,
                ),
                GestureDetector(
                    onTap: () {},
                    child: Container(
                      alignment: Alignment.center,
                      width: 90.w,
                      height: 9.h,
                      decoration: BoxDecoration(

                        border: Border.all(
                          color: AppColors.grey2,
                          width: 0.1.h,
                        ),
                        color: AppColors.grey6,
                        borderRadius: BorderRadius.circular(8.0),


                      ),
                      child: Padding(
                        padding: EdgeInsets.all(2.h),
                        child: Text(
                          "EXIT COMMUNION ",
                          style: TextStyle(
                            color: Colors.black87,
                            fontSize: 11.sp,
                            fontWeight: FontWeight.bold,

                          ),
                        ),
                      ),
                    )),
                SizedBox(
                  height: 8.h,
                ),
                Container(
                  width: 90.w,
                  height: 11.h,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(8.0),
                    color: AppColors.litey,

                  ),
                  child: Padding(
                    padding:  EdgeInsets.all(3.w),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        RichText(text: TextSpan(
                            text: "Need Help? Have Any Questions?",style: TextStyle(fontSize: 9.sp, color: AppColors.black1),

                            children: [
                              TextSpan(text: "\nGet in touch with our customer\nSupport team ",style: TextStyle(fontSize: 9.sp,fontWeight: FontWeight.w400 ,color: AppColors.grey1))
                            ]

                        ),


                        ),
                        Image.asset(IcIcons.arrow4,),
                      ],

                    ),
                  ),
                ),

                SizedBox(
                  height: 8.h,
                ),
              ])),
    );
  }
}
