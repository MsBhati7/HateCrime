import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';

import 'package:otp_text_field/otp_field.dart';
import 'package:otp_text_field/style.dart';

import 'package:sizer/sizer.dart';
import 'package:untitled2/SignUp2.dart';
import 'package:untitled2/EndSession.dart';


import 'package:untitled2/utils/IcIcons.dart';
import 'package:untitled2/utils/colors.dart';

import 'Widgets/appbuttons.dart';

class YourDetails extends StatefulWidget {
  static const route = "/createYourAccount ";

  YourDetails({Key? key}) : super(key: key);

  @override
  State<YourDetails> createState() => _YourDetailsState();
}

class _YourDetailsState extends State<YourDetails> {
  bool _checkbox = false;
  bool isYes = false;
  bool isNo = false;

  String? firstdropDownValue = "Select1";
  String? seconddropDownValue = "Select";

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        elevation: 0.0,
        title: Padding(
          padding:  EdgeInsets.only(left: 5.w),
          child: Text(
            " Sign-up for Type 2 Account",
            style: TextStyle(
              fontSize: 11.sp,
              fontWeight: FontWeight.bold,
              color: AppColors.black1,
            ),
          ),
        ),
        leading: IconButton(
            onPressed: () {},
            icon: Icon(Icons.arrow_back,color: AppColors.black1,size: 5.w,)),
        backgroundColor: AppColors.white1,
      ),
      body: SingleChildScrollView(
          child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
            Container(),
            SizedBox(
              height: 3.h,
            ),
            Text(
              "Your Details",
              style: TextStyle(
                  fontSize: 16.sp,
                  fontWeight: FontWeight.bold,
                  color: AppColors.black1),
            ),
            SizedBox(
              height: 3.h,
            ),
            Padding(
              padding: EdgeInsets.only(left: 5.w),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text("Profession",
                      style: TextStyle(
                          fontSize: 9.sp,
fontWeight: FontWeight.w500,
                          color: AppColors.grey5)),
                  SizedBox(
                    height: 2.h,
                  ),
                  Container(
                    height: 6.5.h,
                    width: 90.w,
                    decoration: BoxDecoration(
                        color: AppColors.grey6,
                        borderRadius: BorderRadius.circular(2.w),
                        border: Border.all(color: AppColors.grey6)),
                    child: Padding(
                      padding:  EdgeInsets.only(left: 4.w,bottom: 1.h),
                      child: TextFormField(
                        decoration: InputDecoration(
                          border: InputBorder.none,
                          hintText: "Enter Profession",
                          hintStyle: TextStyle(
                              fontSize: 10.sp,
                              fontWeight: FontWeight.w500,
                              color: AppColors.grey1),
                        ),
                      ),
                    ),
                  ),
                  SizedBox(
                    height: 2.h,
                  ),
                  Text(
                      "Can you provide rescue and support for victim of\n hate-crime? ",
                      style: TextStyle(
                          fontSize: 9.sp,
                          fontWeight: FontWeight.w400,
                          color: AppColors.grey2)),
                  SizedBox(
                    height: 2.h,
                  ),
                  Padding(
                    padding:  EdgeInsets.only(left: 4.5.w),
                    child: Row(mainAxisAlignment: MainAxisAlignment.start, children: [
                      Container(
                        height: 4.5.h,
                        width: 20.w,
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(1.5.w),
                            border: Border.all(color: Colors.grey)),
                        child: Row(
                          children: [
                            Checkbox(
                              checkColor: AppColors.grey5,
                              value: isYes,
                              onChanged: (value) {
                                setState(() {
                                  isYes = value!;
                               isNo = false;
                                });
                              },
                            ),
                            Text(
                              'Yes',
                              style: TextStyle(fontSize: 8.sp),
                            ),
                          ],
                        ),
                      ),
                      SizedBox(width: 5.w,),
                      Container(
                        height: 4.5.h,
                        width: 20.w,
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(1.5.w),
                            border: Border.all(color: Colors.grey)),
                        child: Row(
                          children: [
                            Checkbox(
                              checkColor: AppColors.grey5,
                              value: isNo,
                              onChanged: (value) {
                                setState(() {
                                   isYes = false;
                                   isNo = value!;
                                });
                              },
                            ),
                            Text(
                              'NO',
                              style: TextStyle(fontSize: 8.sp),
                            ),
                          ],
                        ),
                      ),

                    ]),
                  ),

                  SizedBox(height: 4.h,),
                  Text("  Add Reference",
                      style: TextStyle(
                          fontSize: 11.sp,
                          fontWeight: FontWeight.w500,
                          color: AppColors.black1)),
                  SizedBox(
                    height: 2.h,
                  ),
                  Row(
                    children: [
                      Text("Which church denomination do you belong ot? ",
                          style: TextStyle(
                              fontSize: 9.sp,
                              fontWeight: FontWeight.w400,
                              color: AppColors.grey5)),
                      Padding(
                        padding:  EdgeInsets.only(left: 1.w,bottom: 1.w),
                        child: Icon(Icons.star, color: AppColors.red1,size: 2.w,),
                      )

                    ],
                  ),

                  SizedBox(height: 2.h,),
                  DecoratedBox(
                    decoration: ShapeDecoration(
                      color: AppColors.white1,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.all(Radius.circular(2.w)),
                      ),
                    ),
                    child: Container(
                      decoration: BoxDecoration(
                          color: AppColors.grey6,
                          borderRadius: BorderRadius.circular(2.w),
                          border: Border.all(color: AppColors.grey6)),
                      height: 6.5.h,
                      width: 90.w,
                      child: DropdownButtonHideUnderline(
                        child: Padding(
                          padding: EdgeInsets.symmetric(horizontal: 2.h),
                          child: DropdownButton<String>(
                            elevation: 0,
                            icon: Icon(
                              Icons.keyboard_arrow_down_sharp,
                              color: AppColors.black1,
                            ),
                            value: firstdropDownValue,
                            dropdownColor: AppColors.grey5,
                            items: <String>['Select1', 'Select']
                                .map((String value) {
                              return DropdownMenuItem<String>(
                                value: value,
                                child: Text(
                                  value,
                                  style: TextStyle(fontSize: 10.sp),
                                ),
                              );
                            }).toList(),
                            onChanged: (value) {
                              setState(() {
                                firstdropDownValue = value;
                              });
                            },
                          ),
                        ),
                      ),
                    ),
                  ),

                  SizedBox(
                    height: 2.h,
                  ),
                  Row(
                    children: [
                      Text("Name of your Pastor/Pries",
                          style: TextStyle(
                              fontSize: 9.sp,
                              fontWeight: FontWeight.w400,
                              color: AppColors.grey5)),
                      Padding(
                        padding:  EdgeInsets.only(left: 1.w,bottom: 1.w),
                        child: Icon(Icons.star, color: AppColors.red1,size: 2.w,),
                      )
                    ],
                  ),

                  SizedBox(
                    height: 2.h,
                  ),
                  Container(
                    alignment: Alignment.center,
                    decoration: BoxDecoration(
                        color: AppColors.grey6,
                        borderRadius: BorderRadius.circular(2.w),
                        border: Border.all(color: AppColors.grey6)),
                    height: 6.5.h,
                    width: 90.w,
                    child: Padding(
                      padding:  EdgeInsets.only(left: 4.w,bottom: 1.3.h),
                      child: TextFormField(
                        decoration: InputDecoration(
                          border: InputBorder.none,
                          hintText: "Enter Pastor/Priest Name",
                          hintStyle: TextStyle(
                              fontSize: 9.sp,
                              fontWeight: FontWeight.w500,
                              color: AppColors.grey1),
                        ),
                      ),
                    ),
                  ),
                  SizedBox(
                    height: 2.h,
                  ),
                  Row(
                    children: [
                      Text("Phone Number of your Pastor/Priest",
                          style: TextStyle(
                              fontSize: 9.sp,
                              fontWeight: FontWeight.w400,
                              color: AppColors.grey5)),
                      Padding(
                        padding:  EdgeInsets.only(left: 1.w,bottom: 1.w),
                        child: Icon(Icons.star, color: AppColors.red1,size: 2.w,),
                      )
                    ],
                  ),

                  SizedBox(
                    height: 2.h,
                  ),
                  Container(
                    alignment: Alignment.center,
                    decoration: BoxDecoration(
                        color: AppColors.grey6,
                        borderRadius: BorderRadius.circular(2.w),
                        border: Border.all(color: AppColors.grey6)),
                    height: 6.5.h,
                    width: 90.w,
                    child: Padding(
                      padding:  EdgeInsets.only(left: 4.w,bottom: 1.3.h),
                      child: TextFormField(
                        decoration: InputDecoration(
                          border: InputBorder.none,
                          hintText: "Enter Pastor/Priest Phone Number",
                          hintStyle: TextStyle(
                              fontSize: 9.sp,
                              fontWeight: FontWeight.w500,
                              color: AppColors.grey1),
                        ),
                      ),
                    ),
                  ),

                  SizedBox(
                    height: 2.h,
                  ),
                  Row(
                    children: [
                      Text("Church Name",
                          style: TextStyle(
                              fontSize: 9.sp,
                              fontWeight: FontWeight.w400,
                              color: AppColors.grey5)),
                      Padding(
                        padding:  EdgeInsets.only(left: 1.w,bottom: 1.w),
                        child: Icon(Icons.star, color: AppColors.red1,size: 2.w,),
                      ),
                    ],
                  ),

                  SizedBox(
                    height: 2.h,
                  ),
                  Container(
                    alignment: Alignment.center,
                    decoration: BoxDecoration(
                        color: AppColors.grey6,
                        borderRadius: BorderRadius.circular(2.w),
                        border: Border.all(color: AppColors.grey6)),
                    height: 6.5.h,
                    width: 90.w,
                    child: Padding(
                      padding:  EdgeInsets.only(left: 4.w, bottom: 1.3.h),
                      child: TextFormField(

                        decoration: InputDecoration(

                          border: InputBorder.none,

                          hintText: "Enter Church Name",
                          hintStyle: TextStyle(
                              fontSize: 9.sp,
                           fontWeight: FontWeight.w500,
                              color: AppColors.grey1),
                        ),
                      ),
                    ),
                  ),

                  SizedBox(
                    height: 2.h,
                  ),
                  Row(
                    children: [
                      Text("Church Address",
                          style: TextStyle(
                              fontSize: 9.sp,
                              fontWeight: FontWeight.w400,
                              color: AppColors.grey5)),
                      Padding(
                        padding:  EdgeInsets.only(left: 1.w,bottom: 1.w),
                        child: Icon(Icons.star, color: AppColors.red1,size: 2.w,),
                      ),
                    ],
                  ),

                  SizedBox(
                    height: 2.h,
                  ),
                  Container(
                    alignment: Alignment.center,
                    decoration: BoxDecoration(
                        color: AppColors.grey6,
                        borderRadius: BorderRadius.circular(2.w),
                        border: Border.all(color: AppColors.grey6)),
                    height: 6.5.h,
                    width: 90.w,
                    child: Padding(
                      padding:  EdgeInsets.only(left: 4.w, bottom: 1.3.h),
                      child: TextFormField(
                        decoration: InputDecoration(

                          border: InputBorder.none,
                          hintText: "Enter Church Address",
                          hintStyle: TextStyle(
                              fontSize: 9.sp,
                              fontWeight: FontWeight.w500,
                              color: AppColors.grey1),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            // Text(
            //   '${date.year}/${date.month}/${date.day}',
            //   style: TextStyle(fontSize: 32.0),
            // ),
            // const SizedBox(height: 16,),
            // ElevatedButton( child: Text("SatectDate"),
            //     onPressed: () async {
            //       DateTime? newDate = ShowDataPicker(
            //         context: context,
            //         initialDate: date,
            //         firstDate: DateTime(1900),
            //         lastDate: DateTime(2100),
            //
            //       );
            //     }
            // ),
               SizedBox(height: 2.h,),
                Row(
                  children: [
                    Padding(
                      padding:  EdgeInsets.only(left: 2.w, bottom: 1.5.h),
                      child: Checkbox(
                        checkColor: AppColors.grey5,
                        value: _checkbox,
                        onChanged: (value) {
                          setState(() {
                            _checkbox = !_checkbox;
                          });
                        },
                      ),
                    ),
                    Text(' By checking this box i confirm that above \n information is correct the best of my knowledge.',
                      style:TextStyle(fontSize: 10.sp,fontWeight: FontWeight.w400,color: AppColors.grey2) ,),


                  ],
                ),
            SizedBox(
              height: 1.h,
            ),
            AppButton(
              text: "GENERATE VERIFICATION CODE",
              onTap: () {},
              backgroundColor: AppColors.red1,
              heightsize: 8.h,
              widthsize: 90.w,
            ),
            SizedBox(
              height: 2.h,
            ),
            Text("ENTER VERIFICATION CODE RECEIVED",
                style: TextStyle(
                    fontSize: 9.sp,
                    fontWeight: FontWeight.bold,
                    color: AppColors.black1)),
            SizedBox(
              height: 3.h,
            ),
            Container(
              width: 60.w,

              child: OTPTextField(

                length: 4,

                fieldWidth: 12.w,

                style: TextStyle(fontSize: 14.sp,color: Colors.red),
                textFieldAlignment: MainAxisAlignment.spaceAround,
                fieldStyle: FieldStyle.box,

                onCompleted: (pin) {
                  print("Completed: " + pin);
                },
              ),
            ),

            SizedBox(
              height: 3.h,
            ),
            AppButton(
              text: "NEXT",
              onTap: () {Get.to(() => SignUoType2());},
              backgroundColor: AppColors.red1,
              heightsize: 8.h,
              widthsize: 90.w,
            ),
                SizedBox(
                  height: 5.h,
                ),
            Text("DID NOT RECEIVE VERIFICATION CODE?",
                style: TextStyle(
                    fontSize: 9.sp,
                    fontWeight: FontWeight.w500,
                    color: AppColors.grey5)),
                SizedBox(
                  height: 1.5.h,
                ),
                GestureDetector(
                    onTap: () {Get.to(() => SignUoType2());},
                    child: Container(
                      alignment: Alignment.center,
                      width: 45.w,
                      height: 5.h,

                      decoration: BoxDecoration(
                        color: AppColors.grey7,
                        borderRadius: BorderRadius.circular(1.5.w),

                        border: Border.all(
                          color: AppColors.red1,
                          width: 0.2.w,
                        ),
                      ),
                      child: Text(
                        "RESEND VERIFICATION CODE ",
                        style: TextStyle(
                          color: Colors.black87,
                          fontSize: 8.sp,
                          fontWeight: FontWeight.bold,

                        ),
                      ),
                    )),
                SizedBox(height: 5.h,),
          ])),
    );
  }


}
