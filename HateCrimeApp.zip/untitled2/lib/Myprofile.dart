import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:sizer/sizer.dart';
import 'package:untitled2/utils/IcIcons.dart';
import 'package:untitled2/utils/colors.dart';
import 'package:untitled2/welcome.dart';
import 'Widgets/appbuttons.dart';
import 'YourDetails.dart';

class MyProfile1 extends StatefulWidget {
  static const route = "/myProfile";
  const MyProfile1({Key? key}) : super(key: key);

  @override
  State<MyProfile1> createState() => _MyProfile1State();
}

class _MyProfile1State extends State<MyProfile1> {

  @override



  String? firstdropDownValue = "Food Category";
  String? seconddropDownValue = "Select";

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        elevation: 0.0,
        title: Padding(
          padding:  EdgeInsets.only(left: 5.w),
          child: Text(
            "My Profile",
            style: TextStyle(
              fontSize: 11.sp,
              fontWeight: FontWeight.bold,
              color: AppColors.black1,
            ),
          ),
        ),
        leading: IconButton(
            onPressed: () {},
            icon: Icon(Icons.arrow_back,color: AppColors.black1,size: 5.w,)),
        backgroundColor: AppColors.white1,
      ),
      body: SingleChildScrollView(
          child: Padding(
            padding: EdgeInsets.only(left: 6.w
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SizedBox(height: 3.h,),
                Stack(
                  children: [
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [

                        Padding(
                          padding: EdgeInsets.only(top: 3.w,left: 32.w),
                          child: CircleAvatar(
                            radius: 14.w,
                            backgroundColor: AppColors.litey,
                            child: Image.asset(IcIcons.person1,width: 8.w,),
                          ),
                        ),
                      ],
                    ),
              Positioned(
                         right: 0,
                         top: 0,

                         child: GestureDetector(
                             onTap: () {},
                             child: Image.asset(
                               IcIcons.person4,
                               width: 14.w,
                             )))
                  ],
                ),
                Text("Unique Id" ,style:TextStyle(
                    fontSize: 10.sp,
                    fontWeight: FontWeight.w400,
                    color: AppColors.grey5)),
                SizedBox(height: 2.h,),

                Container(
                  decoration: BoxDecoration(
                      color: AppColors.grey6,
                      borderRadius: BorderRadius.circular(2.w),
                      border: Border.all(color: AppColors.grey6)),
                  height: 6.5.h,
                  width: 90.w,
                  child: Padding(
                    padding: EdgeInsets.all(3.5.w),
                    child: TextFormField(
                      decoration: InputDecoration(
                        border: InputBorder.none,

                        hintText: "Rendy V0759Ad",
                        hintStyle: TextStyle(
                            fontSize: 10.sp,
                            fontWeight: FontWeight.w400,
                            color: AppColors.grey1),
                        suffixIcon: Padding(
                            padding: EdgeInsets.only( left: 10.w),
                            child: Image.asset(IcIcons.Id1,)),
                      ),
                    ),
                  ),
                ),
                SizedBox(height: 2.h,),
                Text("Full name" ,style:TextStyle(
                    fontSize: 10.sp,
                    fontWeight: FontWeight.w400,
                    color: AppColors.grey5)),
                SizedBox(height: 2.h,),

                Container(
                  decoration: BoxDecoration(
                      color: AppColors.grey6,
                      borderRadius: BorderRadius.circular(2.w),
                      border: Border.all(color: AppColors.grey6)),
                  height: 6.5.h,
                  width: 90.w,
                  child: Padding(
                    padding: EdgeInsets.only(left: 3.w,bottom: 0.7.h),
                    child: TextFormField(
                      decoration: InputDecoration(
                        border: InputBorder.none,

                        hintText: "Rendy Vickrianyah",
                        hintStyle: TextStyle(
                            fontSize: 12.sp,
                            fontWeight: FontWeight.w500,
                            color: AppColors.black1),
                        suffixIcon: Padding(
                            padding: EdgeInsets.all( 2.5.w),
                            child: Image.asset(IcIcons.profile,)),
                      ),
                    ),
                  ),
                ),
                SizedBox(height: 2.h,),
                Text("Email Address",style:TextStyle(
                    fontSize: 10.sp,
                    fontWeight: FontWeight.w400,
                    color: AppColors.grey5)),
                SizedBox(height: 2.h,),
                Container(
                  decoration: BoxDecoration(
                      color: AppColors.grey6,
                      borderRadius: BorderRadius.circular(2.w),
                      border: Border.all(color: AppColors.grey6)),
                  height: 6.5.h,
                  width: 90.w,
                  child: Padding(
                    padding: EdgeInsets.all( 3.5.w),
                    child: TextFormField(
                      decoration: InputDecoration(
                        border: InputBorder.none,

                        hintText: "sarah@site-name.com",
                        hintStyle: TextStyle(
                            fontSize: 12.sp,
                            fontWeight: FontWeight.w500,
                            color: AppColors.black1),
                        suffixIcon: Padding(
                            padding: EdgeInsets.only(left: 15.w),
                            child: Image.asset(IcIcons.mail)),
                      ),
                    ),
                  ),
                ),
                SizedBox(height: 2.h,),
                Text("Phone/WhatsApp Number",style:TextStyle(
                    fontSize: 10.sp,
                    fontWeight: FontWeight.w400,
                    color: AppColors.grey5)),
                SizedBox(height: 2.h,),
                Container(
                  alignment: Alignment.center,
                  decoration: BoxDecoration(
                      color: AppColors.grey6,
                      borderRadius: BorderRadius.circular(2.w),
                      border: Border.all(color: AppColors.grey6)),
                  height: 6.5.h,
                  width: 90.w,
                  child: Padding(
                    padding: EdgeInsets.only(left: 3.w,bottom: 0.7.h),
                    child: TextFormField(
                      decoration: InputDecoration(
                        border: InputBorder.none,

                        hintText: "+1 0388455989",
                        hintStyle: TextStyle(
                            fontSize: 12.sp,
                            fontWeight: FontWeight.w500,
                            color: AppColors.black1),
                        suffixIcon: Padding(
                            padding: EdgeInsets.all( 2.5.w),
                            child: Image.asset(IcIcons.phone1)),
                      ),
                    ),
                  ),
                ),
                SizedBox(height: 2.h,),
                Text("Address" ,style:TextStyle(
                    fontSize: 10.sp,
                    fontWeight: FontWeight.w400,
                    color: AppColors.grey5)),
                SizedBox(height: 2.h,),

                Container(
                  decoration: BoxDecoration(
                      color: AppColors.grey6,
                      borderRadius: BorderRadius.circular(2.w),
                      border: Border.all(color: AppColors.grey6)),
                  height: 6.5.h,
                  width: 90.w,
                  child: Padding(
                    padding: EdgeInsets.only(left: 3.w,bottom: 0.7.h),
                    child: TextFormField(
                      decoration: InputDecoration(
                        border: InputBorder.none,

                        hintText: "1434 Isaacs Creek Road, Modesto",
                        hintStyle: TextStyle(
                            fontSize: 10.sp,
                            fontWeight: FontWeight.w400,
                            color: AppColors.black1),
                        suffixIcon: Padding(
                            padding: EdgeInsets.all( 2.5.w),
                            child: Image.asset(IcIcons.location5,width: 5.w,)),
                      ),
                    ),
                  ),
                ),



                SizedBox(height: 2.h,),




                Text("User Account Type" ,style:TextStyle(
                    fontSize: 10.sp,
                    fontWeight: FontWeight.w400,
                    color: AppColors.grey5)),
                SizedBox(height: 2.h,),

                Container(
                  alignment: Alignment.center,
                  decoration: BoxDecoration(
                      color: AppColors.grey6,
                      borderRadius: BorderRadius.circular(2.w),
                      border: Border.all(color: AppColors.grey6)),
                  height: 6.5.h,
                  width: 90.w,
                  child: Padding(
                    padding: EdgeInsets.only(left: 4.w, bottom: 0.7.h),
                    child: TextFormField(
                      decoration: InputDecoration(
                        border: InputBorder.none,
contentPadding: EdgeInsets.only(bottom: 2.h),
                        hintText: "Type 2 Account ",
                        hintStyle: TextStyle(
                            fontSize: 10.sp,
                            fontWeight: FontWeight.w500,
                            color: AppColors.black1),

                      ),
                    ),
                  ),
                ),


                SizedBox(height: 2.h,),
                Text("Member Since" ,style:TextStyle(
                    fontSize: 10.sp,
                    fontWeight: FontWeight.w400,
                    color: AppColors.grey5)),
                SizedBox(height: 2.h,),

                Container(
                  alignment: Alignment.center,
                  decoration: BoxDecoration(
                      color: AppColors.grey6,
                      borderRadius: BorderRadius.circular(2.w),
                      border: Border.all(color: AppColors.grey6)),
                  height: 6.5.h,
                  width: 90.w,
                  child: Padding(
                    padding: EdgeInsets.only(left: 4.w, bottom: 0.7.h),
                    child: TextFormField(
                      decoration: InputDecoration(
                        border: InputBorder.none,
contentPadding: EdgeInsets.only(bottom: 2.h),
                        hintText: "08/05/2015",
                        hintStyle: TextStyle(
                            fontSize: 10.sp,
                            fontWeight: FontWeight.w400,
                            color: AppColors.black1),

                      ),
                    ),
                  ),
                ),

                SizedBox(height: 2.h,),
                Text("Account Last Edited On" ,style:TextStyle(
                    fontSize: 10.sp,
                    fontWeight: FontWeight.w400,
                    color: AppColors.grey5)),
                SizedBox(height: 2.h,),

                Container(
                  alignment: Alignment.center,
                  decoration: BoxDecoration(
                      color: AppColors.grey6,
                      borderRadius: BorderRadius.circular(2.w),
                      border: Border.all(color: AppColors.grey6)),
                  height: 6.5.h,
                  width: 90.w,
                  child: TextFormField(
                    decoration: InputDecoration(
                      border: InputBorder.none,
contentPadding: EdgeInsets.only(left: 3.w, bottom: 2.h),
                      hintText: "20/12/2021",
                      hintStyle: TextStyle(
                          fontSize: 10.sp,
                          fontWeight: FontWeight.w500,
                          color: AppColors.black1),

                    ),
                  ),
                ),


                SizedBox(height: 5.h,),
        AppButton(
            text: "DELETE MY ACCOUNT",

            onTap: () {Get.to(() => WelcomePage());},
            backgroundColor: AppColors.red1,
            heightsize: 8.h,
            widthsize: 90.w,
        ),





        SizedBox(height: 10.h,),

   // Stack(
   //    children: [
   //      CircleAvatar(
   //        backgroundColor: Colors.grey,
   //        radius: 8.h,
   //        child: CircleAvatar(
   //            radius: 7.3.h,
   //            backgroundColor: Colors.white,
   //            backgroundImage: AssetImage(IcIcons.add_profile)),
   //      ),
   //      Positioned(
   //          right: 0,
   //          child: GestureDetector(
   //              onTap: () {},
   //              child: Image.asset(
   //                IcIcons.camera2,
   //                width: 14.w,
   //              )))
   //    ],
    ]),
          ),
      ),);
  }


}
