import 'package:flutter/material.dart';
import 'package:flutter_switch/flutter_switch.dart';
import 'package:get/get.dart';

import 'package:sizer/sizer.dart';
import 'package:untitled2/DASHBOARD1.dart';

import 'package:untitled2/utils/IcIcons.dart';
import 'package:untitled2/utils/colors.dart';



class Settings extends StatefulWidget {
  static const route = "/housingCensusForm";

  Settings({Key? key}) : super(key: key);

  @override
  State<Settings> createState() => _SettingsState();
}

class _SettingsState extends State<Settings> {
  String? firstdropDownValue = "Food Category";
  String? seconddropDownValue = "Select";
  bool selected = false;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        elevation: 0.0,
        title: Row(
          children: [
            Padding(
              padding:  EdgeInsets.only(bottom: 3.h,),
              child: Text(
                "Settings",
                style: TextStyle(
                  fontSize: 12.sp,
                  fontWeight: FontWeight.bold,
                  color: AppColors.black1,
                ),
              ),
            ),



          ],
        ),
        leading: IconButton(onPressed: () { Get.to(() => DashBoard1());}, icon: Icon(Icons.arrow_back,color: AppColors.black1,size: 5.w,)),
        backgroundColor: AppColors.white1,
      ),
      body: SingleChildScrollView(
          child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Container(),
                Padding(
                  padding:  EdgeInsets.only(left: 3.w),
                  child: Container(


                      height: 10.h,
                      width: 90.w,
                      decoration: BoxDecoration(
                          color: AppColors.litey,
                          borderRadius: BorderRadius.circular(5.w)

                      ),
                      child: Row(

                        children: [
                          Padding(
                            padding:  EdgeInsets.only(left: 5.w),
                            child: CircleAvatar(
                                radius: 8.w,
                                backgroundColor: AppColors.lite1,
                                child: Image.asset(IcIcons.image3,width: 14.w,)),
                          ) ,
                          Padding(
                            padding: EdgeInsets.only(left: 3.w),
                            child: RichText(text: TextSpan(
                                text: "Rendy Vickriansyah",style: TextStyle(height: 0.3.h,fontSize: 10.sp,fontWeight: FontWeight.bold,color: AppColors.black1),

                                children: [
                                  TextSpan(
                                    text: "\nUnique ID",style: TextStyle(color: AppColors.lite2),



                                  ),
                                  TextSpan(
                                    text: " - Rendy.V0759AD",style: TextStyle(color: AppColors.red1),



                                  )
                                ])

                            ),
                          ),
                        SizedBox(width: 5.w,),
                          Image.asset(IcIcons.redarrow1,width: 10.w,)
                        ],
                        
                      )
                  ),
                ),
                SizedBox(height: 5.h,),
Padding(
  padding:  EdgeInsets.only(right: 72.w),
  child:   Text("Settings",style: TextStyle(fontSize: 14.sp,fontWeight: FontWeight.bold,color: AppColors.black1),),
),

                SizedBox(height: 1.h,),
        Padding(
          padding:  EdgeInsets.only(right: 80.w),
          child:   Text("Location",style: TextStyle(fontSize: 8.sp,fontWeight: FontWeight.bold,color: AppColors.grey1),),
        ),


                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    Padding(
                      padding:  EdgeInsets.only(right: 55.w),
                      child:   Text("Show Location",style: TextStyle(fontSize: 10.sp,fontWeight: FontWeight.bold,color: AppColors.black1),),
                    ),
                    Padding(
                      padding:  EdgeInsets.only(right: 2.w),
                      child: FlutterSwitch(
                        width: 12.w,
                        height: 3.5.h,
                        activeColor: Colors.green,
                          value: selected,
                          onToggle: (bool value) {
                            setState(() {
                              selected = false;
                            });

                          },

                      ),
                    ),
                  ],
                ),
                Divider(),

                Padding(
                  padding:  EdgeInsets.only(right: 80.w),
                  child:   Text("Notification",style: TextStyle(fontSize: 8.sp,fontWeight: FontWeight.bold,color: AppColors.grey1),),
                ),

                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    Padding(
                      padding:  EdgeInsets.only(right: 65.w),
                      child:   Text("Sound",style: TextStyle(fontSize: 12.sp,fontWeight: FontWeight.bold,color: AppColors.black1),),
                    ),
                    Padding(
                      padding:  EdgeInsets.only(right: 2.w),
                      child: FlutterSwitch(
                        width: 12.w,
                        height: 3.5.h,
                        activeColor: Colors.green,
                        value: selected,
                        onToggle: (bool value) {
                          setState(() {
                            selected = true;
                          });

                        },

                      ),
                    ),
                  ],
                ),
                SizedBox(height: 2.h,),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    Padding(
                      padding:  EdgeInsets.only(right: 62.w),
                      child:   Text("Vibration",style: TextStyle(fontSize: 10.sp,fontWeight: FontWeight.bold,color: AppColors.black1),),
                    ),
                    Padding(
                      padding:  EdgeInsets.only(right: 2.w),
                      child: FlutterSwitch(
                        width: 12.w,
                        height: 3.5.h,
                        activeColor: Colors.green,
                        value: selected,
                        onToggle: (bool value) {
                          setState(() {
                            selected = true;
                          });

                        },

                      ),
                    ),
                  ],
                ),

                Divider(),

                Padding(
                  padding:  EdgeInsets.only(right: 83.w),
                  child:   Text("Privacy",style: TextStyle(fontSize: 8.sp,fontWeight: FontWeight.bold,color: AppColors.grey1),),
                ),
                SizedBox(
                  height: 1.h,
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    Padding(
                      padding:  EdgeInsets.only(right: 50.w),
                      child:   Text("Fingerprint Lock",style: TextStyle(fontSize: 10.sp,fontWeight: FontWeight.bold,color: AppColors.black1),),
                    ),
                    Padding(
                      padding:  EdgeInsets.only(right: 2.w),
                      child: FlutterSwitch(
                        width: 12.w,
                        height: 3.5.h,
                        activeColor: Colors.green,
                        value: selected,
                        onToggle: (bool value) {
                          setState(() {
                            selected = true;
                          });

                        },

                      ),
                    ),
                  ],
                ),
                Divider(),

                Padding(
                  padding:  EdgeInsets.only(right: 85.w),
                  child:   Text("About",style: TextStyle(fontSize: 8.sp,fontWeight: FontWeight.bold,color: AppColors.grey1),),
                ),
                SizedBox(height: 1.h,),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    Padding(
                      padding:  EdgeInsets.only(right: 63.w),
                      child:   Text("COMMUNION",style: TextStyle(fontSize: 10.sp,fontWeight: FontWeight.bold,color: AppColors.black1),),
                    ),
                   Icon(Icons.arrow_forward_ios,size: 4.w,)
                  ],
                ),
                Divider(),
                Padding(
                  padding:  EdgeInsets.only(right: 70.w),
                  child:   Text("Terms of Services",style: TextStyle(fontSize: 8.sp,fontWeight: FontWeight.bold,color: AppColors.grey1),),
                ),
SizedBox(height: 1.h,),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    Padding(
                      padding:  EdgeInsets.only(right: 62.w),
                      child:   Text("Terms of Use",style: TextStyle(fontSize: 11.sp,fontWeight: FontWeight.bold,color: AppColors.black1),),
                    ),
                    Icon(Icons.arrow_forward_ios,size: 4.w,)
                  ],
                ),

                Divider(),

                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    Padding(
                      padding:  EdgeInsets.only(right: 60.w),
                      child:   Text("Privacy Policy",style: TextStyle(fontSize: 11.sp,fontWeight: FontWeight.bold,color: AppColors.black1),),
                    ),
                    Icon(Icons.arrow_forward_ios,size: 4.w,)
                  ],
                ),

                Divider(),

                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    Padding(
                      padding:  EdgeInsets.only(right: 58.w),
                      child:   Text("Trust Securities",style: TextStyle(fontSize: 11.sp,fontWeight: FontWeight.bold,color: AppColors.black1),),
                    ),
                    Icon(Icons.arrow_forward_ios,size: 4.w,)
                  ],
                ),

                Divider(),

                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    Padding(
                      padding:  EdgeInsets.only(right: 55.w),
                      child:   Text("Safety Guidelines",style: TextStyle(fontSize: 11.sp,fontWeight: FontWeight.bold,color: AppColors.black1),),
                    ),
                    Icon(Icons.arrow_forward_ios,size: 4.w,)
                  ],
                ),

                Divider(),

              ])),
    );
  }
}
