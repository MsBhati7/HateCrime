import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:sizer/sizer.dart';
import 'package:untitled2/HousingCharacteristics.dart';
import 'package:untitled2/Widgets/appbuttons.dart';
import 'package:untitled2/utils/IcIcons.dart';

import 'package:untitled2/utils/colors.dart';



class AddHouseholdMember extends StatefulWidget {
  static const route = "/addHouseholdMember";

  AddHouseholdMember({Key? key}) : super(key: key);

  @override
  State<AddHouseholdMember> createState() => _AddHouseholdMemberState();
}

class _AddHouseholdMemberState extends State<AddHouseholdMember> {
  String? firstdropDownValue = "Food Category";
  String? seconddropDownValue = "Select";
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body:  Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
              child:  ElevatedButton( child: Text("Open Bottom Sheet"),
                onPressed: () {
                  showModalBottomSheet(context: context,
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.vertical(
                              top: Radius.circular(12.w)
                          )
                      ),
                      builder: (context) => SingleChildScrollView(
                        child: Center(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [


                              Row(
                                children: [
                                  Padding(
                                    padding:  EdgeInsets.only(left: 5.w),
                                    child: Text("AddPerpetrator(s) info",
                                      style: TextStyle(
                                          fontSize: 12.sp,
                                          fontWeight: FontWeight.w500,
                                          color: AppColors.black1),


                                    ),
                                  ),
                                  Padding(
                                    padding: EdgeInsets.only(top: 1.h, left: 30.w),
                                    child: Image.asset(IcIcons.Close,width: 20.w,),
                                  )
                                ],
                              ),
                              SizedBox(height: 2.h,),
                              Padding(
                                padding:  EdgeInsets.only(right: 70.w),
                                child: Text("Full Name",
                                    style: TextStyle(
                                        fontSize: 11.sp,

                                        color: AppColors.grey1)),
                              ),

                              Padding(
                                padding: EdgeInsets.only(left: 12.w),
                                child: TextFormField(
                                  decoration: InputDecoration(
                                    border: InputBorder.none,
                                    hintText: "Sarah M. Holiday",
                                    hintStyle: TextStyle(
                                        fontSize: 10.sp,
                                        fontWeight: FontWeight.w500,
                                        color: AppColors.black1),
                                  ),
                                ),
                              ),
                              SizedBox(height: 2.h,),
                              Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  Padding(
                                    padding:  EdgeInsets.only(left: 7.w),
                                    child: Text("Relation with Head",
                                        style: TextStyle(
                                            fontSize: 12.sp,

                                            color: AppColors.grey1)),
                                  ),
                                  Padding(
                                    padding:  EdgeInsets.only(right: 40.w),
                                    child: Text("Marital Status",
                                        style: TextStyle(
                                            fontSize: 12.sp,

                                            color: AppColors.grey1)),
                                  ),
                                ],
                              ),
                              SizedBox(height: 2.h,),
                              Row(
                                children: [
                                  TextFormField(
                                    decoration: InputDecoration(
                                      border: InputBorder.none,
                                      hintText: "34 Years",
                                      hintStyle: TextStyle(
                                          fontSize: 14.sp,
                                          fontWeight: FontWeight.w300,
                                          color: AppColors.black1),
                                    ),
                                  ),
                                  Padding(
                                    padding:  EdgeInsets.only(right: 7.w),
                                    child: DecoratedBox(
                                      decoration: ShapeDecoration(
                                        color: AppColors.white1,
                                        shape: RoundedRectangleBorder(
                                          side: BorderSide(
                                              width: .3.w,
                                              style: BorderStyle.solid,
                                              color: AppColors.black1),
                                          borderRadius: BorderRadius.all(Radius.circular(.3.h)),
                                        ),
                                      ),

                                      child: SizedBox(
                                        width: 40.w,
                                        child: DropdownButtonHideUnderline(
                                          child: Padding(
                                            padding: EdgeInsets.symmetric(horizontal: 2.h),
                                            child: DropdownButton<String>(
                                              elevation: 0,
                                              icon: Icon(
                                                Icons.keyboard_arrow_down_sharp,
                                                color: AppColors.black1,
                                              ),
                                              value: seconddropDownValue,
                                              dropdownColor: AppColors.grey5,
                                              items: <String>['Food Category', 'Select']
                                                  .map((String value) {
                                                return DropdownMenuItem<String>(
                                                  value: value,
                                                  child: Text(
                                                    value,
                                                    style: TextStyle(fontSize: 10.sp),
                                                  ),
                                                );
                                              }).toList(),
                                              onChanged: (value) {
                                                setState(() {
                                                  firstdropDownValue = value;
                                                });
                                              },
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                              SizedBox(height: 4.h,),
                              Padding(
                                padding:  EdgeInsets.only(right: 57.w),
                                child: Text("Location of Crime",
                                    style: TextStyle(
                                        fontSize: 11.sp,

                                        color: AppColors.grey1)),
                              ),

                              Padding(
                                padding: EdgeInsets.only(left: 11.w),
                                child: TextFormField(
                                  decoration: InputDecoration(
                                    border: InputBorder.none,
                                    hintText: "1378 Bryan Avenue. Minneapolis",
                                    hintStyle: TextStyle(
                                        fontSize: 10.sp,
                                        fontWeight: FontWeight.w500,
                                        color: AppColors.black1),
                                  ),
                                ),
                              ),
                              SizedBox(height: 4.h,),
                              DecoratedBox(
                                decoration: ShapeDecoration(
                                  color: AppColors.white1,
                                  shape: RoundedRectangleBorder(
                                    side: BorderSide(
                                        width: .3.w,
                                        style: BorderStyle.solid,
                                        color: AppColors.black1),
                                    borderRadius: BorderRadius.all(Radius.circular(.3.h)),
                                  ),
                                ),

                                child: SizedBox(
                                  width: 85.w,
                                  child: DropdownButtonHideUnderline(
                                    child: Padding(
                                      padding: EdgeInsets.symmetric(horizontal: 2.h),
                                      child: DropdownButton<String>(
                                        elevation: 0,
                                        icon: Icon(
                                          Icons.keyboard_arrow_down_sharp,
                                          color: AppColors.black1,
                                        ),
                                        value: seconddropDownValue,
                                        dropdownColor: AppColors.grey5,
                                        items: <String>['Food Category', 'Select']
                                            .map((String value) {
                                          return DropdownMenuItem<String>(
                                            value: value,
                                            child: Text(
                                              value,
                                              style: TextStyle(fontSize: 10.sp),
                                            ),
                                          );
                                        }).toList(),
                                        onChanged: (value) {
                                          setState(() {
                                            firstdropDownValue = value;
                                          });
                                        },
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              SizedBox(height: 2.h,),
                              Padding(
                                padding:  EdgeInsets.only(right: 2.w),
                                child: Text("Reason(s) for victimization -victim(s) perspective",
                                    style: TextStyle(
                                        fontSize: 10.sp,
                                        fontWeight: FontWeight.w500,
                                        color: AppColors.grey1)),
                              ),
                              Container(
                                height: 15.h,
                                width: 80.w,
                                child: TextFormField(
                                  decoration: InputDecoration(
                                    // border: InputBorder.,
                                    hintText: "Enter Details",
                                    hintStyle: TextStyle(
                                        fontSize: 10.sp,
                                        fontWeight: FontWeight.w500,
                                        color: AppColors.black1),
                                  ),
                                ),
                              ),
                              Padding(
                                padding: const EdgeInsets.all(8.0),
                                child: AppButton(
                                  text: "ADD DETAILS",
                                  onTap: () {  Get.to(() => Housing());},
                                  backgroundColor: AppColors.red1,
                                  heightsize: 6.h,
                                  widthsize: 85.w,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ));
                },

              )

          ),


        ],

      ),







    );
  }
}
