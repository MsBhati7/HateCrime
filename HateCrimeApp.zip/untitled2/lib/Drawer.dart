import 'package:flutter/material.dart';
import 'package:get/get.dart';

import 'package:sizer/sizer.dart';
import 'package:untitled2/reportnewhate-crime.dart';

import 'package:untitled2/utils/IcIcons.dart';
import 'package:untitled2/utils/colors.dart';



class MyDrawer extends StatefulWidget {
  static const route = "/mydrawer";

  MyDrawer({Key? key}) : super(key: key);

  @override
  State<MyDrawer> createState() => _MyDrawerState();
}

class _MyDrawerState extends State<MyDrawer> {
  String? firstdropDownValue = "Food Category";
  String? seconddropDownValue = "Select";


  @override
  Widget build(BuildContext context) {
    return Scaffold(
     drawer: Drawer(
        child: Container(
          color: AppColors.black1,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
               SizedBox(height: 3.h,),
            Padding(
              padding:  EdgeInsets.only(left: 3.w,top: 3.h),
              child: Text("Menu",style: TextStyle(fontSize: 12.sp,fontWeight: FontWeight.bold,color: AppColors.white1)),
            ),
              SizedBox(height: 2.h,),
              Padding(
                padding:  EdgeInsets.only(left: 3.w),
                child: Container(


                  height: 15.h,
                  width: 75.w,
            decoration: BoxDecoration(
                  color: AppColors.black2,
                borderRadius: BorderRadius.circular(5.w)

            ),
child: Row(

  children: [
 Padding(
   padding:  EdgeInsets.only(left: 5.w),
   child: CircleAvatar(
     radius: 8.w,
       backgroundColor: AppColors.lite1,
       child: Image.asset(IcIcons.image3,width: 14.w,)),
 ) ,
                    Padding(
                      padding: EdgeInsets.only(left: 3.w),
                      child: RichText(text: TextSpan(
                      text: "Rendy Vickriansyah",style: TextStyle(height: 0.3.h,fontSize: 10.sp,fontWeight: FontWeight.bold,color: AppColors.white1),

                        children: [
                                TextSpan(
                             text: "\nRendy.V@email.con",style: TextStyle(color: AppColors.lite2),



                      )])

                      ),
                    ) ],
)
),
              ),


              SizedBox(height: 4.h,),
              Container(

                height: 7.h,
                width: 75.w,
                child: ListTile(
                  dense:true,
                  leading: Image.asset(IcIcons.Dashb,width: 5.w,),
                  title: Text("DASHBOARD",style: TextStyle(fontSize: 10.sp,color: AppColors.white1),),
trailing: Icon(Icons.arrow_forward_ios,color: AppColors.lite1,size: 4.w,)
                ),
              ),
              Container(

                height: 7.h,
                width: 75.w,
                child: ListTile(
                  dense:true,
                  leading: Image.asset(IcIcons.report2,width: 5.w,),
                  title: GestureDetector(
                      onTap: (){
                        Get.to(() => ReportNewHateCrime());
                      },
                      child: Text("REPORT HISTORY",style: TextStyle(fontSize: 10.sp,color: AppColors.lite2),)),
                    trailing: Icon(Icons.arrow_forward_ios,color: AppColors.lite1,size: 4.w,)
                ),
              ),
              Container(

                height: 7.h,
                width: 75.w,
                child: ListTile(
                  dense:true,
                  leading: Image.asset(IcIcons.per,width: 5.w,),
                  title: Text("MY PROFILE",style: TextStyle(fontSize: 10.sp,color: AppColors.lite2),),
                    trailing: Icon(Icons.arrow_forward_ios,color: AppColors.lite1,size: 4.w,)
                ),
              ),
              Container(

                height: 7.h,
                width: 75.w,
                decoration: BoxDecoration(

                    borderRadius: BorderRadius.circular(5.w)

                ),
                child: ListTile(
                  dense:true,
                  leading: Image.asset(IcIcons.Settings1,width: 5.w,),
                  title: Text("SETTINGS",style: TextStyle(fontSize: 10.sp,color: AppColors.lite2),),
                  trailing: Icon(Icons.arrow_forward_ios,color: AppColors.lite1,size: 4.w,),
                  focusColor:   AppColors.black2,
                ),
              ),
              Container(

                height: 10.h,
                width: 75.w,
                child: ListTile(

                  contentPadding: EdgeInsets.only(left: 5.w, right: 5.w),
                  leading: Image.asset(IcIcons.phone2,width: 5.w,),
                  title: Text("CONTRACT US",style: TextStyle(fontSize: 10.sp,color: AppColors.lite2),),
                   trailing: Icon(Icons.arrow_forward_ios,color: AppColors.lite1,size: 4.w,)
                   // Image.asset(IcIcons.arrowfor,width: 2.w,),
                ),
              ),
              Padding(
                padding:  EdgeInsets.only(left: 36.w,top: 25.h),
                child: Image.asset(IcIcons.image5,width: 10.w,),
              )

            ],
          ),
        )


      ),
    );
  }
}
