import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';


import 'package:sizer/sizer.dart';
import 'package:untitled2/DASHBOARD1.dart';

import 'package:untitled2/utils/IcIcons.dart';
import 'package:untitled2/utils/colors.dart';

import 'Widgets/appbuttons.dart';
import 'YourDetails.dart';

class SignUp2 extends StatefulWidget {

  static const route = "/signUp1";

  SignUp2({Key? key}) : super(key: key);


  @override
  State<SignUp2> createState() => _SignUp2State();
}

class _SignUp2State extends State<SignUp2> {
  bool isYes = false;
  bool isNo = false;
  String? firstdropDownValue = "Food Category";
  String? seconddropDownValue = "Select";
  String? firstdropDownValue1 = "Female";
  String? seconddropDownValue2 = "Male";
  String? firstdropDownValue3 = "Select Education Level1";
  String? seconddropDownValue4 = "Select Education Level";
  String? firstdropDownValue5 = "Select Occupation1";
  String? seconddropDownValue6 = "Select Occupation";
  String? seconddropDownValue7 = "Select";
  String? seconddropDownValue8 = "Select";
  String? firstdropDownValue9 = "Select Completed";
  String? seconddropDownValue10 = "Select Completed1";
  String? firstdropDownValue8 = "Select";


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(

        elevation: 0.0,
        title: Padding(
          padding:  EdgeInsets.only(left: 5.w),
          child: Text(
            " Sign-up for Type 2 Account",
            style: TextStyle(
              fontSize: 13.sp,
              fontWeight: FontWeight.bold,
              color: AppColors.black1,
            ),
          ),
        ),
        leading: IconButton(
            onPressed: () {},
            icon: Icon(Icons.arrow_back,color: AppColors.black1,size: 5.w,)),
        backgroundColor: AppColors.white1,
      ),


      body: SingleChildScrollView(
          child: Column(children: [
            Container(

            ),
            SizedBox(
              height: 3.h,
            ),
            Text(
              "Your Details",
              style: TextStyle(fontSize: 20.sp,fontWeight: FontWeight.bold ,color: AppColors.black1),
            ),
            SizedBox(
              height: 3.h,
            ),
            Padding(
              padding:  EdgeInsets.only(left: 5.w),
              child:   Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text("Full name" ,style:TextStyle(
                      fontSize: 10.sp,
                      fontWeight: FontWeight.w400,
                      color: AppColors.grey5)),
                  SizedBox(height: 2.h,),

                  Container(
                    decoration: BoxDecoration(
                        color: AppColors.grey6,
                        borderRadius: BorderRadius.circular(2.w),
                        border: Border.all(color: AppColors.grey6)),
                    height: 6.5.h,
                    width: 90.w,
                    child: Padding(
                      padding: EdgeInsets.only(left: 3.w,bottom: 0.7.h),
                      child: TextFormField(
                        decoration: InputDecoration(
                          border: InputBorder.none,

                          hintText: "Rendy Vickrianyah",
                          hintStyle: TextStyle(
                              fontSize: 12.sp,
                              fontWeight: FontWeight.w500,
                              color: AppColors.black1),
                          suffixIcon: Padding(
                              padding: EdgeInsets.only(right: 3.w),
                              child: Image.asset(IcIcons.profile)),
                        ),
                      ),
                    ),
                  ),
                  SizedBox(height: 2.h,),
                  Text("Email Address",style:TextStyle(
                      fontSize: 10.sp,
                      fontWeight: FontWeight.w400,
                      color: AppColors.grey5)),
                  SizedBox(height: 2.h,),
                  Container(
                    decoration: BoxDecoration(
                        color: AppColors.grey6,
                        borderRadius: BorderRadius.circular(2.w),
                        border: Border.all(color: AppColors.grey6)),
                    height: 6.5.h,
                    width: 90.w,
                    child: Padding(
                      padding: EdgeInsets.only(left: 3.w,bottom: 0.7.h),
                      child: TextFormField(
                        decoration: InputDecoration(
                          border: InputBorder.none,

                          hintText: "sarah@site-name.com",
                          hintStyle: TextStyle(
                              fontSize: 12.sp,
                              fontWeight: FontWeight.w500,
                              color: AppColors.black1),
                          suffixIcon: Padding(
                              padding: EdgeInsets.only(right: 3.w),
                              child: Image.asset(IcIcons.mail)),
                        ),
                      ),
                    ),
                  ),
                  SizedBox(height: 2.h,),
                  Text("Phone/WhatsApp Number",style:TextStyle(
                      fontSize: 10.sp,
                      fontWeight: FontWeight.w400,
                      color: AppColors.grey5)),
                  SizedBox(height: 2.h,),
                  Container(
                    alignment: Alignment.center,
                    decoration: BoxDecoration(
                        color: AppColors.grey6,
                        borderRadius: BorderRadius.circular(2.w),
                        border: Border.all(color: AppColors.grey6)),
                    height: 6.5.h,
                    width: 90.w,
                    child: Padding(
                      padding: EdgeInsets.only(left: 3.w,bottom: 0.7.h),
                      child: TextFormField(
                        decoration: InputDecoration(
                          border: InputBorder.none,

                          hintText: "+1 0388455989",
                          hintStyle: TextStyle(
                              fontSize: 12.sp,
                              fontWeight: FontWeight.w500,
                              color: AppColors.black1),
                          suffixIcon: Padding(
                              padding: EdgeInsets.only(right: 3.w),
                              child: Image.asset(IcIcons.phone1)),
                        ),
                      ),
                    ),
                  ),
                  SizedBox(height: 2.h,),
                  Text("Area of Your Residence",style:TextStyle(
                      fontSize: 10.sp,
                      fontWeight: FontWeight.w400,
                      color: AppColors.grey5)),



                  SizedBox(height: 2.h,),
                  DecoratedBox(
                    decoration: ShapeDecoration(
                      color: AppColors.white1,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.all(Radius.circular(2.w)),
                      ),
                    ),
                    child: Container(
                      decoration: BoxDecoration(
                          color: AppColors.grey6,
                          borderRadius: BorderRadius.circular(2.w),
                          border: Border.all(color: AppColors.grey6)),
                      height: 6.5.h,
                      width: 90.w,
                      child: DropdownButtonHideUnderline(
                        child: Padding(
                          padding: EdgeInsets.symmetric(horizontal: 2.h),
                          child: DropdownButton<String>(
                            elevation: 0,
                            icon: Icon(
                              Icons.keyboard_arrow_down_sharp,
                              color: AppColors.black1,
                            ),
                            value: seconddropDownValue,
                            dropdownColor: AppColors.grey5,
                            items: <String>['Food Category', 'Select']
                                .map((String value) {
                              return DropdownMenuItem<String>(
                                value: value,
                                child: Text(
                                  value,
                                  style: TextStyle(fontSize: 10.sp),
                                ),
                              );
                            }).toList(),
                            onChanged: (value) {
                              setState(() {
                                seconddropDownValue = value;
                              });
                            },
                          ),
                        ),
                      ),
                    ),
                  ),
                  SizedBox(height: 2.h,),
                  SizedBox(height: 2.h,),
                  DecoratedBox(
                    decoration: ShapeDecoration(
                      color: AppColors.white1,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.all(Radius.circular(2.w)),
                      ),
                    ),
                    child: Container(
                      decoration: BoxDecoration(
                          color: AppColors.grey6,
                          borderRadius: BorderRadius.circular(2.w),
                          border: Border.all(color: AppColors.grey6)),
                      height: 6.5.h,
                      width: 90.w,
                      child: DropdownButtonHideUnderline(
                        child: Padding(
                          padding: EdgeInsets.symmetric(horizontal: 2.h),
                          child: DropdownButton<String>(
                            elevation: 0,
                            icon: Icon(
                              Icons.keyboard_arrow_down_sharp,
                              color: AppColors.black1,
                            ),
                            value: firstdropDownValue,
                            dropdownColor: AppColors.grey5,
                            items: <String>['Food Category', 'Select']
                                .map((String value) {
                              return DropdownMenuItem<String>(
                                value: value,
                                child: Text(
                                  value,
                                  style: TextStyle(fontSize: 10.sp),
                                ),
                              );
                            }).toList(),
                            onChanged: (value) {
                              setState(() {
                                firstdropDownValue = value;
                              });
                            },
                          ),
                        ),
                      ),
                    ),
                  ),

                  SizedBox(height: 2.h,),



                  Text("Cnic Number" ,style:TextStyle(
                      fontSize: 10.sp,
                      fontWeight: FontWeight.w400,
                      color: AppColors.grey5)),
                  SizedBox(height: 2.h,),

                  Container(
                    alignment: Alignment.center,
                    decoration: BoxDecoration(
                        color: AppColors.grey6,
                        borderRadius: BorderRadius.circular(2.w),
                        border: Border.all(color: AppColors.grey6)),
                    height: 6.5.h,
                    width: 90.w,
                    child: Padding(
                      padding: EdgeInsets.only(left: 4.w, bottom: 0.7.h),
                      child: TextFormField(
                        decoration: InputDecoration(
                          border: InputBorder.none,

                          hintText: "Enter Cnic Number",
                          hintStyle: TextStyle(
                              fontSize: 12.sp,
                              fontWeight: FontWeight.w500,
                              color: AppColors.grey1),

                        ),
                      ),
                    ),
                  ),
                  SizedBox(height: 2.h,),
                  Padding(
                    padding: EdgeInsets.only(left: 4.w, right: 20.w),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text("House", style: TextStyle(
                          fontSize: 10.sp,
                          fontWeight: FontWeight.w400,
                          color: AppColors.grey2),),

                        Text("Street/Locality", style: TextStyle(
                          fontSize: 12.sp,
                          fontWeight: FontWeight.w400,
                          color: AppColors.grey2),)],
                    ),
                  ),
                  SizedBox(height: 2.h,),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      Container(
                        height: 6.5.h,
                        width: 45.w,
                        decoration: BoxDecoration(
                            color: AppColors.grey6,
                            borderRadius: BorderRadius.circular(2.w),
                            border: Border.all(color: AppColors.grey6)),
                        child: Padding(
                          padding: EdgeInsets.all(
                            1.5.h,
                          ),
                          child: TextFormField(
                            decoration: InputDecoration(
                              border: InputBorder.none,
                              hintText: "Enter House Rooms",
                              hintStyle: TextStyle(
                                  fontSize: 10.sp,
                                  fontWeight: FontWeight.w500,
                                  color: AppColors.grey1),
                            ),
                          ),
                        ),
                      ),
                      Container(
                        height: 6.5.h,
                        width: 45.w,
                        decoration: BoxDecoration(
                            color: AppColors.grey6,
                            borderRadius: BorderRadius.circular(2.w),
                            border: Border.all(color: AppColors.grey6)),
                        child: Padding(
                          padding: EdgeInsets.all(
                            1.5.h,
                          ),
                          child: TextFormField(
                            decoration: InputDecoration(
                              border: InputBorder.none,
                              hintText: "Enter House Rooms",
                              hintStyle: TextStyle(
                                  fontSize: 10.sp,
                                  fontWeight: FontWeight.w500,
                                  color: AppColors.grey1),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                  SizedBox(height: 2.h,),
                  Text("Village/Town/City" ,style:TextStyle(
                      fontSize: 10.sp,
                      fontWeight: FontWeight.w400,
                      color: AppColors.grey5)),
                  SizedBox(height: 2.h,),

                  Container(
                    alignment: Alignment.center,
                    decoration: BoxDecoration(
                        color: AppColors.grey6,
                        borderRadius: BorderRadius.circular(2.w),
                        border: Border.all(color: AppColors.grey6)),
                    height: 6.5.h,
                    width: 90.w,
                    child: Padding(
                      padding: EdgeInsets.only(left: 4.w, bottom: 0.7.h),
                      child: TextFormField(
                        decoration: InputDecoration(
                          border: InputBorder.none,

                          hintText: "Enter village/Town/City",
                          hintStyle: TextStyle(
                              fontSize: 12.sp,
                              fontWeight: FontWeight.w500,
                              color: AppColors.grey1),

                        ),
                      ),
                    ),
                  ),
                  SizedBox(height: 2.h,),
                  Text("Education Completed" ,style:TextStyle(
                      fontSize: 10.sp,
                      fontWeight: FontWeight.w400,
                      color: AppColors.grey5)),
                  SizedBox(height: 2.h,),
                  DecoratedBox(
                    decoration: ShapeDecoration(
                      color: AppColors.white1,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.all(Radius.circular(2.w)),
                      ),
                    ),
                    child: Container(
                      decoration: BoxDecoration(
                          color: AppColors.grey6,
                          borderRadius: BorderRadius.circular(2.w),
                          border: Border.all(color: AppColors.grey6)),
                      height: 6.5.h,
                      width: 90.w,
                      child: DropdownButtonHideUnderline(
                        child: Padding(
                          padding: EdgeInsets.symmetric(horizontal: 2.h),
                          child: DropdownButton<String>(
                            elevation: 0,
                            icon: Icon(
                              Icons.keyboard_arrow_down_sharp,
                              color: AppColors.black1,
                            ),
                            value: seconddropDownValue8,
                            dropdownColor: AppColors.grey5,
                            items: <String>['Select' ,'Select Completed', 'Select Completed1']
                                .map((String value) {
                              return DropdownMenuItem<String>(
                                value: value,
                                child: Text(
                                  value,
                                  style: TextStyle(fontSize: 10.sp),
                                ),
                              );
                            }).toList(),
                            onChanged: (value) {
                              setState(() {
                                seconddropDownValue8 = value;
                              });
                            },
                          ),
                        ),
                      ),
                    ),
                  ),
                  SizedBox(height: 3.h,),
                  Text("Presently a Student" ,style:TextStyle(
                      fontSize: 10.sp,
                      fontWeight: FontWeight.w400,
                      color: AppColors.grey5)),
                  SizedBox(height: 2.h,),
                  Padding(
                    padding:  EdgeInsets.only(left: 4.5.w),
                    child: Row(mainAxisAlignment: MainAxisAlignment.start, children: [
                      Container(
                        height: 4.5.h,
                        width: 20.w,
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(1.5.w),
                            border: Border.all(color: Colors.grey)),
                        child: Row(
                          children: [
                            Checkbox(
                              checkColor: AppColors.grey5,
                              value: isYes,
                              onChanged: (value) {
                                setState(() {
                                  isYes = value!;
                                   isNo = false;
                                });
                              },
                            ),
                            Text(
                              'Yes',
                              style: TextStyle(fontSize: 8.sp),
                            ),
                          ],
                        ),
                      ),
                      SizedBox(width: 5.w,),
                      Container(
                        height: 4.5.h,
                        width: 20.w,
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(1.5.w),
                            border: Border.all(color: Colors.grey)),
                        child: Row(
                          children: [
                            Checkbox(
                              checkColor: AppColors.grey5,
                              value: isNo,
                              onChanged: (value) {
                                setState(() {
                                  isYes = false;
                                   isNo = value!;
                                });
                              },
                            ),
                            Text(
                              'NO',
                              style: TextStyle(fontSize: 8.sp),
                            ),
                          ],
                        ),
                      ),

                    ]),
                  ),


                  SizedBox(height: 3.h,),
                  Text("Student of" ,style:TextStyle(
                      fontSize: 10.sp,
                      fontWeight: FontWeight.w300,
                      color: AppColors.grey5)),
                  SizedBox(height: 2.h,),
                  DecoratedBox(
                    decoration: ShapeDecoration(
                      color: AppColors.white1,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.all(Radius.circular(2.w)),
                      ),
                    ),
                    child: Container(
                      decoration: BoxDecoration(
                          color: AppColors.grey6,
                          borderRadius: BorderRadius.circular(2.w),
                          border: Border.all(color: AppColors.grey6)),
                      height: 6.5.h,
                      width: 90.w,
                      child: DropdownButtonHideUnderline(
                        child: Padding(
                          padding: EdgeInsets.symmetric(horizontal: 2.h),
                          child: DropdownButton<String>(
                            elevation: 0,
                            icon: Icon(
                              Icons.keyboard_arrow_down_sharp,
                              color: AppColors.black1,
                            ),
                            value: firstdropDownValue8,
                            dropdownColor: AppColors.grey5,
                            items: <String>['Select','Select Education Level', 'Select Education Level1']
                                .map((String value) {
                              return DropdownMenuItem<String>(
                                value: value,
                                child: Text(
                                  value,
                                  style: TextStyle(fontSize: 10.sp),
                                ),
                              );
                            }).toList(),
                            onChanged: (value) {
                              setState(() {
                               firstdropDownValue8 = value;
                              });
                            },
                          ),
                        ),
                      ),
                    ),
                  ),

                  SizedBox(height: 2.h,),
                  Text("Occupation" ,style:TextStyle(
                      fontSize: 10.sp,
                      fontWeight: FontWeight.w300,
                      color: AppColors.grey5)),
                  SizedBox(height: 2.h,),
                  DecoratedBox(
                    decoration: ShapeDecoration(
                      color: AppColors.white1,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.all(Radius.circular(2.w)),
                      ),
                    ),
                    child: Container(
                      decoration: BoxDecoration(
                          color: AppColors.grey6,
                          borderRadius: BorderRadius.circular(2.w),
                          border: Border.all(color: AppColors.grey6)),
                      height: 6.5.h,
                      width: 90.w,
                      child: DropdownButtonHideUnderline(
                        child: Padding(
                          padding: EdgeInsets.symmetric(horizontal: 2.h),
                          child: DropdownButton<String>(
                            elevation: 0,
                            icon: Icon(
                              Icons.keyboard_arrow_down_sharp,
                              color: AppColors.black1,
                            ),
                            value: seconddropDownValue7,
                            dropdownColor: AppColors.grey5,
                            items: <String>['Select','Select Occupation', 'Select Occupation1']
                                .map((String value) {
                              return DropdownMenuItem<String>(
                                value: value,
                                child: Text(
                                  value,
                                  style: TextStyle(fontSize: 10.sp),
                                ),
                              );
                            }).toList(),
                            onChanged: (value) {
                              setState(() {
                                seconddropDownValue7 = value;
                              });
                            },
                          ),
                        ),
                      ),
                    ),
                  ),


                ],),
            ),



            SizedBox(height: 5.h,),
            AppButton(
              text: "NEXT",

              onTap: () {Get.to(() => YourDetails());},
              backgroundColor: AppColors.red1,
              heightsize: 8.h,
              widthsize: 90.w,
            ),





            SizedBox(height: 10.h,),
          ])),





    );
  }


}
