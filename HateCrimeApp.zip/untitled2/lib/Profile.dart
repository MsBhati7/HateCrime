import 'package:flutter/material.dart';
import 'package:get/get.dart';


import 'package:sizer/sizer.dart';
import 'package:untitled2/Signup3.dart';

import 'package:untitled2/utils/IcIcons.dart';
import 'package:untitled2/utils/colors.dart';

import 'Widgets/appbuttons.dart';
import 'YourDetails.dart';

class MyProfile2 extends StatefulWidget {

  static const route = "/myProfile2";

  MyProfile2({Key? key}) : super(key: key);


  @override
  State<MyProfile2> createState() => _MyProfile2State();
}

class _MyProfile2State extends State<MyProfile2> {
  DateTime _dateTime = DateTime.now();
  bool _checkbox = false;
  String? firstdropDownValue = "Food Category";
  String? seconddropDownValue = "Select";
  String? firstdropDownValue1 = "Female";
  String? seconddropDownValue2 = "Male";
  String? seconddropDownValue3 = "Select";

void _showDatePicker(){
  showDatePicker(context: context,
      initialDate: DateTime.now(),
      firstDate: DateTime(2000),
      lastDate: DateTime(2025),
  ).then((value){
    setState((){
_dateTime = value!;
    });
  });
}


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(

        elevation: 0.0,
        title: Padding(
          padding:  EdgeInsets.only(left: 5.w),
          child: Text(
            " Sign-up for Type 1  ",
            style: TextStyle(
              fontSize: 16.sp,
              fontWeight: FontWeight.bold,
              color: AppColors.black1,
            ),
          ),
        ),
        leading: IconButton(
            onPressed: () {},
            icon: Icon(Icons.arrow_back,color: AppColors.black1,size: 5.w,)),
        backgroundColor: AppColors.white1,
      ),


      body: SingleChildScrollView(
          child: Column(children: [
            Container(

            ),
            SizedBox(
              height: 3.h,
            ),
            Text(
              "Create Your Account",
              style: TextStyle(fontSize: 20.sp,fontWeight: FontWeight.bold ,color: AppColors.black1),
            ),
            SizedBox(
              height: 3.h,
            ),
Padding(
  padding:  EdgeInsets.only(left: 5.w),
  child:   Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
              Text("Full name" ,style:TextStyle(
      fontSize: 10.sp,
      fontWeight: FontWeight.w400,
      color: AppColors.grey5)),
      SizedBox(height: 2.h,),

      Container(
        decoration: BoxDecoration(
            color: AppColors.grey6,
            borderRadius: BorderRadius.circular(2.w),
            border: Border.all(color: AppColors.grey6)),
        height: 6.5.h,
        width: 90.w,
        child: Padding(
          padding: EdgeInsets.only(left: 3.w,bottom: 0.7.h),
          child: TextFormField(
            decoration: InputDecoration(
              border: InputBorder.none,

              hintText: "Rendy Vickrianyah",
              hintStyle: TextStyle(
                  fontSize: 12.sp,
                  fontWeight: FontWeight.w500,
                  color: AppColors.black1),
              suffixIcon: Padding(
                  padding: EdgeInsets.only(right: 3.w),
                  child: Image.asset(IcIcons.profile)),
            ),
          ),
        ),
      ),
      SizedBox(height: 2.h,),
              Text("Email Address",style:TextStyle(
                  fontSize: 10.sp,
                  fontWeight: FontWeight.w400,
                  color: AppColors.grey5)),
      SizedBox(height: 2.h,),
      Container(
        decoration: BoxDecoration(
            color: AppColors.grey6,
            borderRadius: BorderRadius.circular(2.w),
            border: Border.all(color: AppColors.grey6)),
        height: 6.5.h,
        width: 90.w,
        child: Padding(
          padding: EdgeInsets.only(left: 3.w,bottom: 0.7.h),
          child: TextFormField(
            decoration: InputDecoration(
              border: InputBorder.none,

              hintText: "sarah@site-name.com",
              hintStyle: TextStyle(
                  fontSize: 12.sp,
                  fontWeight: FontWeight.w500,
                  color: AppColors.black1),
              suffixIcon: Padding(
                  padding: EdgeInsets.only(right: 3.w),
                  child: Image.asset(IcIcons.mail)),
            ),
          ),
        ),
      ),
      SizedBox(height: 2.h,),
              Text("Phone/WhatsApp Number",style:TextStyle(
                  fontSize: 10.sp,
                  fontWeight: FontWeight.w400,
                  color: AppColors.grey5)),
      SizedBox(height: 2.h,),
      Container(
        alignment: Alignment.center,
        decoration: BoxDecoration(
            color: AppColors.grey6,
            borderRadius: BorderRadius.circular(2.w),
            border: Border.all(color: AppColors.grey6)),
        height: 6.5.h,
        width: 90.w,
        child: Padding(
          padding: EdgeInsets.only(left: 3.w,bottom: 0.7.h),
          child: TextFormField(
            decoration: InputDecoration(
              border: InputBorder.none,

              hintText: "+1 0388455989",
              hintStyle: TextStyle(
                  fontSize: 12.sp,
                  fontWeight: FontWeight.w500,
                  color: AppColors.black1),
              suffixIcon: Padding(
                  padding: EdgeInsets.only(right: 3.w),
                  child: Image.asset(IcIcons.phone1)),
            ),
          ),
        ),
      ),
      SizedBox(height: 2.h,),
      Text("Area of Your Residence",style:TextStyle(
          fontSize: 10.sp,
          fontWeight: FontWeight.w400,
          color: AppColors.grey5)),



      SizedBox(height: 2.h,),
      DecoratedBox(
        decoration: ShapeDecoration(
          color: AppColors.white1,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.all(Radius.circular(2.w)),
          ),
        ),
        child: Container(
          decoration: BoxDecoration(
              color: AppColors.grey6,
              borderRadius: BorderRadius.circular(2.w),
              border: Border.all(color: AppColors.grey6)),
          height: 6.5.h,
          width: 90.w,
          child: DropdownButtonHideUnderline(
            child: Padding(
              padding: EdgeInsets.symmetric(horizontal: 2.h),
              child: DropdownButton<String>(
                elevation: 0,
                icon: Icon(
                  Icons.keyboard_arrow_down_sharp,
                  color: AppColors.black1,
                ),
                value: seconddropDownValue,
                dropdownColor: AppColors.grey5,
                items: <String>['Food Category', 'Select']
                    .map((String value) {
                  return DropdownMenuItem<String>(
                    value: value,
                    child: Text(
                      value,
                      style: TextStyle(fontSize: 10.sp),
                    ),
                  );
                }).toList(),
                onChanged: (value) {
                  setState(() {
                    seconddropDownValue = value;
                  });
                },
              ),
            ),
          ),
        ),
      ),
      SizedBox(height: 2.h,),
      DecoratedBox(
        decoration: ShapeDecoration(
          color: AppColors.white1,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.all(Radius.circular(2.w)),
          ),
        ),
        child: Container(
          decoration: BoxDecoration(
              color: AppColors.grey6,
              borderRadius: BorderRadius.circular(2.w),
              border: Border.all(color: AppColors.grey6)),
          height: 6.5.h,
          width: 90.w,
          child: DropdownButtonHideUnderline(
            child: Padding(
              padding: EdgeInsets.symmetric(horizontal: 2.h),
              child: DropdownButton<String>(
                elevation: 0,
                icon: Icon(
                  Icons.keyboard_arrow_down_sharp,
                  color: AppColors.black1,
                ),
                value: firstdropDownValue,
                dropdownColor: AppColors.grey5,
                items: <String>['Food Category', 'Select']
                    .map((String value) {
                  return DropdownMenuItem<String>(
                    value: value,
                    child: Text(
                      value,
                      style: TextStyle(fontSize: 10.sp),
                    ),
                  );
                }).toList(),
                onChanged: (value) {
                  setState(() {
                    firstdropDownValue = value;
                  });
                },
              ),
            ),
          ),
        ),
      ),
Row(
  children: [

  ],
),
      SizedBox(height: 2.h,),
     Row(

       children: [
       Padding(
         padding:  EdgeInsets.only(right: 30.w),
         child: Text("Date of birth "),
       ),
       Padding(
         padding:  EdgeInsets.only(right: 20.w),
         child: Text("Gender"),
       ),
     ],),
      SizedBox(height: 2.h,),
      Row(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: [
          Text(_dateTime.toString(),style: TextStyle(fontSize: 6.sp),),

          MaterialButton(
            elevation: 0.0,

            onPressed: _showDatePicker,
            child: Image.asset(IcIcons.date1,width: 5.w,),

            color: Colors.white,
          ),
          DecoratedBox(
            decoration: ShapeDecoration(
              color: AppColors.white1,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.all(Radius.circular(2.w)),
              ),
            ),
            child: Container(
              decoration: BoxDecoration(
                  color: AppColors.grey6,
                  borderRadius: BorderRadius.circular(2.w),
                  border: Border.all(color: AppColors.grey6)),
              height: 6.5.h,
              width: 45.w,
              child: DropdownButtonHideUnderline(
                child: Padding(
                  padding: EdgeInsets.symmetric(horizontal: 2.h),
                  child: DropdownButton<String>(
                    elevation: 0,
                    icon: Icon(
                      Icons.keyboard_arrow_down_sharp,
                      color: AppColors.black1,
                    ),
                    value: seconddropDownValue3,
                    dropdownColor: AppColors.grey5,
                    items: <String>['Select','Male', 'Female']
                        .map((String value) {
                      return DropdownMenuItem<String>(
                        value: value,
                        child: Text(
                          value,
                          style: TextStyle(fontSize: 10.sp),
                        ),
                      );
                    }).toList(),
                    onChanged: (value) {
                      setState(() {
                        seconddropDownValue3 = value;
                      });
                    },
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
  ],),
),
            SizedBox(height: 2.h,),
            Row(
              children: [
                Padding(
                  padding:  EdgeInsets.only(left: 2.w, bottom: 1.5.h),
                  child: Checkbox(
                    checkColor: AppColors.grey5,
                    value: _checkbox,
                    onChanged: (value) {
                      setState(() {
                        _checkbox = !_checkbox;
                      });
                    },
                  ),
                ),
                Text(' By checking this box i confirm that above \n information is correct the best of my knowledge.',
                  style:TextStyle(fontSize: 10.sp,fontWeight: FontWeight.w400,color: AppColors.grey5) ,),


              ],
            ),
            SizedBox(height: 2.5.h,),
            AppButton(
              text: "GENERATE OTP",

              onTap: () {Get.to(() => SignUp3());},
              backgroundColor: AppColors.red1,
              heightsize: 8.h,
              widthsize: 90.w,
            ),





            SizedBox(height: 10.h,),
          ])),





    );
  }


}
