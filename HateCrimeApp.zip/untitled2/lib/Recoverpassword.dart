import 'package:flutter/material.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:get/route_manager.dart';

import 'package:sizer/sizer.dart';
import 'package:untitled2/Createnewaccount.dart';
import 'package:untitled2/Email.dart';
import 'package:untitled2/Profile.dart';
import 'package:untitled2/SigninMobile.dart';
import 'package:untitled2/proclamationform.dart';
import 'package:untitled2/utils/IcIcons.dart';
import 'package:untitled2/utils/colors.dart';

class RecoverPassword extends StatelessWidget {
  // final person = List<String>.generate(3, (i) => 'Person ${i+1 }' );
  static const route = "/recoverPassword";

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        elevation: 0.0,
        title: Padding(
          padding: EdgeInsets.only(left: 10.w),
          child: Text(
            "Recover Password ",
            style: TextStyle(
              fontSize: 14.sp,
              fontWeight: FontWeight.bold,
              color: AppColors.grey2,
            ),
          ),
        ),
        leading: IconButton(
            onPressed: () {},
            icon: Icon(Icons.arrow_back,color: AppColors.black1,size: 5.w,)),
        backgroundColor: AppColors.white1,
      ),
      body: SingleChildScrollView(
          child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
            SizedBox(
              height: 3.h,
            ),
          GestureDetector(
              onTap: () {
                Get.to(() => MyProfile2 ());
              },
              child:  Text(
              "Recover your password",
              style: TextStyle(
                  fontSize: 20.sp,
                  fontWeight: FontWeight.bold,
                  color: AppColors.black1),
            ),),
            SizedBox(
              height: 4.h,
            ),
            Text(
              "Please enter your registered email address.\n     You will receive password via email ",
              style: TextStyle(
                  height: 0.2.h,
                  fontSize: 11.sp,
                  fontWeight: FontWeight.w500,
                  color: AppColors.grey2),
            ),
            SizedBox(height: 5.h),
            Container(

              alignment: Alignment.center,
              height: 9.h,
              width: 90.w,
              decoration: BoxDecoration(
                  color: AppColors.grey7,
                  borderRadius: BorderRadius.circular(3.w)
              ),
              child: Padding(
                padding:  EdgeInsets.only(left: 5.w
                ),
                child: TextFormField(
                  keyboardType: TextInputType.emailAddress,
                  decoration: InputDecoration(
                    border: InputBorder.none,
                    focusedBorder: InputBorder.none,
                    enabledBorder: InputBorder.none,
                    errorBorder: InputBorder.none,
                    disabledBorder: InputBorder.none,
                    hintText: "Bellamy.Nicholas@gmail.com",
                    hintStyle:
                        TextStyle(fontSize: 13.sp, fontWeight: FontWeight.w500 ,color: Colors.black87),
                    suffixIcon: Image.asset(IcIcons.arrow1,width: 2.5.w,)
                  ),
                ),
              ),
            ),
            SizedBox(
              height: 5.h,
            ),
            GestureDetector(
                onTap: () {},
                child: Container(
                  alignment: Alignment.center,
                  width: 90.w,
                  height: 8.h,
                  decoration: BoxDecoration(
                    color: AppColors.red1,
                      borderRadius: BorderRadius.circular(2.w),
                     ),
                  child: Text(
                    "SEND PASSWORD ",
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 10.sp,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                )),
            SizedBox(
              height: 3.h,
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  "If you do not have access to your phone or email\n            account contract the admisnistrator\n                  for resetting your account",
                  style: TextStyle(
                    height: 0.3.h,
                    fontSize: 11.sp,
                      fontWeight: FontWeight.w500, color: AppColors.grey2),
                ),
              ],
            ),
            SizedBox(
              height: 5.h,
            ),
            GestureDetector(
                onTap: () {Get.to(() => CreateNewAccount());},
                child: Container(
                  alignment: Alignment.center,
                  width: 90.w,
                  height: 8.h,
                  decoration: BoxDecoration(
                    color: AppColors.red1,
                      borderRadius: BorderRadius.circular(2.w),
                    ),
                  child: Text(
                    "CONTRACT ADMINISTRATOR",
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 10.sp,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                )),
            SizedBox(
              height: 3.h,
            ),
            GestureDetector(
                onTap: () { Get.to(() => SigninMobile());},
                child: Container(
                  alignment: Alignment.center,
                  width: 90.w,
                  height: 8.5.h,
                  decoration: BoxDecoration(
                    color: AppColors.grey7,
                    borderRadius: BorderRadius.circular(2.w),

                    border: Border.all(
                      color: AppColors.red1,
                      width: 0.3.h,
                    ),
                  ),
                  child: RichText(text: TextSpan(
                      text: "ALREADY HAVE AN ACCOUNT? ",
                      style: TextStyle(
                        color: AppColors.grey1,
                        fontSize: 10.sp,

                      ),

                      children: [

                        TextSpan(
                            text: "SIGN-IN",
                  style: TextStyle(
                    color: Colors.black54,
                    fontSize: 12.sp,
                    fontWeight: FontWeight.bold,
                  ),
                        )
                      ]

                  ),

                  ),
                  ),
                ),
                SizedBox(
                  height: 7.h,
                ),

          ])

      ),

    );
  }
}
