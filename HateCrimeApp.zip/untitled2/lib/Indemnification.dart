import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';
import 'package:untitled2/Widgets/appbuttons.dart';
import 'package:untitled2/utils/IcIcons.dart';
import 'package:untitled2/utils/colors.dart';



class BottomSheet1 extends StatefulWidget {
  static const route = "/bottomSheet1";

  @override
  State<BottomSheet1> createState() => _BottomSheet1State();
}

class _BottomSheet1State extends State<BottomSheet1> {
  bool _checkbox = false;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body:  Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            child:  ElevatedButton( child: Text("Open Bottom Sheet"),
                  onPressed: () {
                    showModalBottomSheet(context: context,
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.vertical(
                                top: Radius.circular(12.w)
                            )
                        ),
                        builder: (context) => Center(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [

                              SizedBox(height: 4.h,),
                              Padding(
                                padding:  EdgeInsets.only(right: 50.w),
                                child: Text("About Indemnification\nof COMMUNION",
                                  style: TextStyle(
                                      fontSize: 12.sp,
                                      fontWeight: FontWeight.w500,
                                      color: AppColors.grey5),

                                ),
                              ),
                              SizedBox(height: 5.h,),
                              Row(
                                children: [
                                  Padding(
                                    padding: EdgeInsets.only( bottom: 11.h),
                                    child: Checkbox(
                                      checkColor: AppColors.grey5,
                                      value: _checkbox,
                                      onChanged: (value) {
                                        setState(() {
                                          _checkbox = !_checkbox;
                                        });
                                      },
                                    ),
                                  ),

                                  Text(
                                    'If in really I am not a Christian and I still\nprocess to make an account by agreeing to\nthe above creed of Christian faith, I\nunderstand that I will be solely responsible for\nany and all legal, criminal\nconsequences, for which COMMUNION shall',
                                    style: TextStyle(
                                        fontSize: 11.sp,
                                        fontWeight: FontWeight.w500,
                                        color: AppColors.grey5),
                                  ),
                                ],
                              ),
                              SizedBox(height: 7.h,),

                              Padding(
                                padding: const EdgeInsets.all(8.0),
                                child: AppButton(
                                  text: "CONTINUE",
                                  onTap: () {},
                                  backgroundColor: AppColors.red1,
                                  heightsize: 6.h,
                                  widthsize: 85.w,
                                ),
                              ),
                            ],
                          ),
                        ));
                  },

                )

            ),


        ],

      ),







    );
  }
}
