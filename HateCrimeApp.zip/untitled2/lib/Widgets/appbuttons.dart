import 'package:flutter/material.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:get/get_navigation/get_navigation.dart';
import 'package:sizer/sizer.dart';
import 'package:untitled2/utils/colors.dart';

import '../Verificationcode.dart';

class AppButton extends StatelessWidget {
  final Color backgroundColor;
  final String text;
  TextStyle? textStyle;
  IconData? icon;
  double? widthsize;
  double heightsize;
  double? textSize;

  bool? isIcon = false;
  final Function() onTap;
  AppButton(
      {Key? key,
      required this.backgroundColor,
      required this.text,
      this.widthsize,
      this.textStyle,
      required this.onTap,
      required this.heightsize})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: SizedBox(
        width: widthsize,
        height: heightsize,
        child: Container(
          child: Center(
            child: Text(
                      text,
                      style: textStyle ??
                          TextStyle(
                              color: AppColors.white1,
                              fontWeight: FontWeight.w500,
                              fontSize: 8.sp),
                    ),
          ),
          decoration: BoxDecoration(
            color: AppColors.red1,
            borderRadius: BorderRadius.all(
              Radius.circular(2.5.w),
            ),
          ),
        ),
      ),
    );
  }
}
