import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';

import 'package:sizer/sizer.dart';

import '../utils/colors.dart';

class TextInputField extends StatefulWidget {
  final TextEditingController controller;
  final TextEditingController? firstPassword;
  final bool isPhone;
  final bool isNumber;
  final bool isNumberDecimal;
  final bool isPassword;
  final bool isEmail;
  final bool isCheck;
  final bool isReadOnly;
  final String hint;
  final Color? texfieldbackcolor;
  final String? label;
  final String? value;
  final Function(String)? onChange;
  final Widget? suffixIcon;
  final Widget? prefixIcon;
  final int? limit;
  final FocusNode focusNode;
  final TextInputType? keyboardType;
  TextInputField(this.label, this.hint, this.controller, this.focusNode,
      {Key? key,
      this.firstPassword,
      this.isPhone = false,
      this.isPassword = false,
      this.isEmail = false,
      this.isCheck = true,
      this.value,
      this.suffixIcon,
      this.prefixIcon,
      this.isNumber = false,
      this.isNumberDecimal = false,
      this.keyboardType,
      this.limit,
      this.isReadOnly = false,
      this.onChange,
      this.texfieldbackcolor})
      : super(key: key);

  @override
  State<TextInputField> createState() => _TextInputFieldState();
}

class _TextInputFieldState extends State<TextInputField> {
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    widget.focusNode.addListener(() {
      setState(() {});
    });
  }

  @override
  Widget build(BuildContext context) {
    AppController appController = Get.find();
    return TextFormField(
      style: const TextStyle(color: AppColors.black1),
      controller: widget.controller,
      focusNode: widget.focusNode,
      obscureText: widget.isPassword,
      readOnly: widget.isReadOnly,
      onChanged: widget.onChange,
      inputFormatters: [
        if (widget.limit != null)
          LengthLimitingTextInputFormatter(widget.limit),
        if (widget.isNumber && !widget.isNumberDecimal)
          FilteringTextInputFormatter.digitsOnly
      ],
      keyboardType: widget.keyboardType ??
          (widget.isEmail
              ? TextInputType.emailAddress
              : widget.isPhone
                  ? TextInputType.phone
                  : widget.isNumber
                      ? TextInputType.numberWithOptions(
                          decimal: widget.isNumberDecimal)
                      : TextInputType.text),
      decoration: InputDecoration(
        isDense: false,
        hintText: widget.hint,
        fillColor: widget.texfieldbackcolor,
        contentPadding: EdgeInsets.only(top: 5.h),
        hintStyle: TextStyle(color: AppColors.black1, fontSize: 12.sp),
        labelText: widget.label,
        labelStyle: TextStyle(
          color: widget.focusNode.hasFocus
              ? AppColors.black1
              : widget.controller.text.isNotEmpty
                  ? AppColors.black1
                  : AppColors.black1,
          fontSize: 12.sp,
        ),
        prefixIcon: widget.prefixIcon,
        suffixIcon: widget.suffixIcon,
        focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(4.w),
            borderSide: const BorderSide(color: AppColors.red1, width: 2.0)),
        enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(4.w),
            borderSide: const BorderSide(color: AppColors.white1, width: 1)),
        errorBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(4.w),
            borderSide: const BorderSide(color: AppColors.red1, width: 1)),
        focusedErrorBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(4.w),
            borderSide: const BorderSide(color: AppColors.red1, width: 1)),
      ),
      validator: (value) {
        String? str = appController.validation(
            value: value,
            isCheck: widget.isCheck,
            isEmail: widget.isEmail,
            isPassword: widget.isPassword,
            isPhone: widget.isPhone,
            firstPassword: widget.firstPassword);
        return str;
      },
    );
  }
}

class AppController {
  String? validation(
      {String? value,
      required bool isCheck,
      required bool isEmail,
      required bool isPassword,
      required bool isPhone,
      TextEditingController? firstPassword}) {}
}
