import 'package:flutter/material.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:get/get_navigation/get_navigation.dart';
import 'package:sizer/sizer.dart';
import 'package:untitled2/Report%20New%20Hate%20-Crime.dart';
import 'package:untitled2/Reports%20History.dart';
import 'package:untitled2/Signup3.dart';
import 'package:untitled2/Widgets/appbuttons.dart';
import 'package:untitled2/addvictim.dart';
import 'package:untitled2/utils/IcIcons.dart';

import 'package:untitled2/utils/colors.dart';

class ReportNewHateCrime2 extends StatefulWidget {
  static const route = "/reportNewHateCrime1 ";

  ReportNewHateCrime2({Key? key}) : super(key: key);

  @override
  State<ReportNewHateCrime2> createState() => _ReportNewHateCrime2State();
}

class _ReportNewHateCrime2State extends State<ReportNewHateCrime2> {
  String? firstdropDownValue = "Food Category";
  String? seconddropDownValue = "Select";
  String? firstdropDownValue2 = "Food Category";
  String? seconddropDownValue1 = "Select";
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        elevation: 0.0,
        title: Text(
          "Report New Hate-Crime",
          style: TextStyle(
            fontSize: 12.sp,
            fontWeight: FontWeight.bold,
            color: AppColors.black1,
          ),
        ),
        leading: IconButton(
            onPressed: () {},
            icon: Icon(Icons.arrow_back,color: AppColors.black1,size: 5.w,)),
        backgroundColor: AppColors.white1,
      ),
      body: SingleChildScrollView(
        child:
        Padding(
            padding:  EdgeInsets.only(),
            child: Column(crossAxisAlignment: CrossAxisAlignment.center, children: [
              SizedBox(
                height: 3.h,
              ),
              Padding(
                padding:  EdgeInsets.only(right: 40.w),
                child: Text(
                  "Select Hate-Crime Category",
                  style: TextStyle(
                      fontSize: 11.sp,
                      fontWeight: FontWeight.bold,
                      color: AppColors.black1),
                ),
              ),
              SizedBox(
                height: 2.h,
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  DecoratedBox(
                    decoration: ShapeDecoration(
                      color: AppColors.white1,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.all(Radius.circular(2.w)),
                      ),
                    ),
                    child: Container(
                      decoration: BoxDecoration(
                          color: AppColors.grey6,
                          borderRadius: BorderRadius.circular(2.w),
                          border: Border.all(color: AppColors.grey6)),
                      height: 6.5.h,
                      width: 42.w,
                      child: DropdownButtonHideUnderline(
                        child: Padding(
                          padding: EdgeInsets.symmetric(horizontal: 2.h),
                          child: DropdownButton<String>(
                            elevation: 0,
                            icon: Icon(
                              Icons.keyboard_arrow_down_sharp,
                              color: AppColors.black1,
                            ),
                            value: firstdropDownValue,
                            dropdownColor: AppColors.grey5,
                            items: <String>['Food Category', 'Select']
                                .map((String value) {
                              return DropdownMenuItem<String>(
                                value: value,
                                child: Text(
                                  value,
                                  style: TextStyle(fontSize: 10.sp),
                                ),
                              );
                            }).toList(),
                            onChanged: (value) {
                              setState(() {
                                firstdropDownValue = value;
                              });
                            },
                          ),
                        ),
                      ),
                    ),
                  ),
                  DecoratedBox(
                    decoration: ShapeDecoration(
                      color: AppColors.white1,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.all(Radius.circular(2.w)),
                      ),
                    ),
                    child: Container(
                      decoration: BoxDecoration(
                          color: AppColors.grey6,
                          borderRadius: BorderRadius.circular(2.w),
                          border: Border.all(color: AppColors.grey6)),
                      height: 6.5.h,
                      width: 42.w,
                      child: DropdownButtonHideUnderline(
                        child: Padding(
                          padding: EdgeInsets.symmetric(horizontal: 2.h),
                          child: DropdownButton<String>(
                            elevation: 0,
                            icon: Icon(
                              Icons.keyboard_arrow_down_sharp,
                              color: AppColors.black1,
                            ),
                            value: firstdropDownValue2,
                            dropdownColor: AppColors.grey5,
                            items: <String>['Food Category', 'Select']
                                .map((String value) {
                              return DropdownMenuItem<String>(
                                value: value,
                                child: Text(
                                  value,
                                  style: TextStyle(fontSize: 10.sp),
                                ),
                              );
                            }).toList(),
                            onChanged: (value) {
                              setState(() {
                                firstdropDownValue2 = value;
                              });
                            },
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
              SizedBox(
                height: 2.h,
              ),
              Padding(
                padding:  EdgeInsets.only(right: 57.w),
                child: Text(
                  "Severity of Crime",
                  style: TextStyle(
                      fontSize: 11.sp,
                      fontWeight: FontWeight.bold,
                      color: AppColors.black1),
                ),
              ),
              SizedBox(
                height: 2.h,
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  DecoratedBox(
                    decoration: ShapeDecoration(
                      color: AppColors.white1,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.all(Radius.circular(2.w)),
                      ),
                    ),
                    child: Container(
                      decoration: BoxDecoration(
                          color: AppColors.grey6,
                          borderRadius: BorderRadius.circular(2.w),
                          border: Border.all(color: AppColors.grey6)),
                      height: 6.5.h,
                      width: 90.w,
                      child: DropdownButtonHideUnderline(
                        child: Padding(
                          padding: EdgeInsets.symmetric(horizontal: 2.h),
                          child: DropdownButton<String>(
                            elevation: 0,
                            icon: Icon(
                              Icons.keyboard_arrow_down_sharp,
                              color: AppColors.black1,
                            ),
                            value: seconddropDownValue1,
                            dropdownColor: AppColors.grey5,
                            items: <String>['Food Category', 'Select']
                                .map((String value) {
                              return DropdownMenuItem<String>(
                                value: value,
                                child: Text(
                                  value,
                                  style: TextStyle(fontSize: 10.sp),
                                ),
                              );
                            }).toList(),
                            onChanged: (value) {
                              setState(() {
                                seconddropDownValue1 = value;
                              });
                            },
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
              SizedBox(
                height: 2.h,
              ),
              Padding(
                padding: EdgeInsets.only(right: 20.w),
                child: Text(
                  "Select Data, Time and Location of Crime\nBeing reported",
                  style: TextStyle(
                      fontSize: 11.sp,
                      fontWeight: FontWeight.bold,
                      color: AppColors.black1),
                ),
              ),
              SizedBox(
                height: 2.h,
              ),
              Container(
                height: 6.5.h,
                width: 92.w,
                decoration: BoxDecoration(
                    color: AppColors.grey6,
                    borderRadius: BorderRadius.circular(2.w),
                    border: Border.all(color: AppColors.grey6)),
                child: Padding(
                  padding: EdgeInsets.all(
                    1.5.h,
                  ),
                  child: TextFormField(
                    decoration: InputDecoration(
                        border: InputBorder.none,
                        hintText: "Pick Current Location/Enter Location",
                        hintStyle: TextStyle(
                            fontSize: 10.sp,
                            fontWeight: FontWeight.w300,
                            color: AppColors.black1),
                        suffixIcon: Icon(Icons.my_location,color: AppColors.black1,)),
                  ),
                ),
              ),
              SizedBox(
                height: 2.h,
              ),
              Padding(
                padding:  EdgeInsets.only(right: 62.w),
                child: Text(
                  "Victim(s) Details",
                  style: TextStyle(
                      fontSize: 11.sp,
                      fontWeight: FontWeight.bold,
                      color: AppColors.black1),
                ),
              ),
              SizedBox(
                height: 2.h,
              ),

              SizedBox(height: 3.5.h,),
              GestureDetector(
                  onTap: () {
                    showModalBottomSheet(
                        context: context,
                        shape: RoundedRectangleBorder(
                            borderRadius:
                            BorderRadius.vertical(top: Radius.circular(5.w))),
                        builder: (context) => Container(


                          decoration: BoxDecoration(
                            color: AppColors.lite1,
                            borderRadius: BorderRadius.only(
                                topRight: Radius.circular(5.w),
                                topLeft: Radius.circular(5.w)),
                          ),
                          child: Stack(
                            children: [
                              Padding(
                                padding: EdgeInsets.only(top: 3.h),
                                child: SingleChildScrollView(
                                  child: Container(
                                    decoration: BoxDecoration(
                                      color: AppColors.white1,
                                      borderRadius: BorderRadius.only(
                                          topRight: Radius.circular(5.w),
                                          topLeft: Radius.circular(5.w)),
                                    ),
                                    height: 100.h,
                                    child: Column(
                                      children: [
                                        SizedBox(height: 2.h,),
                                        Row(
                                          children: [
                                            Text("     Add Victim(s) info",style: TextStyle(
                                                fontSize: 13.sp,
                                                fontWeight: FontWeight.bold,
                                                color: AppColors.black1)),
                                            Padding(
                                              padding:  EdgeInsets.only(left: 35.w),
                                              child: CircleAvatar(
                                                  backgroundColor: AppColors.white1,
                                                  child:
                                                  Icon(Icons.close,color: AppColors.black1,)
                                              ),
                                            )
                                          ],
                                        ),

                                        Padding(
                                          padding:  EdgeInsets.only(right: 45
                                              .w),
                                          child: Text("Full Name                     ",
                                              style: TextStyle(
                                                  fontSize: 11.sp,

                                                  color: AppColors.grey1)),
                                        ),
                                        SizedBox(height: 2.h,),
                                        SingleChildScrollView(
                                          child: Container(
                                            height: 6.5.h,
                                            width: 90.w,
                                            decoration: BoxDecoration(
                                                color: AppColors.grey6,
                                                borderRadius:
                                                BorderRadius.circular(2.w),
                                                border: Border.all(
                                                    color: AppColors.grey6)),
                                            child: Padding(
                                              padding: EdgeInsets.all(
                                                1.5.h,
                                              ),
                                              child: TextFormField(
                                                decoration: InputDecoration(
                                                  border: InputBorder.none,
                                                  hintText: "Sarah M. Holiday",
                                                  hintStyle: TextStyle(
                                                      fontSize: 10.sp,
                                                      fontWeight:
                                                      FontWeight.w500,
                                                      color: AppColors.black1),
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                        SizedBox(height: 2.h,),
                                        Row(
                                          mainAxisAlignment:
                                          MainAxisAlignment.spaceEvenly,
                                          children: [
                                            Text(
                                              "Age                                               ",
                                              style: TextStyle(
                                                  fontSize: 10.sp,
                                                  fontWeight: FontWeight.w300,
                                                  color: AppColors.grey5),
                                            ),

                                            Text(
                                              "Gender                               ",
                                              style: TextStyle(
                                                  fontSize: 10.sp,
                                                  fontWeight: FontWeight.w300,
                                                  color: AppColors.grey5),
                                            )
                                          ],
                                        ),
                                        SizedBox(height: 2.h,),

                                        Row(
                                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                          children: [
                                            Container(
                                              height: 6.5.h,
                                              width: 45.w,
                                              decoration: BoxDecoration(
                                                  color: AppColors.grey6,
                                                  borderRadius: BorderRadius.circular(2.w),
                                                  border: Border.all(color: AppColors.grey6)),
                                              child: Padding(
                                                padding: EdgeInsets.all(
                                                  1.5.h,
                                                ),
                                                child: TextFormField(
                                                  decoration: InputDecoration(
                                                    border: InputBorder.none,
                                                    hintText: "34 Years",
                                                    hintStyle: TextStyle(
                                                        fontSize: 10.sp,
                                                        fontWeight: FontWeight.w500,
                                                        color: AppColors.black1),
                                                  ),
                                                ),
                                              ),
                                            ),
                                            DecoratedBox(
                                              decoration: ShapeDecoration(
                                                color: AppColors.white1,
                                                shape: RoundedRectangleBorder(
                                                  borderRadius: BorderRadius.all(Radius.circular(2.w)),
                                                ),
                                              ),
                                              child: Container(
                                                decoration: BoxDecoration(
                                                    color: AppColors.grey6,
                                                    borderRadius: BorderRadius.circular(2.w),
                                                    border: Border.all(color: AppColors.grey6)),
                                                height: 6.5.h,
                                                width: 45.w,
                                                child: DropdownButtonHideUnderline(
                                                  child: Padding(
                                                    padding: EdgeInsets.symmetric(horizontal: 2.h),
                                                    child: DropdownButton<String>(
                                                      elevation: 0,
                                                      icon: Icon(
                                                        Icons.keyboard_arrow_down_sharp,
                                                        color: AppColors.black1,
                                                      ),
                                                      value: firstdropDownValue,
                                                      dropdownColor: AppColors.grey5,
                                                      items: <String>['Food Category', 'Select']
                                                          .map((String value) {
                                                        return DropdownMenuItem<String>(
                                                          value: value,
                                                          child: Text(
                                                            value,
                                                            style: TextStyle(fontSize: 10.sp),
                                                          ),
                                                        );
                                                      }).toList(),
                                                      onChanged: (value) {
                                                        setState(() {
                                                          firstdropDownValue = value;
                                                        });
                                                      },
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                        SizedBox(
                                          height: 2.h,
                                        ),
                                        Padding(
                                          padding:  EdgeInsets.only(right: 62.w),
                                          child: Text(
                                            "Location of Crime",
                                            style: TextStyle(
                                                fontSize: 10.sp,
                                                fontWeight: FontWeight.w300,
                                                color: AppColors.grey5),
                                          ),
                                        ),
                                        SizedBox(
                                          height: 2.h,
                                        ),
                                        Container(
                                          height: 6.5.h,
                                          width: 90.w,
                                          decoration: BoxDecoration(
                                              color: AppColors.grey6,
                                              borderRadius:
                                              BorderRadius.circular(2.w),
                                              border: Border.all(
                                                  color: AppColors.grey6)),
                                          child: Padding(
                                            padding: EdgeInsets.all(
                                              1.5.h,
                                            ),
                                            child: TextFormField(
                                              decoration: InputDecoration(
                                                border: InputBorder.none,
                                                hintText: "1378 Bryan Avenue. Minneapolis",
                                                hintStyle: TextStyle(
                                                    fontSize: 10.sp,
                                                    fontWeight:
                                                    FontWeight.w500,
                                                    color: AppColors.black1),
                                              ),
                                            ),
                                          ),
                                        ),

                                        SizedBox(
                                          height: 2.h,
                                        ),


                                        DecoratedBox(
                                          decoration: ShapeDecoration(
                                            color: AppColors.white1,
                                            shape: RoundedRectangleBorder(
                                              borderRadius: BorderRadius.all(
                                                  Radius.circular(2.w)),
                                            ),
                                          ),
                                          child: Container(
                                            decoration: BoxDecoration(
                                                color: AppColors.grey6,
                                                borderRadius:
                                                BorderRadius.circular(
                                                    2.w),
                                                border: Border.all(
                                                    color: AppColors.grey6)),
                                            height: 6.5.h,
                                            width: 90.w,
                                            child:
                                            DropdownButtonHideUnderline(
                                              child: Padding(
                                                padding: EdgeInsets.symmetric(
                                                    horizontal: 2.h),
                                                child: DropdownButton<String>(
                                                  elevation: 0,
                                                  icon: Icon(
                                                    Icons
                                                        .keyboard_arrow_down_sharp,
                                                    color: AppColors.black1,
                                                  ),
                                                  value: seconddropDownValue,
                                                  dropdownColor:
                                                  AppColors.grey5,
                                                  items: <String>[
                                                    'Food Category',
                                                    'Select'
                                                  ].map((String value) {
                                                    return DropdownMenuItem<
                                                        String>(
                                                      value: value,
                                                      child: Text(
                                                        value,
                                                        style: TextStyle(
                                                            fontSize: 10.sp),
                                                      ),
                                                    );
                                                  }).toList(),
                                                  onChanged: (value) {
                                                    setState(() {
                                                      seconddropDownValue =
                                                          value;
                                                    });
                                                  },
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),

                                        SizedBox(
                                          height: 2.h,
                                        ),

                                        Text("Reason (s) for victimization-victim(s) perspective             ",style: TextStyle(
                                            fontSize: 10.sp,
                                            fontWeight: FontWeight.w400,
                                            color: AppColors.grey5),),
                                        SizedBox(
                                          height: 3.h,
                                        ),
                                        Container(
                                          height: 20.h,
                                          width: 90.w,
                                          decoration: BoxDecoration(
                                              color: AppColors.grey6,
                                              borderRadius:
                                              BorderRadius.circular(2.w),
                                              border: Border.all(
                                                  color: AppColors.grey6)),
                                          child: TextFormField(
                                            decoration: InputDecoration(
                                              border: InputBorder.none,
                                              hintText: "     Enter Details",
                                              hintStyle: TextStyle(
                                                  fontSize: 10.sp,
                                                  fontWeight:
                                                  FontWeight.w300,
                                                  color: AppColors.black1),
                                            ),
                                          ),
                                        ),

                                        SizedBox(
                                          height: 5.h,
                                        ),

                                        AppButton(
                                          text: "Add Details",
                                          onTap: () {

                                          },
                                          backgroundColor: AppColors.red1,
                                          heightsize: 8.h,
                                          widthsize: 90.w,
                                        ),
                                        SizedBox(height: 2.h,)
                                      ],
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ));
                  },
                  child: Container(
                    alignment: Alignment.center,
                    width: 88.w,
                    height: 7.h,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(8.0),
                      color: AppColors.lite1,
                      border: Border.all(
                        color: AppColors.lite1,
                        width: 0.2.h,
                      ),
                    ),
                    child: Text(
                      "ADD NEW VICTIM",
                      style: TextStyle(
                        color: AppColors.dark1,
                        fontSize: 10.sp,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  )),
              SizedBox(
                height: 2.h,
              ),
              Padding(
                padding:  EdgeInsets.only(right: 40.w),
                child: Text(
                  "Perpetrator(s) Details",
                  style: TextStyle(
                      fontSize: 14.sp,
                      fontWeight: FontWeight.bold,
                      color: AppColors.black1),
                ),
              ),
            
              SizedBox(
                height: 3.h,
              ),
              GestureDetector(
                  onTap: () {  showModalBottomSheet(
                      context: context,
                      shape: RoundedRectangleBorder(
                          borderRadius:
                          BorderRadius.vertical(top: Radius.circular(5.w))),
                      builder: (context) => Container(


                        decoration: BoxDecoration(
                          color: AppColors.lite1,
                          borderRadius: BorderRadius.only(
                              topRight: Radius.circular(5.w),
                              topLeft: Radius.circular(5.w)),
                        ),
                        child: Stack(
                          children: [
                            Padding(
                              padding: EdgeInsets.only(top: 3.h),
                              child: SingleChildScrollView(
                                child: Container(
                                  decoration: BoxDecoration(
                                    color: AppColors.white1,
                                    borderRadius: BorderRadius.only(
                                        topRight: Radius.circular(5.w),
                                        topLeft: Radius.circular(5.w)),
                                  ),
                                  height: 100.h,
                                  child: Column(
                                    children: [
                                      SizedBox(height: 2.h,),
                                      Row(
                                        children: [
                                          Text("     Add Perpetrator(s) info",style: TextStyle(
                                              fontSize: 13.sp,
                                              fontWeight: FontWeight.bold,
                                              color: AppColors.black1)),
                                          Padding(
                                            padding:  EdgeInsets.only(left: 35.w),
                                            child: CircleAvatar(
                                                backgroundColor: AppColors.white1,
                                                child:
                                                Icon(Icons.close,color: AppColors.black1,)
                                            ),
                                          )
                                        ],
                                      ),

                                      Padding(
                                        padding:  EdgeInsets.only(right: 45
                                            .w),
                                        child: Text("Full Name                     ",
                                            style: TextStyle(
                                                fontSize: 11.sp,

                                                color: AppColors.grey1)),
                                      ),
                                      SizedBox(height: 2.h,),
                                      SingleChildScrollView(
                                        child: Container(
                                          height: 6.5.h,
                                          width: 90.w,
                                          decoration: BoxDecoration(
                                              color: AppColors.grey6,
                                              borderRadius:
                                              BorderRadius.circular(2.w),
                                              border: Border.all(
                                                  color: AppColors.grey6)),
                                          child: Padding(
                                            padding: EdgeInsets.all(
                                              1.5.h,
                                            ),
                                            child: TextFormField(
                                              decoration: InputDecoration(
                                                border: InputBorder.none,
                                                hintText: "Abu Bin Oalid",
                                                hintStyle: TextStyle(
                                                    fontSize: 10.sp,
                                                    fontWeight:
                                                    FontWeight.w500,
                                                    color: AppColors.black1),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                      SizedBox(height: 2.h,),
                                      Row(
                                        mainAxisAlignment:
                                        MainAxisAlignment.spaceEvenly,
                                        children: [
                                          Text(
                                            "Age                                               ",
                                            style: TextStyle(
                                                fontSize: 10.sp,
                                                fontWeight: FontWeight.w300,
                                                color: AppColors.grey5),
                                          ),

                                          Text(
                                            "Gender                               ",
                                            style: TextStyle(
                                                fontSize: 10.sp,
                                                fontWeight: FontWeight.w300,
                                                color: AppColors.grey5),
                                          )
                                        ],
                                      ),
                                      SizedBox(height: 2.h,),

                                      Row(
                                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                        children: [
                                          Container(
                                            height: 6.5.h,
                                            width: 45.w,
                                            decoration: BoxDecoration(
                                                color: AppColors.grey6,
                                                borderRadius: BorderRadius.circular(2.w),
                                                border: Border.all(color: AppColors.grey6)),
                                            child: Padding(
                                              padding: EdgeInsets.all(
                                                1.5.h,
                                              ),
                                              child: TextFormField(
                                                decoration: InputDecoration(
                                                  border: InputBorder.none,
                                                  hintText: "24 Years",
                                                  hintStyle: TextStyle(
                                                      fontSize: 10.sp,
                                                      fontWeight: FontWeight.w500,
                                                      color: AppColors.black1),
                                                ),
                                              ),
                                            ),
                                          ),
                                          DecoratedBox(
                                            decoration: ShapeDecoration(
                                              color: AppColors.white1,
                                              shape: RoundedRectangleBorder(
                                                borderRadius: BorderRadius.all(Radius.circular(2.w)),
                                              ),
                                            ),
                                            child: Container(
                                              decoration: BoxDecoration(
                                                  color: AppColors.grey6,
                                                  borderRadius: BorderRadius.circular(2.w),
                                                  border: Border.all(color: AppColors.grey6)),
                                              height: 6.5.h,
                                              width: 45.w,
                                              child: DropdownButtonHideUnderline(
                                                child: Padding(
                                                  padding: EdgeInsets.symmetric(horizontal: 2.h),
                                                  child: DropdownButton<String>(
                                                    elevation: 0,
                                                    icon: Icon(
                                                      Icons.keyboard_arrow_down_sharp,
                                                      color: AppColors.black1,
                                                    ),
                                                    value: seconddropDownValue,
                                                    dropdownColor: AppColors.grey5,
                                                    items: <String>['Food Category', 'Select']
                                                        .map((String value) {
                                                      return DropdownMenuItem<String>(
                                                        value: value,
                                                        child: Text(
                                                          value,
                                                          style: TextStyle(fontSize: 10.sp),
                                                        ),
                                                      );
                                                    }).toList(),
                                                    onChanged: (value) {
                                                      setState(() {
                                                        seconddropDownValue = value;
                                                      });
                                                    },
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                      SizedBox(
                                        height: 2.h,
                                      ),
                                      Padding(
                                        padding:  EdgeInsets.only(right: 62.w),
                                        child: Text(
                                          "Location of Crime",
                                          style: TextStyle(
                                              fontSize: 10.sp,
                                              fontWeight: FontWeight.w300,
                                              color: AppColors.grey5),
                                        ),
                                      ),
                                      SizedBox(
                                        height: 2.h,
                                      ),
                                      Container(
                                        height: 6.5.h,
                                        width: 90.w,
                                        decoration: BoxDecoration(
                                            color: AppColors.grey6,
                                            borderRadius:
                                            BorderRadius.circular(2.w),
                                            border: Border.all(
                                                color: AppColors.grey6)),
                                        child: Padding(
                                          padding: EdgeInsets.all(
                                            1.5.h,
                                          ),
                                          child: TextFormField(
                                            decoration: InputDecoration(
                                              border: InputBorder.none,
                                              hintText: "1378 Bryan Avenue. Minneapolis",
                                              hintStyle: TextStyle(
                                                  fontSize: 10.sp,
                                                  fontWeight:
                                                  FontWeight.w500,
                                                  color: AppColors.black1),
                                            ),
                                          ),
                                        ),
                                      ),

                                      SizedBox(
                                        height: 2.h,
                                      ),


                                      DecoratedBox(
                                        decoration: ShapeDecoration(
                                          color: AppColors.white1,
                                          shape: RoundedRectangleBorder(
                                            borderRadius: BorderRadius.all(
                                                Radius.circular(2.w)),
                                          ),
                                        ),
                                        child: Container(
                                          decoration: BoxDecoration(
                                              color: AppColors.grey6,
                                              borderRadius:
                                              BorderRadius.circular(
                                                  2.w),
                                              border: Border.all(
                                                  color: AppColors.grey6)),
                                          height: 6.5.h,
                                          width: 90.w,
                                          child:
                                          DropdownButtonHideUnderline(
                                            child: Padding(
                                              padding: EdgeInsets.symmetric(
                                                  horizontal: 2.h),
                                              child: DropdownButton<String>(
                                                elevation: 0,
                                                icon: Icon(
                                                  Icons
                                                      .keyboard_arrow_down_sharp,
                                                  color: AppColors.black1,
                                                ),
                                                value: firstdropDownValue,
                                                dropdownColor:
                                                AppColors.grey5,
                                                items: <String>[
                                                  'Food Category',
                                                  'Select'
                                                ].map((String value) {
                                                  return DropdownMenuItem<
                                                      String>(
                                                    value: value,
                                                    child: Text(
                                                      value,
                                                      style: TextStyle(
                                                          fontSize: 10.sp),
                                                    ),
                                                  );
                                                }).toList(),
                                                onChanged: (value) {
                                                  setState(() {
                                                    firstdropDownValue =
                                                        value;
                                                  });
                                                },
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),

                                      SizedBox(
                                        height: 2.h,
                                      ),

                                      Padding(
                                        padding:  EdgeInsets.only(right: 18.w),
                                        child: Text("Reason (s) given by perpetrator(s) to commit/\njustify the hate crime? ",style: TextStyle(
                                            fontSize: 10.sp,
                                            fontWeight: FontWeight.w500,
                                            color: AppColors.grey5),),
                                      ),
                                      SizedBox(
                                        height: 3.h,
                                      ),
                                      Container(
                                        height: 20.h,
                                        width: 90.w,
                                        decoration: BoxDecoration(
                                            color: AppColors.grey6,
                                            borderRadius:
                                            BorderRadius.circular(2.w),
                                            border: Border.all(
                                                color: AppColors.grey6)),
                                        child: TextFormField(
                                          decoration: InputDecoration(
                                            border: InputBorder.none,
                                            hintText: "     Enter Details",
                                            hintStyle: TextStyle(
                                                fontSize: 10.sp,
                                                fontWeight:
                                                FontWeight.w300,
                                                color: AppColors.black1),
                                          ),
                                        ),
                                      ),

                                      SizedBox(
                                        height: 5.h,
                                      ),

                                      AppButton(
                                        text: "Add Details",
                                        onTap: () {Get.to(() => ReportNewHateCrime1());},
                                        backgroundColor: AppColors.red1,
                                        heightsize: 8.h,
                                        widthsize: 90.w,
                                      ),
                                      SizedBox(height: 2.h,)
                                    ],
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ));},
                  child: Container(
                    alignment: Alignment.center,
                    width: 88.w,
                    height: 7.h,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(8.0),
                      color: AppColors.lite1,
                      border: Border.all(
                        color: AppColors.lite1,
                        width: 0.2.h,
                      ),
                    ),
                    child: Text(
                      "ADD NEW PERPETRATOR",
                      style: TextStyle(
                        color: AppColors.dark1,
                        fontSize: 10.sp,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  )),
              SizedBox(
                height: 3.h,
              ),
              Padding(
                padding: EdgeInsets.only(right: 50.w),
                child: Text(
                  "Additional Information",
                  style: TextStyle(
                      fontSize: 12.sp,
                      fontWeight: FontWeight.bold,
                      color: AppColors.black1),
                ),
              ),
              SizedBox(
                height: 3.h,
              ),
              Container(
                height: 15.h,
                width: 90.w,
                decoration: BoxDecoration(
                    color: AppColors.grey6,
                    borderRadius: BorderRadius.circular(2.w),
                    border: Border.all(color: AppColors.grey6)),
                child: Padding(
                  padding: EdgeInsets.all(
                    1.5.h,
                  ),
                  child: TextFormField(
                    decoration: InputDecoration(
                      border: InputBorder.none,
                      hintText: "Write Details of Crime",
                      hintStyle: TextStyle(
                          fontSize: 10.sp,
                          fontWeight: FontWeight.w300,
                          color: AppColors.grey5),
                    ),
                  ),
                ),
              ),
              SizedBox(
                height: 3.h,
              ),
              Padding(
                padding:  EdgeInsets.only(right: 55.w),
                child: Text(
                  "Attach Media Files",
                  style: TextStyle(
                      fontSize: 12.sp,
                      fontWeight: FontWeight.bold,
                      color: AppColors.black1),
                ),
              ),
              SizedBox(
                height: 3.h,
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  Container(
                    alignment: Alignment.center,

                    height: 17.h,
                    width: 22.w,
                    decoration: BoxDecoration(
                        color: AppColors.grey6,
                        borderRadius: BorderRadius.circular(2.w)
                    ),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        CircleAvatar(
                          radius: 8.w,
                          backgroundColor: AppColors.blue1,
                          child: Padding(
                            padding:  EdgeInsets.symmetric(vertical: 3.h, horizontal: 3.w),
                            child: Image.asset(IcIcons.VideoImage,width: 8.w,),
                          ),
                        ),
                        SizedBox(height: 2.h,),
                        Text("Add Video",style: TextStyle(
                            fontSize: 8.sp,
                            fontWeight: FontWeight.bold,
                            color: AppColors.black1),),
                        Text("Max. 20 Sec.",style: TextStyle(
                            fontSize: 6.sp,
                            fontWeight: FontWeight.bold,
                            color: AppColors.grey2),)
                      ],
                    ),
                  ),
                  Container(
                    alignment: Alignment.center,

                    height: 17.h,
                    width: 22.w,
                    decoration: BoxDecoration(
                        color: AppColors.grey6,
                        borderRadius: BorderRadius.circular(2.w)
                    ),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        CircleAvatar(
                          backgroundColor: AppColors.orange1,
                          radius: 8.w,
                          child: Padding(
                            padding:  EdgeInsets.symmetric(vertical: 3.h, horizontal: 3.w),
                            child: Image.asset(IcIcons.VoiceImage,width: 5.w,),
                          ),
                        ),
                        SizedBox(height: 2.h,),
                        Text("Add Audio",style: TextStyle(
                            fontSize: 8.sp,
                            fontWeight: FontWeight.bold,
                            color: AppColors.black1),),
                        Text("Max. 20 Sec.",style: TextStyle(
                            fontSize: 6.sp,
                            fontWeight: FontWeight.bold,
                            color: AppColors.grey2),)
                      ],
                    ),
                  ),
                  Container(
                    alignment: Alignment.center,

                    height: 17.h,
                    width: 22.w,
                    decoration: BoxDecoration(
                        color: AppColors.grey6,

                        borderRadius: BorderRadius.circular(2.w)
                    ),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        CircleAvatar(
                          backgroundColor: AppColors.pink1,
                          radius: 8.w,
                          child: Padding(
                            padding:  EdgeInsets.symmetric(vertical: 3.h, horizontal: 3.w),
                            child: Image.asset(IcIcons.PhotoImage,width: 10.w,),
                          ),
                        ),
                        SizedBox(height: 2.h,),
                        Text("Add Photo",style: TextStyle(
                            fontSize: 8.sp,
                            fontWeight: FontWeight.bold,
                            color: AppColors.black1),),
                        Text("Max. 5 Photos",style: TextStyle(
                            fontSize: 6.sp,
                            fontWeight: FontWeight.bold,
                            color: AppColors.grey2),),

                      ],
                    ),
                  ),],
              ),
              SizedBox(height: 5.h,),
              Container(
                height: 8.h,
                width: 90.w,
                decoration: BoxDecoration(
                    color: AppColors.grey6,

                    borderRadius: BorderRadius.circular(5.w)
                ),
                child: ListTile(
                  leading: CircleAvatar(
                    radius: 5.w,
                    child: Image.asset(IcIcons.VideoImage,width: 5.w
                      ,),

                  ),
                  title: Text("Video041221.mp4",style: TextStyle(fontWeight: FontWeight.bold),),
                  trailing: Image.asset(IcIcons.DeleteImage),
                ),
              ),
              SizedBox(height: 2.h,),
              Container(

                height: 8.h,
                width: 90.w,
                decoration: BoxDecoration(
                    color: AppColors.grey6,

                    borderRadius: BorderRadius.circular(5.w)
                ),
                child: ListTile(
                  leading: CircleAvatar(
                    backgroundColor: AppColors.orange1,
                    radius: 5.w,
                    child: Image.asset(IcIcons.VoiceImage,width: 4.w
                      ,),

                  ),
                  title: Text("Audio04211.mp3",style: TextStyle(fontWeight: FontWeight.bold),),
                  trailing: Image.asset(IcIcons.DeleteImage),
                ),
              ),
              SizedBox(height: 2.h,),
              Container(
                height: 8.h,
                width: 90.w,
                decoration: BoxDecoration(
                    color: AppColors.grey6,

                    borderRadius: BorderRadius.circular(5.w)
                ),
                child: ListTile(
                  leading: CircleAvatar(
                    backgroundColor: AppColors.pink1,
                    radius: 5.w,
                    child: Image.asset(IcIcons.PhotoImage,width: 5.w
                      ,),

                  ),
                  title: Text("Image041221.jpg",style: TextStyle(fontWeight: FontWeight.bold),),
                  trailing: Image.asset(IcIcons.DeleteImage),
                ),
              ),
              SizedBox(height: 2.h,),
              Container(
                height: 8.h,
                width: 90.w,
                decoration: BoxDecoration(
                    color: AppColors.grey6,

                    borderRadius: BorderRadius.circular(5.w)
                ),
                child: ListTile(
                  leading: CircleAvatar(
                    backgroundColor: AppColors.pink1,
                    radius: 5.w,
                    child: Image.asset(IcIcons.PhotoImage,width: 4.w
                      ,),

                  ),
                  title: Text("Image04211.jpg",style: TextStyle(fontWeight: FontWeight.bold),),
                  trailing: Image.asset(IcIcons.DeleteImage),
                ),
              ),
              SizedBox(height: 7.h,),
              AppButton(
                text: "SUBMIT",
                onTap: () {
                  Get.to(() => ReportNewHateCrime1());
                },
                backgroundColor: AppColors.red1,
                heightsize: 8.h,
                widthsize: 85.w,
              ),

              SizedBox(height: 5.h,),
            ])),
      ),
    );
  }
}
